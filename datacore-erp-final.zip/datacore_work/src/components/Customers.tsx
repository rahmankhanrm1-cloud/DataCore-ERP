import React, { useState, useEffect } from 'react';
import { db } from '../firebase';
import {
  collection,
  addDoc,
  getDocs,
  updateDoc,
  deleteDoc,
  doc,
  serverTimestamp,
  query,
  where,
  runTransaction
} from 'firebase/firestore';
import { Customer, Settings } from '../types';
import { formatCurrency, generateCode, formatDate } from '../utils/formatters';
import {
  Users,
  Plus,
  Search,
  Edit2,
  Trash2,
  Eye,
  AlertTriangle,
  X,
  CreditCard,
  FileText,
  Phone,
  Mail,
  MapPin,
  DollarSign
} from 'lucide-react';

interface CustomersProps {
  settings: Settings;
}

export const Customers: React.FC<CustomersProps> = ({ settings }) => {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);
  const [viewCustomer, setViewCustomer] = useState<Customer | null>(null);
  const [customerInvoices, setCustomerInvoices] = useState<any[]>([]);
  const [customerPayments, setCustomerPayments] = useState<any[]>([]);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  // Quick Payment Modal
  const [payModalCustomer, setPayModalCustomer] = useState<Customer | null>(null);
  const [payAmount, setPayAmount] = useState<number | ''>('');
  const [payMethod, setPayMethod] = useState('Cash');
  const [payRef, setPayRef] = useState('');

  // Form Fields
  const [name, setName] = useState('');
  const [mobile, setMobile] = useState('');
  const [email, setEmail] = useState('');
  const [address, setAddress] = useState('');
  const [openingBalance, setOpeningBalance] = useState<number | ''>(0);
  const [notes, setNotes] = useState('');
  const [formError, setFormError] = useState<string | null>(null);

  const fetchCustomers = async () => {
    try {
      setLoading(true);
      const snap = await getDocs(collection(db, 'customers'));
      const list: Customer[] = snap.docs.map(d => {
        const data = d.data();
        return {
          id: d.id,
          code: data.code || `CUS-${d.id.slice(0, 5).toUpperCase()}`,
          name: data.name || 'Unnamed Customer',
          mobile: data.mobile || '',
          email: data.email || '',
          address: data.address || '',
          openingBalance: Number(data.openingBalance || 0),
          outstanding: Number(data.outstanding ?? (data.openingBalance || 0)),
          notes: data.notes || '',
          createdAt: data.createdAt?.toDate ? data.createdAt.toDate().toISOString() : data.createdAt,
        };
      });
      list.sort((a, b) => b.code.localeCompare(a.code));
      setCustomers(list);
    } catch (err) {
      console.error('Error fetching customers:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCustomers();
  }, []);

  const openAddModal = () => {
    setEditingCustomer(null);
    setName('');
    setMobile('');
    setEmail('');
    setAddress('');
    setOpeningBalance(0);
    setNotes('');
    setFormError(null);
    setIsModalOpen(true);
  };

  const openEditModal = (c: Customer) => {
    setEditingCustomer(c);
    setName(c.name);
    setMobile(c.mobile);
    setEmail(c.email);
    setAddress(c.address);
    setOpeningBalance(c.openingBalance);
    setNotes(c.notes || '');
    setFormError(null);
    setIsModalOpen(true);
  };

  const openViewCustomer = async (c: Customer) => {
    // Clear previous customer's history immediately
    setCustomerInvoices([]);
    setCustomerPayments([]);
    setViewCustomer(c);

    try {
      const [sSnap, pSnap] = await Promise.all([
        getDocs(query(collection(db, 'sales'), where('customerId', '==', c.id))),
        getDocs(query(collection(db, 'payments'), where('partyId', '==', c.id))),
      ]);

      const invoices = sSnap.docs.map(d => ({ id: d.id, ...d.data() }));
      invoices.sort((a: any, b: any) => (b.date || '').localeCompare(a.date || ''));
      setCustomerInvoices(invoices);

      // Derive payments from both invoices with paid > 0 and separate payment records
      const invoicePayments = invoices
        .filter((inv: any) => (Number(inv.paid) || 0) > 0)
        .map((inv: any) => ({
          id: `inv-pay-${inv.id}`,
          date: inv.date,
          paymentMethod: inv.paymentMethod || inv.method || '-',
          reference: inv.invoiceNumber,
          amount: Number(inv.paid) || 0,
          source: 'Invoice Payment',
        }));

      const separatePayments = pSnap.docs
        .map(d => ({ id: d.id, ...d.data() }))
        .filter((p: any) => p.type === 'customer_payment' || !p.type)
        .map((p: any) => ({
          id: p.id,
          date: p.date,
          paymentMethod: p.paymentMethod || '-',
          reference: p.reference || '-',
          amount: Number(p.amount) || 0,
          source: 'Receipt',
        }));

      const allPayments = [...invoicePayments, ...separatePayments];
      allPayments.sort((a, b) => (b.date || '').localeCompare(a.date || ''));
      setCustomerPayments(allPayments);
    } catch (err) {
      console.error('Error fetching customer history:', err);
      setCustomerInvoices([]);
      setCustomerPayments([]);
    }
  };

  const closeViewCustomer = () => {
    setViewCustomer(null);
    setCustomerInvoices([]);
    setCustomerPayments([]);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setFormError('Customer Name is required.');
      return;
    }

    const opBal = Number(openingBalance) || 0;
    setSaving(true);
    setFormError(null);

    try {
      if (editingCustomer) {
        await updateDoc(doc(db, 'customers', editingCustomer.id), {
          name: name.trim(),
          mobile: mobile.trim(),
          email: email.trim(),
          address: address.trim(),
          notes: notes.trim(),
          updatedAt: serverTimestamp(),
        });
      } else {
        const autoCode = generateCode('CUS', customers.length);
        await addDoc(collection(db, 'customers'), {
          code: autoCode,
          name: name.trim(),
          mobile: mobile.trim(),
          email: email.trim(),
          address: address.trim(),
          openingBalance: opBal,
          outstanding: opBal, // initial outstanding is opening balance
          notes: notes.trim(),
          createdAt: serverTimestamp(),
        });
      }
      setIsModalOpen(false);
      fetchCustomers();
    } catch (err: any) {
      console.error('Error saving customer:', err);
      setFormError(err.message || 'Failed to save customer.');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await deleteDoc(doc(db, 'customers', id));
      setDeleteConfirmId(null);
      fetchCustomers();
    } catch (err) {
      console.error('Error deleting customer:', err);
    }
  };

  const handleRecordPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!payModalCustomer) return;
    const amount = Number(payAmount);
    if (isNaN(amount) || amount <= 0) return;

    setSaving(true);
    try {
      await runTransaction(db, async transaction => {
        const cRef = doc(db, 'customers', payModalCustomer.id);
        const cDoc = await transaction.get(cRef);
        if (!cDoc.exists()) throw new Error('Customer not found');
        const currentBal = Number(cDoc.data().outstanding || 0);
        const newBal = currentBal - amount;

        transaction.update(cRef, {
          outstanding: newBal,
          updatedAt: serverTimestamp(),
        });

        // Record payment in payments collection
        const payRefDoc = doc(collection(db, 'payments'));
        transaction.set(payRefDoc, {
          type: 'customer_payment',
          partyId: payModalCustomer.id,
          partyName: payModalCustomer.name,
          amount,
          date: new Date().toISOString().slice(0, 10),
          paymentMethod: payMethod,
          reference: payRef.trim(),
          createdAt: serverTimestamp(),
        });
      });

      setPayModalCustomer(null);
      setPayAmount('');
      setPayRef('');
      fetchCustomers();
    } catch (err) {
      console.error('Error recording payment:', err);
    } finally {
      setSaving(false);
    }
  };

  const filteredCustomers = customers.filter(c =>
    c.name.toLowerCase().includes(search.toLowerCase()) ||
    c.code.toLowerCase().includes(search.toLowerCase()) ||
    c.mobile.toLowerCase().includes(search.toLowerCase()) ||
    c.email.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-slate-900 border border-slate-800 p-4 sm:p-5 rounded-2xl">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-white flex items-center gap-2.5">
            <Users className="text-cyan-400" size={26} />
            <span>Customer Directory</span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 mt-0.5">
            Maintain client accounts, track outstanding receivables, and view billing history.
          </p>
        </div>
        <button
          onClick={openAddModal}
          className="bg-cyan-600 hover:bg-cyan-500 text-white font-medium px-4 py-2.5 rounded-xl flex items-center gap-2 transition cursor-pointer text-sm shadow-lg shadow-cyan-950 w-full sm:w-auto justify-center"
        >
          <Plus size={18} />
          <span>Add Customer</span>
        </button>
      </div>

      {/* Search Bar */}
      <div className="bg-slate-900/70 border border-slate-800 p-3 sm:p-4 rounded-xl">
        <div className="relative">
          <Search size={18} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" />
          <input
            type="text"
            placeholder="Search by customer name, code, phone, email..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-10 pr-4 py-2 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-cyan-500"
          />
        </div>
      </div>

      {/* Customer List */}
      {loading ? (
        <div className="text-center py-16 bg-slate-900/50 border border-slate-800 rounded-2xl">
          <span className="inline-block w-8 h-8 border-3 border-cyan-400 border-t-transparent rounded-full animate-spin" />
          <p className="text-slate-400 text-sm mt-3">Loading customer accounts...</p>
        </div>
      ) : filteredCustomers.length === 0 ? (
        <div className="text-center py-14 bg-slate-900/40 border border-slate-800 rounded-2xl space-y-3">
          <Users className="mx-auto text-slate-600" size={44} />
          <p className="text-slate-300 font-medium text-base">No customers found</p>
          <p className="text-slate-500 text-xs max-w-sm mx-auto">
            {search
              ? 'No matching customer names or mobile numbers found.'
              : 'Add your first customer to enable creating sales invoices and tracking accounts receivable.'}
          </p>
          <button
            onClick={openAddModal}
            className="mt-2 bg-slate-800 hover:bg-slate-750 text-cyan-400 border border-cyan-500/30 px-4 py-2 rounded-xl text-sm font-medium transition cursor-pointer"
          >
            + Add First Customer
          </button>
        </div>
      ) : (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-slate-950/80 text-slate-400 border-b border-slate-800 text-xs uppercase tracking-wider">
                <tr>
                  <th className="py-3 px-4">Customer Code</th>
                  <th className="py-3 px-4">Name & Contact</th>
                  <th className="py-3 px-4">Address</th>
                  <th className="py-3 px-4 text-right">Opening Bal</th>
                  <th className="py-3 px-4 text-right">Outstanding Due</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-slate-200">
                {filteredCustomers.map(c => {
                  const hasDue = c.outstanding > 0;
                  return (
                    <tr key={c.id} className="hover:bg-slate-800/40 transition">
                      <td className="py-3.5 px-4 font-mono text-xs">
                        <span className="font-semibold text-cyan-300">{c.code}</span>
                      </td>
                      <td className="py-3.5 px-4">
                        <span className="font-semibold text-white block text-sm">{c.name}</span>
                        <div className="flex items-center gap-3 text-xs text-slate-400 mt-0.5">
                          {c.mobile && (
                            <span className="flex items-center gap-1">
                              <Phone size={12} className="text-slate-500" /> {c.mobile}
                            </span>
                          )}
                          {c.email && (
                            <span className="flex items-center gap-1">
                              <Mail size={12} className="text-slate-500" /> {c.email}
                            </span>
                          )}
                        </div>
                      </td>
                      <td className="py-3.5 px-4 text-xs text-slate-400 max-w-[180px] truncate">
                        {c.address || '-'}
                      </td>
                      <td className="py-3.5 px-4 text-right font-mono text-xs text-slate-400">
                        {formatCurrency(c.openingBalance, settings.currency)}
                      </td>
                      <td className="py-3.5 px-4 text-right font-mono text-xs font-bold">
                        <span className={hasDue ? 'text-rose-400' : 'text-emerald-400'}>
                          {formatCurrency(c.outstanding, settings.currency)}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {hasDue && (
                            <button
                              title="Record Payment"
                              onClick={() => {
                                setPayModalCustomer(c);
                                setPayAmount(c.outstanding);
                              }}
                              className="px-2 py-1 bg-emerald-950 hover:bg-emerald-900 border border-emerald-800 text-emerald-300 text-xs rounded-lg flex items-center gap-1 font-medium transition"
                            >
                              <DollarSign size={13} />
                              <span>Pay</span>
                            </button>
                          )}
                          <button
                            title="View Profile & Invoices"
                            onClick={() => openViewCustomer(c)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-cyan-300 hover:bg-slate-800 transition"
                          >
                            <Eye size={16} />
                          </button>
                          <button
                            title="Edit Customer"
                            onClick={() => openEditModal(c)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
                          >
                            <Edit2 size={16} />
                          </button>
                          <button
                            title="Delete Customer"
                            onClick={() => setDeleteConfirmId(c.id)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-slate-800 transition"
                          >
                            <Trash2 size={16} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Record Quick Payment Modal */}
      {payModalCustomer && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-6 space-y-4">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="text-lg font-bold text-white flex items-center gap-2">
                  <CreditCard className="text-emerald-400" size={20} />
                  <span>Receive Customer Payment</span>
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Customer: <span className="text-white font-semibold">{payModalCustomer.name}</span>
                </p>
                <p className="text-xs text-rose-400 font-mono mt-0.5">
                  Current Due: {formatCurrency(payModalCustomer.outstanding, settings.currency)}
                </p>
              </div>
              <button
                onClick={() => setPayModalCustomer(null)}
                className="text-slate-400 hover:text-white p-1"
              >
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleRecordPayment} className="space-y-3 text-xs sm:text-sm">
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-300">Payment Amount ({settings.currency}) *</label>
                <input
                  type="number"
                  step="0.001"
                  min="0.001"
                  required
                  value={payAmount}
                  onChange={e => setPayAmount(e.target.value === '' ? '' : Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-white font-mono text-sm focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-300">Payment Method</label>
                <select
                  value={payMethod}
                  onChange={e => setPayMethod(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:border-cyan-500"
                >
                  <option value="Cash">Cash</option>
                  <option value="K-Net / Card">K-Net / Debit Card</option>
                  <option value="Bank Transfer">Bank Transfer</option>
                  <option value="Cheque">Cheque</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-300">Reference / Notes</label>
                <input
                  type="text"
                  placeholder="Receipt #, Txn ID, Bank Reference"
                  value={payRef}
                  onChange={e => setPayRef(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-white text-xs focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div className="flex justify-end gap-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setPayModalCustomer(null)}
                  className="px-4 py-2 bg-slate-800 text-slate-300 rounded-xl text-xs font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-semibold transition cursor-pointer flex items-center gap-1.5"
                >
                  {saving && <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />}
                  <span>Confirm Receipt</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteConfirmId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-sm w-full p-6 space-y-4">
            <h3 className="text-lg font-bold text-white flex items-center gap-2 text-rose-400">
              <AlertTriangle size={20} />
              Confirm Delete Customer
            </h3>
            <p className="text-sm text-slate-300">
              Are you sure you want to delete this customer account? Historic invoices will remain recorded.
            </p>
            <div className="flex justify-end gap-3 pt-2">
              <button
                onClick={() => setDeleteConfirmId(null)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-sm font-medium rounded-xl transition"
              >
                Cancel
              </button>
              <button
                onClick={() => handleDelete(deleteConfirmId)}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white text-sm font-medium rounded-xl transition cursor-pointer"
              >
                Yes, Delete
              </button>
            </div>
          </div>
        </div>
      )}

      {/* View Customer Details Modal */}
      {viewCustomer && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-xs overflow-y-auto">
          <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl p-6 sm:p-7 space-y-5 my-8 max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-start border-b border-slate-800 pb-4">
              <div>
                <span className="text-xs font-mono text-cyan-400 font-semibold">{viewCustomer.code}</span>
                <h3 className="text-xl font-bold text-white">{viewCustomer.name}</h3>
                <div className="flex flex-wrap gap-4 text-xs text-slate-400 mt-1">
                  {viewCustomer.mobile && <span>Tel: {viewCustomer.mobile}</span>}
                  {viewCustomer.email && <span>Email: {viewCustomer.email}</span>}
                  {viewCustomer.address && <span>Address: {viewCustomer.address}</span>}
                </div>
              </div>
              <button onClick={closeViewCustomer} className="text-slate-400 hover:text-white p-1">
                <X size={20} />
              </button>
            </div>

            {/* Financial Summary */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800">
                <span className="text-xs text-slate-500 block">Opening Balance</span>
                <span className="font-mono text-sm text-slate-300">{formatCurrency(viewCustomer.openingBalance, settings.currency)}</span>
              </div>
              <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800">
                <span className="text-xs text-slate-500 block">Total Invoices</span>
                <span className="font-mono text-sm text-cyan-400 font-bold">{customerInvoices.length} orders</span>
              </div>
              <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 col-span-2 sm:col-span-1">
                <span className="text-xs text-slate-500 block">Outstanding Balance</span>
                <span className={`font-mono text-sm font-bold ${viewCustomer.outstanding > 0 ? 'text-rose-400' : 'text-emerald-400'}`}>
                  {formatCurrency(viewCustomer.outstanding, settings.currency)}
                </span>
              </div>
            </div>

            {/* Invoices History */}
            <div className="space-y-2">
              <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                <FileText size={14} className="text-cyan-400" />
                <span>Sales Invoices History ({customerInvoices.length})</span>
              </h4>
              {customerInvoices.length === 0 ? (
                <p className="text-xs text-slate-500 italic py-2">No invoices recorded yet for this customer.</p>
              ) : (
                <div className="border border-slate-800 rounded-xl overflow-hidden max-h-48 overflow-y-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-950 text-slate-400 border-b border-slate-800">
                      <tr>
                        <th className="p-2">Invoice #</th>
                        <th className="p-2">Date</th>
                        <th className="p-2 text-right">Total</th>
                        <th className="p-2 text-right">Balance</th>
                        <th className="p-2 text-center">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800">
                      {customerInvoices.map((inv: any) => (
                        <tr key={inv.id}>
                          <td className="p-2 font-mono text-cyan-400 font-semibold">{inv.invoiceNumber}</td>
                          <td className="p-2 text-slate-400">{formatDate(inv.date)}</td>
                          <td className="p-2 text-right font-mono">{formatCurrency(inv.total, settings.currency)}</td>
                          <td className="p-2 text-right font-mono text-rose-400">{formatCurrency(inv.outstanding, settings.currency)}</td>
                          <td className="p-2 text-center">
                            <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-950 border border-slate-800 text-slate-300">
                              {inv.paymentStatus || 'Paid'}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>

            {/* Payment Receipts History */}
            <div className="space-y-2">
              <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                <DollarSign size={14} className="text-emerald-400" />
                <span>Payment Receipts History ({customerPayments.length})</span>
              </h4>
              {customerPayments.length === 0 ? (
                <p className="text-xs text-slate-500 italic py-2">No separate payments recorded yet.</p>
              ) : (
                <div className="border border-slate-800 rounded-xl overflow-hidden max-h-40 overflow-y-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-950 text-slate-400 border-b border-slate-800">
                      <tr>
                        <th className="p-2">Date</th>
                        <th className="p-2">Method</th>
                        <th className="p-2">Reference</th>
                        <th className="p-2 text-right">Amount Received</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800">
                      {customerPayments.map((p: any) => (
                        <tr key={p.id}>
                          <td className="p-2 text-slate-400">{formatDate(p.date)}</td>
                          <td className="p-2 text-slate-300">{p.paymentMethod || 'Cash'}</td>
                          <td className="p-2 text-slate-500">{p.reference || '-'}</td>
                          <td className="p-2 text-right font-mono font-bold text-emerald-400">
                            {formatCurrency(p.amount, settings.currency)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>

            <div className="flex justify-end pt-2 border-t border-slate-800">
              <button
                onClick={closeViewCustomer}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold rounded-xl"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add / Edit Customer Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-xs overflow-y-auto">
          <div className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl p-6 sm:p-7 space-y-5 my-8">
            <div className="flex justify-between items-center border-b border-slate-800 pb-4">
              <h3 className="text-lg sm:text-xl font-bold text-white flex items-center gap-2">
                <Users className="text-cyan-400" size={22} />
                <span>{editingCustomer ? 'Edit Customer' : 'Add New Customer'}</span>
              </h3>
              <button onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:text-white p-1 rounded-lg">
                <X size={20} />
              </button>
            </div>

            {formError && (
              <div className="p-3 bg-rose-950/70 border border-rose-800 text-rose-300 text-xs rounded-xl flex items-center gap-2">
                <AlertTriangle size={16} />
                <span>{formError}</span>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4 text-xs sm:text-sm">
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-300">Customer / Company Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Al-Mansoor Trading Co."
                  value={name}
                  onChange={e => setName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-white text-sm focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-300">Mobile / Phone</label>
                  <input
                    type="text"
                    placeholder="+965 9988 7766"
                    value={mobile}
                    onChange={e => setMobile(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-white text-sm focus:outline-none focus:border-cyan-500 font-mono"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-300">Email Address</label>
                  <input
                    type="email"
                    placeholder="finance@almansoor.com"
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-white text-sm focus:outline-none focus:border-cyan-500"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-300">Billing Address</label>
                <input
                  type="text"
                  placeholder="Shuwaikh Industrial Area, Block 1, Street 4"
                  value={address}
                  onChange={e => setAddress(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-white text-sm focus:outline-none focus:border-cyan-500"
                />
              </div>

              {!editingCustomer && (
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-300">
                    Opening Balance ({settings.currency})
                  </label>
                  <input
                    type="number"
                    step="0.001"
                    min="0"
                    placeholder="0.000"
                    value={openingBalance}
                    onChange={e => setOpeningBalance(e.target.value === '' ? '' : Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-white text-sm focus:outline-none focus:border-cyan-500 font-mono"
                  />
                  <p className="text-[11px] text-slate-500">
                    Existing unpaid balance prior to using DataCore ERP.
                  </p>
                </div>
              )}

              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-300">Notes / Credit Terms</label>
                <textarea
                  rows={2}
                  placeholder="Payment terms, special discounts, credit limit..."
                  value={notes}
                  onChange={e => setNotes(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-white text-xs focus:outline-none focus:border-cyan-500 resize-none"
                />
              </div>

              <div className="flex justify-end gap-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-sm font-medium rounded-xl transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="px-5 py-2 bg-cyan-600 hover:bg-cyan-500 text-white text-sm font-medium rounded-xl transition cursor-pointer flex items-center gap-2 shadow-lg shadow-cyan-950 disabled:opacity-50"
                >
                  {saving && <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />}
                  <span>{editingCustomer ? 'Update Customer' : 'Save Customer'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
