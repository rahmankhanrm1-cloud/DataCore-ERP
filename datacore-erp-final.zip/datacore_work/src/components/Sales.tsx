import React, { useState, useEffect } from 'react';
import { db } from '../firebase';
import {
  collection,
  addDoc,
  getDocs,
  updateDoc,
  deleteDoc,
  doc,
  serverTimestamp,
  runTransaction
} from 'firebase/firestore';
import { SaleInvoice, Customer, Product, InvoiceItem, Settings } from '../types';
import { formatCurrency, generateCode, formatDate } from '../utils/formatters';
import { PrintInvoiceModal } from './PrintInvoiceModal';
import {
  FileText,
  Plus,
  Search,
  Printer,
  Trash2,
  Eye,
  AlertTriangle,
  X,
  PlusCircle,
  MinusCircle,
  CheckCircle,
  Clock,
  User,
  Package,
  Calendar,
  DollarSign
} from 'lucide-react';

interface SalesProps {
  settings: Settings;
  onNavigateToCustomers?: () => void;
  onNavigateToInventory?: () => void;
}

export const Sales: React.FC<SalesProps> = ({
  settings,
  onNavigateToCustomers,
  onNavigateToInventory,
}) => {
  const [sales, setSales] = useState<SaleInvoice[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');

  // Form View State
  const [isCreating, setIsCreating] = useState(false);
  const [editingSale, setEditingSale] = useState<SaleInvoice | null>(null);
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  // Invoice Print / View State
  const [printInvoice, setPrintInvoice] = useState<SaleInvoice | null>(null);
  const [viewInvoice, setViewInvoice] = useState<SaleInvoice | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  // Form Fields
  const [selectedCustomerId, setSelectedCustomerId] = useState('');
  const [invoiceDate, setInvoiceDate] = useState(new Date().toISOString().slice(0, 10));
  const [dueDate, setDueDate] = useState('');
  const [items, setItems] = useState<InvoiceItem[]>([]);
  const [paidAmount, setPaidAmount] = useState<number | ''>(0);
  const [notes, setNotes] = useState('');

  const loadData = async () => {
    try {
      setLoading(true);
      const [sSnap, cSnap, pSnap] = await Promise.all([
        getDocs(collection(db, 'sales')),
        getDocs(collection(db, 'customers')),
        getDocs(collection(db, 'products')),
      ]);

      const sList: SaleInvoice[] = sSnap.docs.map(d => ({ id: d.id, ...d.data() } as SaleInvoice));
      sList.sort((a, b) => (b.invoiceNumber || '').localeCompare(a.invoiceNumber || ''));
      setSales(sList);

      setCustomers(cSnap.docs.map(d => ({ id: d.id, ...d.data() } as Customer)));
      setProducts(pSnap.docs.map(d => ({ id: d.id, ...d.data() } as Product)));
    } catch (err) {
      console.error('Error loading sales data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const openNewSale = () => {
    setEditingSale(null);
    setSelectedCustomerId(customers[0]?.id || '');
    setInvoiceDate(new Date().toISOString().slice(0, 10));
    setDueDate('');
    setNotes('');
    setFormError(null);

    // Initial item row
    if (products.length > 0) {
      const p = products[0];
      setItems([
        {
          productId: p.id,
          productName: p.name,
          sku: p.sku || p.code,
          availableStock: p.stock,
          quantity: 1,
          unitPrice: p.sellingPrice || 0,
          discount: 0,
          tax: 0,
          lineTotal: p.sellingPrice || 0,
        },
      ]);
      setPaidAmount(p.sellingPrice || 0);
    } else {
      setItems([]);
      setPaidAmount(0);
    }
    setIsCreating(true);
  };

  const openEditSale = (s: SaleInvoice) => {
    setEditingSale(s);
    setSelectedCustomerId(s.customerId);
    setInvoiceDate(s.date || new Date().toISOString().slice(0, 10));
    setDueDate(s.dueDate || '');
    setItems(s.items.map(it => ({ ...it })));
    setPaidAmount(s.paid);
    setNotes(s.notes || '');
    setFormError(null);
    setIsCreating(true);
  };

  // Add Item to sale form
  const handleAddItem = () => {
    if (products.length === 0) return;
    const p = products[0];
    setItems(prev => [
      ...prev,
      {
        productId: p.id,
        productName: p.name,
        sku: p.sku || p.code,
        availableStock: p.stock,
        quantity: 1,
        unitPrice: p.sellingPrice || 0,
        discount: 0,
        tax: 0,
        lineTotal: p.sellingPrice || 0,
      },
    ]);
  };

  const handleRemoveItem = (idx: number) => {
    setItems(prev => prev.filter((_, i) => i !== idx));
  };

  const handleProductChange = (idx: number, productId: string) => {
    const prod = products.find(p => p.id === productId);
    if (!prod) return;
    setItems(prev => {
      const copy = [...prev];
      const cur = copy[idx];
      const qty = cur.quantity || 1;
      const price = prod.sellingPrice || 0;
      const sub = qty * price;
      const disc = cur.discount || 0;
      const tax = cur.tax || 0;
      const total = Math.max(0, sub - disc + tax);
      copy[idx] = {
        ...cur,
        productId: prod.id,
        productName: prod.name,
        sku: prod.sku || prod.code,
        availableStock: prod.stock,
        unitPrice: price,
        lineTotal: total,
      };
      return copy;
    });
  };

  const handleItemFieldChange = (
    idx: number,
    field: 'quantity' | 'unitPrice' | 'discount' | 'tax',
    val: number
  ) => {
    setItems(prev => {
      const copy = [...prev];
      const item = { ...copy[idx], [field]: val };
      const sub = (item.quantity || 0) * (item.unitPrice || 0);
      const disc = item.discount || 0;
      const tax = item.tax || 0;
      item.lineTotal = Math.max(0, sub - disc + tax);
      copy[idx] = item;
      return copy;
    });
  };

  // Totals calculations
  const subtotal = items.reduce((acc, it) => acc + (it.quantity || 0) * (it.unitPrice || 0), 0);
  const totalDiscount = items.reduce((acc, it) => acc + (it.discount || 0), 0);
  const totalTax = items.reduce((acc, it) => acc + (it.tax || 0), 0);
  const grandTotal = Math.max(0, subtotal - totalDiscount + totalTax);
  const paid = typeof paidAmount === 'number' ? paidAmount : 0;
  const outstanding = Math.max(0, grandTotal - paid);

  let paymentStatus: 'Paid' | 'Partially Paid' | 'Unpaid' = 'Unpaid';
  if (paid >= grandTotal && grandTotal > 0) {
    paymentStatus = 'Paid';
  } else if (paid > 0 && paid < grandTotal) {
    paymentStatus = 'Partially Paid';
  }

  const handleSaveSale = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    if (!selectedCustomerId) {
      setFormError('Please select a customer for this sale invoice.');
      return;
    }
    if (items.length === 0) {
      setFormError('Please add at least one product item to the invoice.');
      return;
    }

    // Client-side quick validation: positive quantities
    const totalQtyByProduct = new Map<string, number>();
    for (const it of items) {
      if (it.quantity <= 0) {
        setFormError(`Quantity for "${it.productName}" must be greater than zero.`);
        return;
      }
      totalQtyByProduct.set(it.productId, (totalQtyByProduct.get(it.productId) || 0) + it.quantity);
    }

    // Quick client-side check for new sales against client stock cache
    if (!editingSale && !settings.allowNegativeStock) {
      for (const [pid, reqQty] of totalQtyByProduct.entries()) {
        const prod = products.find(p => p.id === pid);
        if (prod && reqQty > prod.stock) {
          setFormError(
            `Insufficient Stock: Only ${prod.stock} available for "${prod.name}". Total requested across rows: ${reqQty}.`
          );
          return;
        }
      }
    }

    const customer = customers.find(c => c.id === selectedCustomerId);
    if (!customer) {
      setFormError('Customer not found.');
      return;
    }

    setSaving(true);
    try {
      await runTransaction(db, async transaction => {
        // ================= 1. ALL READS FIRST =================
        let existingSaleData: SaleInvoice | null = null;
        let saleRef: any = null;
        if (editingSale) {
          saleRef = doc(db, 'sales', editingSale.id);
          const saleDoc = await transaction.get(saleRef);
          if (!saleDoc.exists()) {
            throw new Error(`Sale invoice ${editingSale.invoiceNumber} no longer exists in database.`);
          }
          existingSaleData = saleDoc.data() as SaleInvoice;
        }

        // Identify all affected product IDs (new items + old items if editing)
        const affectedProductIds = new Set<string>();
        for (const it of items) {
          if (it.productId) affectedProductIds.add(it.productId);
        }
        if (existingSaleData) {
          for (const oldIt of existingSaleData.items || []) {
            if (oldIt.productId) affectedProductIds.add(oldIt.productId);
          }
        }

        // Read all affected product documents
        const productDocsMap = new Map<string, { ref: any; doc: any }>();
        for (const pid of affectedProductIds) {
          const pRef = doc(db, 'products', pid);
          const pDoc = await transaction.get(pRef);
          productDocsMap.set(pid, { ref: pRef, doc: pDoc });
        }

        // Identify all affected customer IDs (new customer + old customer if changed)
        const affectedCustomerIds = new Set<string>();
        affectedCustomerIds.add(selectedCustomerId);
        if (existingSaleData && existingSaleData.customerId) {
          affectedCustomerIds.add(existingSaleData.customerId);
        }

        // Read all affected customer documents
        const customerDocsMap = new Map<string, { ref: any; doc: any }>();
        for (const cid of affectedCustomerIds) {
          const cRef = doc(db, 'customers', cid);
          const cDoc = await transaction.get(cRef);
          customerDocsMap.set(cid, { ref: cRef, doc: cDoc });
        }

        // ================= 2. VALIDATION & CALCULATIONS (SNAPSHOT-BASED) =================
        // Validate new customer exists
        const newCustEntry = customerDocsMap.get(selectedCustomerId);
        if (!newCustEntry || !newCustEntry.doc.exists()) {
          throw new Error('Customer no longer exists in database.');
        }

        // Validate old customer exists if changed
        let oldCustEntry: { ref: any; doc: any } | null = null;
        if (existingSaleData && existingSaleData.customerId !== selectedCustomerId) {
          oldCustEntry = customerDocsMap.get(existingSaleData.customerId) || null;
          if (!oldCustEntry || !oldCustEntry.doc.exists()) {
            throw new Error('Original customer no longer exists in database.');
          }
        }

        // Aggregate quantities per product across all item rows
        const newQtyByProduct = new Map<string, number>();
        for (const it of items) {
          newQtyByProduct.set(it.productId, (newQtyByProduct.get(it.productId) || 0) + Number(it.quantity || 0));
        }

        const oldQtyByProduct = new Map<string, number>();
        if (existingSaleData) {
          for (const oldIt of existingSaleData.items || []) {
            oldQtyByProduct.set(oldIt.productId, (oldQtyByProduct.get(oldIt.productId) || 0) + Number(oldIt.quantity || 0));
          }
        }

        // Verify all affected products exist and calculate net stock changes
        const productFinalStocks = new Map<string, number>();
        for (const pid of affectedProductIds) {
          const pEntry = productDocsMap.get(pid);
          if (!pEntry || !pEntry.doc.exists()) {
            throw new Error(`Product with ID "${pid}" does not exist in database.`);
          }
          const curStock = Number(pEntry.doc.data().stock || 0);
          const oldQty = oldQtyByProduct.get(pid) || 0;
          const newQty = newQtyByProduct.get(pid) || 0;
          // Reversing old sale adds back oldQty, applying new sale subtracts newQty
          const finalStock = curStock + oldQty - newQty;

          if (!settings.allowNegativeStock && finalStock < 0) {
            const pName = pEntry.doc.data().name || pid;
            throw new Error(
              `Insufficient stock for "${pName}". Current stock: ${curStock}, net required: ${newQty - oldQty}. Resulting stock would be ${finalStock}.`
            );
          }
          productFinalStocks.set(pid, finalStock);
        }

        // Calculate customer balances from database snapshots
        const newCustCurrentBal = Number(newCustEntry.doc.data().outstanding || 0);
        let finalNewCustBal: number;
        let finalOldCustBal: number | null = null;

        if (!existingSaleData) {
          finalNewCustBal = newCustCurrentBal + outstanding;
        } else if (existingSaleData.customerId === selectedCustomerId) {
          const oldOutstanding = Number(existingSaleData.outstanding || 0);
          finalNewCustBal = newCustCurrentBal - oldOutstanding + outstanding;
        } else {
          const oldOutstanding = Number(existingSaleData.outstanding || 0);
          const oldCustCurrentBal = Number(oldCustEntry!.doc.data().outstanding || 0);
          finalOldCustBal = oldCustCurrentBal - oldOutstanding;
          finalNewCustBal = newCustCurrentBal + outstanding;
        }

        // ================= 3. ALL WRITES STAGED ATOMICALLY =================
        // Update product inventory stocks
        for (const [pid, finalStock] of productFinalStocks.entries()) {
          const pEntry = productDocsMap.get(pid)!;
          transaction.update(pEntry.ref, {
            stock: finalStock,
            updatedAt: serverTimestamp(),
          });
        }

        // Update customer balances
        transaction.update(newCustEntry.ref, {
          outstanding: finalNewCustBal,
          updatedAt: serverTimestamp(),
        });
        if (oldCustEntry && finalOldCustBal !== null) {
          transaction.update(oldCustEntry.ref, {
            outstanding: finalOldCustBal,
            updatedAt: serverTimestamp(),
          });
        }

        // Save invoice document
        const invoiceNumber = existingSaleData
          ? existingSaleData.invoiceNumber
          : generateCode(settings.invoicePrefix || 'INV', sales.length);

        const saleData = {
          invoiceNumber,
          customerId: selectedCustomerId,
          customerName: newCustEntry.doc.data().name || customer.name,
          customerMobile: newCustEntry.doc.data().mobile || customer.mobile || '',
          customerAddress: newCustEntry.doc.data().address || customer.address || '',
          date: invoiceDate,
          dueDate: dueDate || invoiceDate,
          items,
          subtotal,
          discount: totalDiscount,
          tax: totalTax,
          total: grandTotal,
          paid,
          outstanding,
          paymentStatus,
          notes: notes.trim(),
          updatedAt: serverTimestamp(),
        };

        if (existingSaleData) {
          transaction.update(saleRef, saleData);
        } else {
          const newSaleRef = doc(collection(db, 'sales'));
          transaction.set(newSaleRef, {
            ...saleData,
            createdAt: serverTimestamp(),
          });
        }
      });

      setIsCreating(false);
      setEditingSale(null);
      await loadData();
    } catch (err: any) {
      console.error('Error saving sale:', err);
      setFormError(err.message || 'Failed to complete sale transaction.');
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteSale = async (id: string) => {
    const saleToDelete = sales.find(s => s.id === id);
    if (!saleToDelete) return;

    try {
      await runTransaction(db, async transaction => {
        // 1. ALL READS FIRST
        const saleRef = doc(db, 'sales', id);
        const saleDoc = await transaction.get(saleRef);
        if (!saleDoc.exists()) {
          throw new Error('Sale invoice no longer exists in database.');
        }
        const saleData = saleDoc.data() as SaleInvoice;

        // Aggregate quantities per product
        const oldQtyByProduct = new Map<string, number>();
        for (const item of saleData.items || []) {
          oldQtyByProduct.set(item.productId, (oldQtyByProduct.get(item.productId) || 0) + Number(item.quantity || 0));
        }

        // Read all product docs
        const productDocsMap = new Map<string, { ref: any; doc: any }>();
        for (const pid of oldQtyByProduct.keys()) {
          const pRef = doc(db, 'products', pid);
          const pDoc = await transaction.get(pRef);
          productDocsMap.set(pid, { ref: pRef, doc: pDoc });
        }

        // Read customer doc
        const cRef = doc(db, 'customers', saleData.customerId);
        const cDoc = await transaction.get(cRef);

        // 2. VALIDATION
        if (!cDoc.exists()) {
          throw new Error('Customer no longer exists in database.');
        }
        for (const pid of oldQtyByProduct.keys()) {
          const pEntry = productDocsMap.get(pid);
          if (!pEntry || !pEntry.doc.exists()) {
            throw new Error(`Product ${pid} no longer exists in database.`);
          }
        }

        // 3. ALL WRITES AFTER ALL READS
        // Reverse inventory stock deduction (add back sold quantities)
        for (const [pid, oldQty] of oldQtyByProduct.entries()) {
          const pEntry = productDocsMap.get(pid)!;
          const currentStock = Number(pEntry.doc.data().stock || 0);
          transaction.update(pEntry.ref, {
            stock: currentStock + oldQty,
            updatedAt: serverTimestamp(),
          });
        }

        // Reverse customer outstanding balance
        const currentBal = Number(cDoc.data().outstanding || 0);
        const saleOutstanding = Number(saleData.outstanding || 0);
        transaction.update(cRef, {
          outstanding: currentBal - saleOutstanding,
          updatedAt: serverTimestamp(),
        });

        // Delete the sale doc
        transaction.delete(saleRef);
      });

      setDeleteConfirmId(null);
      await loadData();
    } catch (err: any) {
      console.error('Error deleting sale:', err);
    }
  };

  const filteredSales = sales.filter(s => {
    const matchesSearch =
      s.invoiceNumber.toLowerCase().includes(search.toLowerCase()) ||
      s.customerName.toLowerCase().includes(search.toLowerCase());
    const matchesStatus = statusFilter === 'ALL' || s.paymentStatus === statusFilter;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-slate-900 border border-slate-800 p-4 sm:p-5 rounded-2xl">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-white flex items-center gap-2.5">
            <FileText className="text-cyan-400" size={26} />
            <span>Sales & Invoicing</span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 mt-0.5">
            Create customer invoices, manage stock deductions, and print professional billing documents.
          </p>
        </div>
        {!isCreating && (
          <button
            onClick={openNewSale}
            className="bg-cyan-600 hover:bg-cyan-500 text-white font-medium px-4 py-2.5 rounded-xl flex items-center gap-2 transition cursor-pointer text-sm shadow-lg shadow-cyan-950 w-full sm:w-auto justify-center"
          >
            <Plus size={18} />
            <span>New Sale Invoice</span>
          </button>
        )}
      </div>

      {/* Main View or Create Form */}
      {isCreating ? (
        /* ================= CREATE / EDIT SALE FORM ================= */
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-7 space-y-6 shadow-xl">
          <div className="flex justify-between items-center border-b border-slate-800 pb-4">
            <div>
              <span className="text-xs font-mono text-cyan-400 uppercase tracking-widest font-semibold">
                {editingSale ? editingSale.invoiceNumber : 'NEW SALE'}
              </span>
              <h3 className="text-lg sm:text-xl font-bold text-white mt-0.5">
                {editingSale ? 'Edit Sales Invoice' : 'Create Sales Invoice'}
              </h3>
            </div>
            <button
              onClick={() => setIsCreating(false)}
              className="text-slate-400 hover:text-white p-1 rounded-lg"
            >
              <X size={20} />
            </button>
          </div>

          {formError && (
            <div className="p-3 bg-rose-950/80 border border-rose-800 text-rose-300 text-xs rounded-xl flex items-center gap-2">
              <AlertTriangle size={16} className="shrink-0" />
              <span>{formError}</span>
            </div>
          )}

          <form onSubmit={handleSaveSale} className="space-y-6">
            {/* Top row: Customer, Invoice Date, Due Date */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-300 flex justify-between">
                  <span>Customer Account *</span>
                  {customers.length === 0 && (
                    <button
                      type="button"
                      onClick={onNavigateToCustomers}
                      className="text-cyan-400 hover:underline text-[11px]"
                    >
                      + Add Customer First
                    </button>
                  )}
                </label>
                {customers.length === 0 ? (
                  <div className="p-2.5 bg-amber-950/40 border border-amber-800/80 rounded-xl text-amber-300 text-xs flex items-center justify-between">
                    <span>No customers found</span>
                    <button
                      type="button"
                      onClick={onNavigateToCustomers}
                      className="text-cyan-400 font-medium hover:underline ml-2"
                    >
                      Create Customer
                    </button>
                  </div>
                ) : (
                  <select
                    required
                    value={selectedCustomerId}
                    onChange={e => setSelectedCustomerId(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-white text-sm focus:outline-none focus:border-cyan-500"
                  >
                    <option value="" disabled>
                      Select Customer
                    </option>
                    {customers.map(c => (
                      <option key={c.id} value={c.id}>
                        {c.name} ({c.code}) - Due: {formatCurrency(c.outstanding, settings.currency)}
                      </option>
                    ))}
                  </select>
                )}
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-300">Invoice Date</label>
                <input
                  type="date"
                  required
                  value={invoiceDate}
                  onChange={e => setInvoiceDate(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-white text-sm focus:outline-none focus:border-cyan-500 font-mono"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-300">Payment Due Date</label>
                <input
                  type="date"
                  value={dueDate}
                  onChange={e => setDueDate(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-white text-sm focus:outline-none focus:border-cyan-500 font-mono"
                />
              </div>
            </div>

            {/* Products Selector Table */}
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                  <Package size={14} className="text-cyan-400" />
                  <span>Invoice Product Items ({items.length})</span>
                </h4>
                {products.length === 0 ? (
                  <button
                    type="button"
                    onClick={onNavigateToInventory}
                    className="text-xs text-cyan-400 hover:underline"
                  >
                    + Add Product in Inventory
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={handleAddItem}
                    className="text-xs bg-slate-800 hover:bg-slate-750 text-cyan-300 border border-cyan-500/30 px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition cursor-pointer"
                  >
                    <PlusCircle size={14} />
                    <span>Add Item Line</span>
                  </button>
                )}
              </div>

              {products.length === 0 ? (
                <div className="p-4 bg-amber-950/40 border border-amber-800/80 rounded-xl text-amber-300 text-xs">
                  No products available in inventory. Please add products to inventory before creating sales.
                </div>
              ) : items.length === 0 ? (
                <div className="p-6 text-center border border-dashed border-slate-800 rounded-xl text-slate-500 text-xs">
                  No item lines added yet. Click &quot;Add Item Line&quot; above.
                </div>
              ) : (
                <div className="border border-slate-800 rounded-xl overflow-x-auto">
                  <table className="w-full text-left text-xs min-w-[700px]">
                    <thead className="bg-slate-950 text-slate-400 border-b border-slate-800 uppercase font-semibold">
                      <tr>
                        <th className="py-2.5 px-3">Product Item</th>
                        <th className="py-2.5 px-3 w-28 text-center">In Stock</th>
                        <th className="py-2.5 px-3 w-24 text-center">Quantity</th>
                        <th className="py-2.5 px-3 w-32 text-right">Unit Price</th>
                        <th className="py-2.5 px-3 w-24 text-right">Discount</th>
                        <th className="py-2.5 px-3 w-24 text-right">Tax</th>
                        <th className="py-2.5 px-3 w-32 text-right">Line Total</th>
                        <th className="py-2.5 px-2 w-10"></th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/80">
                      {items.map((item, idx) => {
                        const insufficient =
                          !settings.allowNegativeStock && item.quantity > item.availableStock;
                        return (
                          <tr key={idx} className="hover:bg-slate-950/30">
                            {/* Product Selector */}
                            <td className="p-2.5">
                              <select
                                value={item.productId}
                                onChange={e => handleProductChange(idx, e.target.value)}
                                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white text-xs focus:outline-none focus:border-cyan-500 font-medium"
                              >
                                {products.map(p => (
                                  <option key={p.id} value={p.id}>
                                    {p.name} ({p.sku || p.code}) - {p.stock} in stock
                                  </option>
                                ))}
                              </select>
                            </td>

                            {/* Stock Indicator */}
                            <td className="p-2.5 text-center font-mono">
                              <span
                                className={`px-2 py-0.5 rounded-md text-[11px] font-semibold ${
                                  item.availableStock <= 0
                                    ? 'bg-rose-950 text-rose-300 border border-rose-800'
                                    : 'bg-slate-950 text-slate-300 border border-slate-800'
                                }`}
                              >
                                {item.availableStock}
                              </span>
                            </td>

                            {/* Quantity */}
                            <td className="p-2.5">
                              <input
                                type="number"
                                min="1"
                                value={item.quantity}
                                onChange={e =>
                                  handleItemFieldChange(idx, 'quantity', Math.max(1, Number(e.target.value)))
                                }
                                className={`w-full bg-slate-950 border rounded-lg p-2 text-center text-xs font-mono font-bold text-white focus:outline-none ${
                                  insufficient
                                    ? 'border-rose-500 bg-rose-950/30 text-rose-300'
                                    : 'border-slate-800 focus:border-cyan-500'
                                }`}
                              />
                              {insufficient && (
                                <span className="text-[10px] text-rose-400 block text-center mt-0.5">
                                  Exceeds stock
                                </span>
                              )}
                            </td>

                            {/* Unit Price */}
                            <td className="p-2.5">
                              <input
                                type="number"
                                step="0.001"
                                min="0"
                                value={item.unitPrice}
                                onChange={e =>
                                  handleItemFieldChange(idx, 'unitPrice', Number(e.target.value))
                                }
                                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-right text-xs font-mono text-cyan-400 font-semibold focus:outline-none focus:border-cyan-500"
                              />
                            </td>

                            {/* Discount */}
                            <td className="p-2.5">
                              <input
                                type="number"
                                step="0.001"
                                min="0"
                                value={item.discount}
                                onChange={e =>
                                  handleItemFieldChange(idx, 'discount', Number(e.target.value))
                                }
                                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-right text-xs font-mono text-slate-300 focus:outline-none focus:border-cyan-500"
                              />
                            </td>

                            {/* Tax */}
                            <td className="p-2.5">
                              <input
                                type="number"
                                step="0.001"
                                min="0"
                                value={item.tax}
                                onChange={e =>
                                  handleItemFieldChange(idx, 'tax', Number(e.target.value))
                                }
                                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-right text-xs font-mono text-slate-300 focus:outline-none focus:border-cyan-500"
                              />
                            </td>

                            {/* Line Total */}
                            <td className="p-2.5 text-right font-mono font-bold text-white">
                              {formatCurrency(item.lineTotal, settings.currency)}
                            </td>

                            {/* Remove button */}
                            <td className="p-2.5 text-center">
                              <button
                                type="button"
                                title="Remove line"
                                onClick={() => handleRemoveItem(idx)}
                                className="text-slate-500 hover:text-rose-400 p-1 transition"
                              >
                                <MinusCircle size={16} />
                              </button>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </div>

            {/* Bottom summary and payment section */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-2 border-t border-slate-800">
              <div className="space-y-3">
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-300">Invoice Notes / Terms</label>
                  <textarea
                    rows={3}
                    placeholder="Goods sold are eligible for replacement within 14 days with original receipt..."
                    value={notes}
                    onChange={e => setNotes(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-white text-xs focus:outline-none focus:border-cyan-500 resize-none"
                  />
                </div>
              </div>

              {/* Financial Calculation Summary Card */}
              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2 text-xs font-mono">
                <div className="flex justify-between text-slate-400">
                  <span>Subtotal:</span>
                  <span>{formatCurrency(subtotal, settings.currency)}</span>
                </div>
                {totalDiscount > 0 && (
                  <div className="flex justify-between text-slate-400">
                    <span>Discount:</span>
                    <span>- {formatCurrency(totalDiscount, settings.currency)}</span>
                  </div>
                )}
                {totalTax > 0 && (
                  <div className="flex justify-between text-slate-400">
                    <span>Tax:</span>
                    <span>+ {formatCurrency(totalTax, settings.currency)}</span>
                  </div>
                )}
                <div className="flex justify-between text-white font-bold text-sm pt-2 border-t border-slate-800">
                  <span>Grand Total:</span>
                  <span className="text-cyan-400">{formatCurrency(grandTotal, settings.currency)}</span>
                </div>

                <div className="pt-3 border-t border-slate-800 space-y-2">
                  <div className="flex items-center justify-between gap-3">
                    <span className="text-slate-300 font-semibold">Paid Amount ({settings.currency}):</span>
                    <input
                      type="number"
                      step="0.001"
                      min="0"
                      value={paidAmount}
                      onChange={e => setPaidAmount(e.target.value === '' ? '' : Number(e.target.value))}
                      className="w-36 bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-right font-bold text-emerald-400 focus:outline-none focus:border-cyan-500"
                    />
                  </div>
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-slate-400">Payment Status:</span>
                    <span
                      className={`px-2 py-0.5 rounded-full font-bold uppercase text-[10px] ${
                        paymentStatus === 'Paid'
                          ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                          : paymentStatus === 'Partially Paid'
                          ? 'bg-amber-950 text-amber-300 border border-amber-800'
                          : 'bg-rose-950 text-rose-300 border border-rose-800'
                      }`}
                    >
                      {paymentStatus}
                    </span>
                  </div>
                  <div className="flex justify-between items-center text-xs pt-1 border-t border-slate-800/80">
                    <span className="text-slate-400 font-semibold">Outstanding Due:</span>
                    <span className="text-rose-400 font-bold">
                      {formatCurrency(outstanding, settings.currency)}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Actions Bar */}
            <div className="flex justify-end gap-3 pt-4 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setIsCreating(false)}
                className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-sm font-medium transition"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={saving}
                className="px-6 py-2.5 bg-cyan-600 hover:bg-cyan-500 text-white rounded-xl text-sm font-semibold transition cursor-pointer flex items-center gap-2 shadow-lg shadow-cyan-950 disabled:opacity-50"
              >
                {saving && (
                  <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                )}
                <span>{editingSale ? 'Save Invoice Updates' : 'Complete Sale & Deduct Stock'}</span>
              </button>
            </div>
          </form>
        </div>
      ) : (
        /* ================= SALES HISTORY TABLE ================= */
        <div className="space-y-4">
          {/* Filters */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 bg-slate-900/70 border border-slate-800 p-3 sm:p-4 rounded-xl">
            <div className="relative">
              <Search size={18} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" />
              <input
                type="text"
                placeholder="Search invoice number or customer name..."
                value={search}
                onChange={e => setSearch(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-10 pr-4 py-2 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-cyan-500"
              />
            </div>
            <div>
              <select
                value={statusFilter}
                onChange={e => setStatusFilter(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2 text-white text-sm focus:outline-none focus:border-cyan-500"
              >
                <option value="ALL">All Payment Statuses</option>
                <option value="Paid">Fully Paid</option>
                <option value="Partially Paid">Partially Paid</option>
                <option value="Unpaid">Unpaid (Full Due)</option>
              </select>
            </div>
          </div>

          {loading ? (
            <div className="text-center py-16 bg-slate-900/50 border border-slate-800 rounded-2xl">
              <span className="inline-block w-8 h-8 border-3 border-cyan-400 border-t-transparent rounded-full animate-spin" />
              <p className="text-slate-400 text-sm mt-3">Loading sales records...</p>
            </div>
          ) : filteredSales.length === 0 ? (
            <div className="text-center py-14 bg-slate-900/40 border border-slate-800 rounded-2xl space-y-3">
              <FileText className="mx-auto text-slate-600" size={44} />
              <p className="text-slate-300 font-medium text-base">No sales invoices found</p>
              <p className="text-slate-500 text-xs max-w-sm mx-auto">
                {search || statusFilter !== 'ALL'
                  ? 'No invoices match your search filters.'
                  : 'Start issuing invoices to clients to record revenue and automatically adjust stock levels.'}
              </p>
              <button
                onClick={openNewSale}
                className="mt-2 bg-slate-800 hover:bg-slate-750 text-cyan-400 border border-cyan-500/30 px-4 py-2 rounded-xl text-sm font-medium transition cursor-pointer"
              >
                + Create First Sale
              </button>
            </div>
          ) : (
            <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-sm">
                  <thead className="bg-slate-950/80 text-slate-400 border-b border-slate-800 text-xs uppercase tracking-wider">
                    <tr>
                      <th className="py-3 px-4">Invoice #</th>
                      <th className="py-3 px-4">Date</th>
                      <th className="py-3 px-4">Customer</th>
                      <th className="py-3 px-4 text-center">Items</th>
                      <th className="py-3 px-4 text-right">Grand Total</th>
                      <th className="py-3 px-4 text-right">Paid</th>
                      <th className="py-3 px-4 text-right">Balance Due</th>
                      <th className="py-3 px-4 text-center">Status</th>
                      <th className="py-3 px-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60 text-slate-200">
                    {filteredSales.map(s => (
                      <tr key={s.id} className="hover:bg-slate-800/40 transition">
                        <td className="py-3.5 px-4 font-mono text-xs font-bold text-cyan-300">
                          {s.invoiceNumber}
                        </td>
                        <td className="py-3.5 px-4 text-slate-400 text-xs font-mono">
                          {formatDate(s.date)}
                        </td>
                        <td className="py-3.5 px-4 font-medium text-white max-w-[180px] truncate">
                          {s.customerName}
                        </td>
                        <td className="py-3.5 px-4 text-center text-xs font-mono text-slate-400">
                          {s.items?.length || 0}
                        </td>
                        <td className="py-3.5 px-4 text-right font-mono text-xs font-bold text-white">
                          {formatCurrency(s.total, settings.currency)}
                        </td>
                        <td className="py-3.5 px-4 text-right font-mono text-xs text-emerald-400">
                          {formatCurrency(s.paid, settings.currency)}
                        </td>
                        <td className="py-3.5 px-4 text-right font-mono text-xs font-semibold text-rose-400">
                          {formatCurrency(s.outstanding, settings.currency)}
                        </td>
                        <td className="py-3.5 px-4 text-center">
                          <span
                            className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                              s.paymentStatus === 'Paid'
                                ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-800'
                                : s.paymentStatus === 'Partially Paid'
                                ? 'bg-amber-950/80 text-amber-300 border border-amber-800'
                                : 'bg-rose-950/80 text-rose-300 border border-rose-800'
                            }`}
                          >
                            {s.paymentStatus}
                          </span>
                        </td>
                        <td className="py-3.5 px-4 text-right">
                          <div className="flex items-center justify-end gap-1">
                            <button
                              title="Print Invoice"
                              onClick={() => setPrintInvoice(s)}
                              className="p-1.5 rounded-lg text-slate-400 hover:text-cyan-300 hover:bg-slate-800 transition"
                            >
                              <Printer size={16} />
                            </button>
                            <button
                              title="Edit Sale"
                              onClick={() => openEditSale(s)}
                              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
                            >
                              <Eye size={16} />
                            </button>
                            <button
                              title="Delete Invoice & Restore Stock"
                              onClick={() => setDeleteConfirmId(s.id)}
                              className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-slate-800 transition"
                            >
                              <Trash2 size={16} />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteConfirmId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-sm w-full p-6 space-y-4">
            <h3 className="text-lg font-bold text-white flex items-center gap-2 text-rose-400">
              <AlertTriangle size={20} />
              Confirm Delete Invoice
            </h3>
            <p className="text-sm text-slate-300">
              Deleting this invoice will automatically <strong className="text-white">restore the sold product quantities</strong> back into inventory and reverse customer outstanding dues.
            </p>
            <div className="flex justify-end gap-3 pt-2">
              <button
                onClick={() => setDeleteConfirmId(null)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-sm font-medium rounded-xl transition"
              >
                Cancel
              </button>
              <button
                onClick={() => handleDeleteSale(deleteConfirmId)}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white text-sm font-medium rounded-xl transition cursor-pointer"
              >
                Yes, Reverse & Delete
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Printable Invoice Modal */}
      {printInvoice && (
        <PrintInvoiceModal
          type="sale"
          data={printInvoice}
          settings={settings}
          onClose={() => setPrintInvoice(null)}
        />
      )}
    </div>
  );
};
