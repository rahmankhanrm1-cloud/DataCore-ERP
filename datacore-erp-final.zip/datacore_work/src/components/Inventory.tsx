import React, { useState, useEffect } from 'react';
import { db } from '../firebase';
import { collection, addDoc, getDocs, updateDoc, deleteDoc, doc, serverTimestamp } from 'firebase/firestore';
import { Product, Settings } from '../types';
import { formatCurrency, generateCode } from '../utils/formatters';
import {
  Plus,
  Search,
  Edit2,
  Trash2,
  Package,
  AlertTriangle,
  XCircle,
  CheckCircle,
  Eye,
  Filter,
  X,
  Boxes
} from 'lucide-react';

interface InventoryProps {
  settings: Settings;
}

export const Inventory: React.FC<InventoryProps> = ({ settings }) => {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('ALL');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [viewProduct, setViewProduct] = useState<Product | null>(null);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [saving, setSaving] = useState(false);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  // Form State
  const [name, setName] = useState('');
  const [sku, setSku] = useState('');
  const [barcode, setBarcode] = useState('');
  const [category, setCategory] = useState('General');
  const [unit, setUnit] = useState('pcs');
  const [purchasePrice, setPurchasePrice] = useState<number | ''>(0);
  const [sellingPrice, setSellingPrice] = useState<number | ''>(0);
  const [openingStock, setOpeningStock] = useState<number | ''>(0);
  const [stock, setStock] = useState<number | ''>(0);
  const [minStock, setMinStock] = useState<number | ''>(settings.lowStockThreshold || 5);
  const [description, setDescription] = useState('');
  const [formError, setFormError] = useState<string | null>(null);

  const fetchProducts = async () => {
    try {
      setLoading(true);
      const snap = await getDocs(collection(db, 'products'));
      const list: Product[] = snap.docs.map(d => {
        const data = d.data();
        return {
          id: d.id,
          code: data.code || `PRD-${d.id.slice(0, 5).toUpperCase()}`,
          name: data.name || 'Unnamed Product',
          sku: data.sku || '-',
          barcode: data.barcode || '',
          category: data.category || 'General',
          unit: data.unit || 'pcs',
          purchasePrice: Number(data.purchasePrice || 0),
          sellingPrice: Number(data.sellingPrice || 0),
          openingStock: Number(data.openingStock || 0),
          stock: Number(data.stock || 0),
          minStock: Number(data.minStock || 5),
          description: data.description || '',
          createdAt: data.createdAt?.toDate ? data.createdAt.toDate().toISOString() : data.createdAt,
        };
      });
      // Sort newest first
      list.sort((a, b) => b.code.localeCompare(a.code));
      setProducts(list);
    } catch (err) {
      console.error('Error loading products:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  const openAddModal = () => {
    setEditingProduct(null);
    setName('');
    const newCode = generateCode('PRD', products.length);
    setSku(newCode);
    setBarcode('');
    setCategory('General');
    setUnit('pcs');
    setPurchasePrice(0);
    setSellingPrice(0);
    setOpeningStock(0);
    setStock(0);
    setMinStock(settings.lowStockThreshold || 5);
    setDescription('');
    setFormError(null);
    setIsModalOpen(true);
  };

  const openEditModal = (p: Product) => {
    setEditingProduct(p);
    setName(p.name);
    setSku(p.sku);
    setBarcode(p.barcode || '');
    setCategory(p.category || 'General');
    setUnit(p.unit || 'pcs');
    setPurchasePrice(p.purchasePrice);
    setSellingPrice(p.sellingPrice);
    setOpeningStock(p.openingStock);
    setStock(p.stock);
    setMinStock(p.minStock);
    setDescription(p.description || '');
    setFormError(null);
    setIsModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setFormError('Product Name is required.');
      return;
    }

    const pPrice = Number(purchasePrice) || 0;
    const sPrice = Number(sellingPrice) || 0;
    const curStock = Number(stock) || 0;
    const mStock = Number(minStock) || 0;
    const opStock = Number(openingStock) || 0;

    if (pPrice < 0 || sPrice < 0 || curStock < 0 || mStock < 0) {
      setFormError('Prices and stock values cannot be negative.');
      return;
    }

    setSaving(true);
    setFormError(null);
    try {
      if (editingProduct) {
        await updateDoc(doc(db, 'products', editingProduct.id), {
          name: name.trim(),
          sku: sku.trim(),
          barcode: barcode.trim(),
          category: category.trim(),
          unit: unit.trim(),
          purchasePrice: pPrice,
          sellingPrice: sPrice,
          stock: curStock,
          minStock: mStock,
          description: description.trim(),
          updatedAt: serverTimestamp(),
        });
      } else {
        const autoCode = generateCode('PRD', products.length);
        await addDoc(collection(db, 'products'), {
          code: autoCode,
          name: name.trim(),
          sku: sku.trim() || autoCode,
          barcode: barcode.trim(),
          category: category.trim(),
          unit: unit.trim(),
          purchasePrice: pPrice,
          sellingPrice: sPrice,
          openingStock: opStock || curStock,
          stock: curStock,
          minStock: mStock,
          description: description.trim(),
          createdAt: serverTimestamp(),
        });
      }
      setIsModalOpen(false);
      fetchProducts();
    } catch (err: any) {
      console.error('Error saving product:', err);
      setFormError(err.message || 'Failed to save product.');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await deleteDoc(doc(db, 'products', id));
      setDeleteConfirmId(null);
      fetchProducts();
    } catch (err) {
      console.error('Error deleting product:', err);
    }
  };

  // Categories list for filter
  const categories = ['ALL', ...Array.from(new Set(products.map(p => p.category || 'General')))];

  // Filter products
  const filteredProducts = products.filter(p => {
    const matchesSearch =
      p.name.toLowerCase().includes(search.toLowerCase()) ||
      p.sku.toLowerCase().includes(search.toLowerCase()) ||
      p.code.toLowerCase().includes(search.toLowerCase());

    const matchesCategory = categoryFilter === 'ALL' || p.category === categoryFilter;

    let matchesStatus = true;
    if (statusFilter === 'OUT_OF_STOCK') {
      matchesStatus = p.stock <= 0;
    } else if (statusFilter === 'LOW_STOCK') {
      matchesStatus = p.stock > 0 && p.stock <= p.minStock;
    } else if (statusFilter === 'IN_STOCK') {
      matchesStatus = p.stock > p.minStock;
    }

    return matchesSearch && matchesCategory && matchesStatus;
  });

  return (
    <div className="space-y-6">
      {/* Top action & metrics bar */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-slate-900 border border-slate-800 p-4 sm:p-5 rounded-2xl">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-white flex items-center gap-2.5">
            <Boxes className="text-cyan-400" size={26} />
            <span>Inventory Management</span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 mt-0.5">
            Track product catalog, stock levels, reorder thresholds, and valuations.
          </p>
        </div>
        <button
          onClick={openAddModal}
          className="bg-cyan-600 hover:bg-cyan-500 text-white font-medium px-4 py-2.5 rounded-xl flex items-center gap-2 transition cursor-pointer text-sm shadow-lg shadow-cyan-950 w-full sm:w-auto justify-center"
        >
          <Plus size={18} />
          <span>Add Product</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 bg-slate-900/70 border border-slate-800 p-3 sm:p-4 rounded-xl">
        {/* Search Input */}
        <div className="relative">
          <Search size={18} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" />
          <input
            type="text"
            placeholder="Search by name, SKU, code..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-10 pr-4 py-2 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-cyan-500"
          />
        </div>

        {/* Category Filter */}
        <div className="relative">
          <Filter size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" />
          <select
            value={categoryFilter}
            onChange={e => setCategoryFilter(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-4 py-2 text-white text-sm focus:outline-none focus:border-cyan-500"
          >
            {categories.map(c => (
              <option key={c} value={c}>
                Category: {c}
              </option>
            ))}
          </select>
        </div>

        {/* Stock Status Filter */}
        <div>
          <select
            value={statusFilter}
            onChange={e => setStatusFilter(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2 text-white text-sm focus:outline-none focus:border-cyan-500"
          >
            <option value="ALL">All Stock Statuses</option>
            <option value="IN_STOCK">In Stock (Good)</option>
            <option value="LOW_STOCK">Low Stock (Alert)</option>
            <option value="OUT_OF_STOCK">Out of Stock (Zero)</option>
          </select>
        </div>
      </div>

      {/* Product List Table / Cards */}
      {loading ? (
        <div className="text-center py-16 bg-slate-900/50 border border-slate-800 rounded-2xl">
          <span className="inline-block w-8 h-8 border-3 border-cyan-400 border-t-transparent rounded-full animate-spin" />
          <p className="text-slate-400 text-sm mt-3">Loading inventory catalog...</p>
        </div>
      ) : filteredProducts.length === 0 ? (
        <div className="text-center py-14 bg-slate-900/40 border border-slate-800 rounded-2xl space-y-3">
          <Package className="mx-auto text-slate-600" size={44} />
          <p className="text-slate-300 font-medium text-base">No inventory products found</p>
          <p className="text-slate-500 text-xs max-w-sm mx-auto">
            {search || categoryFilter !== 'ALL' || statusFilter !== 'ALL'
              ? 'Try adjusting your filters or search keywords.'
              : 'Add your first product to start tracking stock, sales, and purchases.'}
          </p>
          <button
            onClick={openAddModal}
            className="mt-2 bg-slate-800 hover:bg-slate-750 text-cyan-400 border border-cyan-500/30 px-4 py-2 rounded-xl text-sm font-medium transition cursor-pointer"
          >
            + Create Product Now
          </button>
        </div>
      ) : (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-slate-950/80 text-slate-400 border-b border-slate-800 text-xs uppercase tracking-wider">
                <tr>
                  <th className="py-3 px-4">Code / SKU</th>
                  <th className="py-3 px-4">Product Name</th>
                  <th className="py-3 px-4">Category</th>
                  <th className="py-3 px-4 text-right">Cost Price</th>
                  <th className="py-3 px-4 text-right">Sale Price</th>
                  <th className="py-3 px-4 text-center">Current Stock</th>
                  <th className="py-3 px-4 text-center">Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-slate-200">
                {filteredProducts.map(p => {
                  const isOut = p.stock <= 0;
                  const isLow = !isOut && p.stock <= p.minStock;

                  return (
                    <tr key={p.id} className="hover:bg-slate-800/40 transition">
                      <td className="py-3.5 px-4 font-mono text-xs">
                        <span className="font-semibold text-cyan-300">{p.code}</span>
                        {p.sku && p.sku !== p.code && (
                          <span className="block text-[11px] text-slate-500">SKU: {p.sku}</span>
                        )}
                      </td>
                      <td className="py-3.5 px-4 font-medium text-white max-w-[200px] truncate">
                        {p.name}
                      </td>
                      <td className="py-3.5 px-4 text-slate-400 text-xs">
                        <span className="bg-slate-950 px-2 py-0.5 rounded-md border border-slate-800">
                          {p.category}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-right font-mono text-xs text-slate-300">
                        {formatCurrency(p.purchasePrice, settings.currency)}
                      </td>
                      <td className="py-3.5 px-4 text-right font-mono text-xs font-semibold text-cyan-400">
                        {formatCurrency(p.sellingPrice, settings.currency)}
                      </td>
                      <td className="py-3.5 px-4 text-center font-bold">
                        <span className="font-mono">{p.stock}</span>{' '}
                        <span className="text-[11px] text-slate-500 font-normal">{p.unit}</span>
                      </td>
                      <td className="py-3.5 px-4 text-center">
                        {isOut ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-rose-950/80 text-rose-300 border border-rose-800">
                            <XCircle size={12} /> Out of Stock
                          </span>
                        ) : isLow ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-amber-950/80 text-amber-300 border border-amber-800">
                            <AlertTriangle size={12} /> Low Stock (&le;{p.minStock})
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-950/80 text-emerald-300 border border-emerald-800">
                            <CheckCircle size={12} /> In Stock
                          </span>
                        )}
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            title="View Details"
                            onClick={() => setViewProduct(p)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-cyan-300 hover:bg-slate-800 transition"
                          >
                            <Eye size={16} />
                          </button>
                          <button
                            title="Edit Product"
                            onClick={() => openEditModal(p)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
                          >
                            <Edit2 size={16} />
                          </button>
                          <button
                            title="Delete Product"
                            onClick={() => setDeleteConfirmId(p.id)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-slate-800 transition"
                          >
                            <Trash2 size={16} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteConfirmId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-sm w-full p-6 space-y-4">
            <h3 className="text-lg font-bold text-white flex items-center gap-2 text-rose-400">
              <AlertTriangle size={20} />
              Confirm Delete Product
            </h3>
            <p className="text-sm text-slate-300">
              Are you sure you want to delete this product from inventory? This action cannot be undone.
            </p>
            <div className="flex justify-end gap-3 pt-2">
              <button
                onClick={() => setDeleteConfirmId(null)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-sm font-medium rounded-xl transition"
              >
                Cancel
              </button>
              <button
                onClick={() => handleDelete(deleteConfirmId)}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white text-sm font-medium rounded-xl transition cursor-pointer"
              >
                Yes, Delete
              </button>
            </div>
          </div>
        </div>
      )}

      {/* View Product Modal */}
      {viewProduct && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-lg w-full p-6 space-y-5">
            <div className="flex justify-between items-start">
              <div>
                <span className="text-xs font-mono text-cyan-400 uppercase tracking-widest">
                  {viewProduct.code}
                </span>
                <h3 className="text-xl font-bold text-white mt-0.5">{viewProduct.name}</h3>
              </div>
              <button
                onClick={() => setViewProduct(null)}
                className="text-slate-400 hover:text-white p-1 rounded-lg"
              >
                <X size={20} />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs bg-slate-950 p-4 rounded-xl border border-slate-800">
              <div>
                <span className="text-slate-500 block">Category:</span>
                <span className="font-semibold text-slate-200">{viewProduct.category}</span>
              </div>
              <div>
                <span className="text-slate-500 block">SKU / Barcode:</span>
                <span className="font-mono text-slate-200">{viewProduct.sku || '-'}</span>
              </div>
              <div>
                <span className="text-slate-500 block">Cost Price:</span>
                <span className="font-mono text-slate-200">{formatCurrency(viewProduct.purchasePrice, settings.currency)}</span>
              </div>
              <div>
                <span className="text-slate-500 block">Selling Price:</span>
                <span className="font-mono text-cyan-400 font-bold">{formatCurrency(viewProduct.sellingPrice, settings.currency)}</span>
              </div>
              <div>
                <span className="text-slate-500 block">Current Stock:</span>
                <span className="font-mono font-bold text-white text-sm">{viewProduct.stock} {viewProduct.unit}</span>
              </div>
              <div>
                <span className="text-slate-500 block">Min Reorder Level:</span>
                <span className="font-mono text-slate-200">{viewProduct.minStock} {viewProduct.unit}</span>
              </div>
            </div>

            {viewProduct.description && (
              <div className="text-xs text-slate-400 bg-slate-950/60 p-3 rounded-xl border border-slate-800">
                <span className="text-slate-500 font-semibold block mb-1">Description:</span>
                {viewProduct.description}
              </div>
            )}

            <div className="flex justify-end pt-2">
              <button
                onClick={() => setViewProduct(null)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold rounded-xl"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add / Edit Product Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-xs overflow-y-auto">
          <div className="relative w-full max-w-xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl p-6 sm:p-7 space-y-5 my-8">
            <div className="flex justify-between items-center border-b border-slate-800 pb-4">
              <h3 className="text-lg sm:text-xl font-bold text-white flex items-center gap-2">
                <Package className="text-cyan-400" size={22} />
                <span>{editingProduct ? 'Edit Product' : 'Add New Product'}</span>
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg"
              >
                <X size={20} />
              </button>
            </div>

            {formError && (
              <div className="p-3 bg-rose-950/70 border border-rose-800 text-rose-300 text-xs rounded-xl flex items-center gap-2">
                <AlertTriangle size={16} />
                <span>{formError}</span>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4 text-xs sm:text-sm">
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-300">Product Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Wireless Barcode Scanner 2D"
                  value={name}
                  onChange={e => setName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-white text-sm focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-300">SKU / Product Code</label>
                  <input
                    type="text"
                    placeholder="PRD-00001"
                    value={sku}
                    onChange={e => setSku(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-white text-sm focus:outline-none focus:border-cyan-500 font-mono"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-300">Barcode (Optional)</label>
                  <input
                    type="text"
                    placeholder="628100001234"
                    value={barcode}
                    onChange={e => setBarcode(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-white text-sm focus:outline-none focus:border-cyan-500 font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-300">Category</label>
                  <input
                    type="text"
                    placeholder="e.g. Electronics, Hardware, Office"
                    value={category}
                    onChange={e => setCategory(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-white text-sm focus:outline-none focus:border-cyan-500"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-300">Unit of Measure</label>
                  <input
                    type="text"
                    placeholder="pcs, box, kg, meter"
                    value={unit}
                    onChange={e => setUnit(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-white text-sm focus:outline-none focus:border-cyan-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-300">
                    Purchase Cost Price ({settings.currency})
                  </label>
                  <input
                    type="number"
                    step="0.001"
                    min="0"
                    placeholder="0.000"
                    value={purchasePrice}
                    onChange={e => setPurchasePrice(e.target.value === '' ? '' : Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-white text-sm focus:outline-none focus:border-cyan-500 font-mono"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-300">
                    Selling Price ({settings.currency}) *
                  </label>
                  <input
                    type="number"
                    step="0.001"
                    min="0"
                    required
                    placeholder="0.000"
                    value={sellingPrice}
                    onChange={e => setSellingPrice(e.target.value === '' ? '' : Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-white text-sm focus:outline-none focus:border-cyan-500 font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-300">
                    {editingProduct ? 'Current Stock Quantity' : 'Initial Stock Quantity'}
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={stock}
                    onChange={e => setStock(e.target.value === '' ? '' : Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-white text-sm focus:outline-none focus:border-cyan-500 font-mono"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-300">
                    Low Stock Reorder Threshold
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={minStock}
                    onChange={e => setMinStock(e.target.value === '' ? '' : Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-white text-sm focus:outline-none focus:border-cyan-500 font-mono"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-300">Product Description (Optional)</label>
                <textarea
                  rows={2}
                  placeholder="Notes, specification, warranty details..."
                  value={description}
                  onChange={e => setDescription(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-white text-xs focus:outline-none focus:border-cyan-500 resize-none"
                />
              </div>

              <div className="flex justify-end gap-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-sm font-medium rounded-xl transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="px-5 py-2 bg-cyan-600 hover:bg-cyan-500 text-white text-sm font-medium rounded-xl transition cursor-pointer flex items-center gap-2 shadow-lg shadow-cyan-950 disabled:opacity-50"
                >
                  {saving && <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />}
                  <span>{editingProduct ? 'Update Product' : 'Save Product'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
