import React, { useState, useEffect } from 'react';
import { db } from '../firebase';
import {
  collection,
  addDoc,
  getDocs,
  deleteDoc,
  doc,
  serverTimestamp,
  runTransaction
} from 'firebase/firestore';
import { Expense, PaymentRecord, Customer, Supplier, SaleInvoice, PurchaseOrder, Settings } from '../types';
import { formatCurrency, formatDate } from '../utils/formatters';
import {
  Briefcase,
  Plus,
  Search,
  DollarSign,
  TrendingUp,
  TrendingDown,
  ArrowDownRight,
  ArrowUpRight,
  Wallet,
  Calendar,
  CreditCard,
  Trash2,
  AlertTriangle,
  X,
  FileSpreadsheet
} from 'lucide-react';

interface AccountsProps {
  settings: Settings;
  onNavigateToCustomers?: () => void;
  onNavigateToSuppliers?: () => void;
}

export const Accounts: React.FC<AccountsProps> = ({
  settings,
  onNavigateToCustomers,
  onNavigateToSuppliers,
}) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'expenses' | 'customer_pay' | 'supplier_pay'>('overview');
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [payments, setPayments] = useState<PaymentRecord[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [sales, setSales] = useState<SaleInvoice[]>([]);
  const [purchases, setPurchases] = useState<PurchaseOrder[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [search, setSearch] = useState('');

  // New Expense Form State
  const [isExpenseModalOpen, setIsExpenseModalOpen] = useState(false);
  const [expDate, setExpDate] = useState(new Date().toISOString().slice(0, 10));
  const [expCategory, setExpCategory] = useState('Office Supplies');
  const [expDesc, setExpDesc] = useState('');
  const [expAmount, setExpAmount] = useState<number | ''>('');
  const [expMethod, setExpMethod] = useState('Cash');
  const [expRef, setExpRef] = useState('');
  const [expNotes, setExpNotes] = useState('');
  const [formError, setFormError] = useState<string | null>(null);

  // Customer Payment Form State
  const [cpCustomerId, setCpCustomerId] = useState('');
  const [cpAmount, setCpAmount] = useState<number | ''>('');
  const [cpDate, setCpDate] = useState(new Date().toISOString().slice(0, 10));
  const [cpMethod, setCpMethod] = useState('Cash');
  const [cpRef, setCpRef] = useState('');
  const [cpNotes, setCpNotes] = useState('');

  // Supplier Payment Form State
  const [spSupplierId, setSpSupplierId] = useState('');
  const [spAmount, setSpAmount] = useState<number | ''>('');
  const [spDate, setSpDate] = useState(new Date().toISOString().slice(0, 10));
  const [spMethod, setSpMethod] = useState('Bank Transfer');
  const [spRef, setSpRef] = useState('');
  const [spNotes, setSpNotes] = useState('');

  const loadAccountsData = async () => {
    try {
      setLoading(true);
      const [eSnap, paySnap, cSnap, sSnap, saleSnap, puSnap] = await Promise.all([
        getDocs(collection(db, 'expenses')),
        getDocs(collection(db, 'payments')),
        getDocs(collection(db, 'customers')),
        getDocs(collection(db, 'suppliers')),
        getDocs(collection(db, 'sales')),
        getDocs(collection(db, 'purchases')),
      ]);

      const expList: Expense[] = eSnap.docs.map(d => ({ id: d.id, ...d.data() } as Expense));
      expList.sort((a, b) => (b.date || '').localeCompare(a.date || ''));
      setExpenses(expList);

      const payList: PaymentRecord[] = paySnap.docs.map(d => ({ id: d.id, ...d.data() } as PaymentRecord));
      payList.sort((a, b) => (b.date || '').localeCompare(a.date || ''));
      setPayments(payList);

      setCustomers(cSnap.docs.map(d => ({ id: d.id, ...d.data() } as Customer)));
      setSuppliers(sSnap.docs.map(d => ({ id: d.id, ...d.data() } as Supplier)));

      const sList: SaleInvoice[] = saleSnap.docs.map(d => ({ id: d.id, ...d.data() } as SaleInvoice));
      setSales(sList);

      const puList: PurchaseOrder[] = puSnap.docs.map(d => ({ id: d.id, ...d.data() } as PurchaseOrder));
      setPurchases(puList);
    } catch (err) {
      console.error('Error loading accounts data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadAccountsData();
  }, []);

  // Aggregated Cash Flow - each amount counted exactly once
  const salesCashIn = sales.reduce((acc, s) => acc + (Number(s.paid) || 0), 0);
  const customerPaymentsIn = payments
    .filter(p => p.type === 'customer_payment')
    .reduce((acc, p) => acc + (p.amount || 0), 0);

  const purchasesCashOut = purchases.reduce((acc, po) => acc + (Number(po.paid) || 0), 0);
  const supplierPaymentsOut = payments
    .filter(p => p.type === 'supplier_payment')
    .reduce((acc, p) => acc + (p.amount || 0), 0);

  const totalDirectExpenses = expenses.reduce((acc, e) => acc + (e.amount || 0), 0);

  const totalCashIn = salesCashIn + customerPaymentsIn;
  const totalCashOut = purchasesCashOut + supplierPaymentsOut + totalDirectExpenses;
  const netCashBalance = totalCashIn - totalCashOut;

  // Save Expense
  const handleSaveExpense = async (e: React.FormEvent) => {
    e.preventDefault();
    const amount = Number(expAmount);
    if (!amount || amount <= 0) {
      setFormError('Please enter a valid expense amount.');
      return;
    }
    if (!expDesc.trim()) {
      setFormError('Please provide a description for the expense.');
      return;
    }

    setSaving(true);
    setFormError(null);
    try {
      await addDoc(collection(db, 'expenses'), {
        date: expDate,
        category: expCategory,
        description: expDesc.trim(),
        amount,
        paymentMethod: expMethod,
        reference: expRef.trim(),
        notes: expNotes.trim(),
        createdAt: serverTimestamp(),
      });
      setIsExpenseModalOpen(false);
      setExpDesc('');
      setExpAmount('');
      setExpRef('');
      setExpNotes('');
      await loadAccountsData();
    } catch (err: any) {
      console.error('Error saving expense:', err);
      setFormError(err.message || 'Failed to save expense record.');
    } finally {
      setSaving(false);
    }
  };

  // Save Customer Payment Receipt
  const handleSaveCustomerPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!cpCustomerId) {
      setFormError('Please select a customer.');
      return;
    }
    const amount = Number(cpAmount);
    if (!amount || amount <= 0) {
      setFormError('Please enter a valid payment amount.');
      return;
    }

    const customer = customers.find(c => c.id === cpCustomerId);
    if (!customer) return;

    setSaving(true);
    setFormError(null);
    try {
      await runTransaction(db, async transaction => {
        const cRef = doc(db, 'customers', cpCustomerId);
        const cDoc = await transaction.get(cRef);
        if (!cDoc.exists()) throw new Error('Customer does not exist');
        const curBal = Number(cDoc.data().outstanding || 0);

        // Reduce customer outstanding balance
        transaction.update(cRef, {
          outstanding: Math.max(0, curBal - amount),
          updatedAt: serverTimestamp(),
        });

        // Record in payments
        const pRef = doc(collection(db, 'payments'));
        transaction.set(pRef, {
          type: 'customer_payment',
          partyId: cpCustomerId,
          partyName: customer.name,
          amount,
          date: cpDate,
          paymentMethod: cpMethod,
          reference: cpRef.trim(),
          notes: cpNotes.trim(),
          createdAt: serverTimestamp(),
        });
      });

      setCpAmount('');
      setCpRef('');
      setCpNotes('');
      setActiveTab('overview');
      await loadAccountsData();
    } catch (err: any) {
      console.error('Error recording customer payment:', err);
      setFormError(err.message || 'Transaction failed.');
    } finally {
      setSaving(false);
    }
  };

  // Save Supplier Payment Disbursement
  const handleSaveSupplierPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!spSupplierId) {
      setFormError('Please select a supplier.');
      return;
    }
    const amount = Number(spAmount);
    if (!amount || amount <= 0) {
      setFormError('Please enter a valid payment amount.');
      return;
    }

    const supplier = suppliers.find(s => s.id === spSupplierId);
    if (!supplier) return;

    setSaving(true);
    setFormError(null);
    try {
      await runTransaction(db, async transaction => {
        const sRef = doc(db, 'suppliers', spSupplierId);
        const sDoc = await transaction.get(sRef);
        if (!sDoc.exists()) throw new Error('Supplier does not exist');
        const curPayable = Number(sDoc.data().payable || 0);

        // Reduce supplier payable balance
        transaction.update(sRef, {
          payable: Math.max(0, curPayable - amount),
          updatedAt: serverTimestamp(),
        });

        // Record in payments
        const pRef = doc(collection(db, 'payments'));
        transaction.set(pRef, {
          type: 'supplier_payment',
          partyId: spSupplierId,
          partyName: supplier.name,
          amount,
          date: spDate,
          paymentMethod: spMethod,
          reference: spRef.trim(),
          notes: spNotes.trim(),
          createdAt: serverTimestamp(),
        });
      });

      setSpAmount('');
      setSpRef('');
      setSpNotes('');
      setActiveTab('overview');
      await loadAccountsData();
    } catch (err: any) {
      console.error('Error recording supplier payment:', err);
      setFormError(err.message || 'Transaction failed.');
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteExpense = async (id: string) => {
    try {
      await deleteDoc(doc(db, 'expenses', id));
      await loadAccountsData();
    } catch (err) {
      console.error('Error deleting expense:', err);
    }
  };

  // Compile unified transactions ledger for table
  interface UnifiedTxn {
    id: string;
    date: string;
    type: 'Sale Payment' | 'Customer Receipt' | 'Purchase Payment' | 'Supplier Paid' | 'Expense';
    partyOrDesc: string;
    reference: string;
    direction: 'IN' | 'OUT';
    amount: number;
    method: string;
  }

  const unifiedTransactions: UnifiedTxn[] = [
    // Direct payments recorded on sales invoices
    ...sales
      .filter(s => (Number(s.paid) || 0) > 0)
      .map(s => ({
        id: `sale-pay-${s.id}`,
        date: s.date,
        type: 'Sale Payment' as const,
        partyOrDesc: s.customerName,
        reference: s.invoiceNumber,
        direction: 'IN' as const,
        amount: Number(s.paid) || 0,
        method: (s as any).paymentMethod || (s as any).method || '-',
      })),
    // Separate customer receipts recorded in Accounts
    ...payments
      .filter(p => p.type === 'customer_payment')
      .map(p => ({
        id: p.id,
        date: p.date,
        type: 'Customer Receipt' as const,
        partyOrDesc: p.partyName,
        reference: p.reference || '-',
        direction: 'IN' as const,
        amount: p.amount,
        method: p.paymentMethod || '-',
      })),
    // Direct payments recorded on purchase orders
    ...purchases
      .filter(po => (Number(po.paid) || 0) > 0)
      .map(po => ({
        id: `po-pay-${po.id}`,
        date: po.date,
        type: 'Purchase Payment' as const,
        partyOrDesc: po.supplierName,
        reference: po.purchaseNumber,
        direction: 'OUT' as const,
        amount: Number(po.paid) || 0,
        method: (po as any).paymentMethod || (po as any).method || '-',
      })),
    // Separate supplier payments recorded in Accounts
    ...payments
      .filter(p => p.type === 'supplier_payment')
      .map(p => ({
        id: p.id,
        date: p.date,
        type: 'Supplier Paid' as const,
        partyOrDesc: p.partyName,
        reference: p.reference || '-',
        direction: 'OUT' as const,
        amount: p.amount,
        method: p.paymentMethod || '-',
      })),
    // Operational expenses
    ...expenses.map(e => ({
      id: e.id,
      date: e.date,
      type: 'Expense' as const,
      partyOrDesc: `${e.category}: ${e.description}`,
      reference: e.reference || '-',
      direction: 'OUT' as const,
      amount: e.amount,
      method: e.paymentMethod || '-',
    })),
  ];

  unifiedTransactions.sort((a, b) => (b.date || '').localeCompare(a.date || ''));

  const filteredTxns = unifiedTransactions.filter(t =>
    t.partyOrDesc.toLowerCase().includes(search.toLowerCase()) ||
    t.type.toLowerCase().includes(search.toLowerCase()) ||
    t.method.toLowerCase().includes(search.toLowerCase()) ||
    t.reference.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-slate-900 border border-slate-800 p-4 sm:p-5 rounded-2xl">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-white flex items-center gap-2.5">
            <Briefcase className="text-cyan-400" size={26} />
            <span>Accounts & Financial Ledger</span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 mt-0.5">
            Monitor cash inflows, operational expenses, customer receipts, and vendor disbursements.
          </p>
        </div>
        <div className="flex flex-wrap gap-2 w-full sm:w-auto">
          <button
            onClick={() => {
              setFormError(null);
              setIsExpenseModalOpen(true);
            }}
            className="bg-cyan-600 hover:bg-cyan-500 text-white font-medium px-3.5 py-2 rounded-xl flex items-center gap-1.5 transition cursor-pointer text-xs shadow-lg shadow-cyan-950"
          >
            <Plus size={16} />
            <span>Record Expense</span>
          </button>
        </div>
      </div>

      {/* Metrics Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Net Cash Balance */}
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Net Cash/Bank Balance</span>
            <Wallet size={16} className="text-cyan-400" />
          </div>
          <p className={`text-2xl font-extrabold font-mono ${netCashBalance >= 0 ? 'text-white' : 'text-rose-400'}`}>
            {formatCurrency(netCashBalance, settings.currency)}
          </p>
          <p className="text-[11px] text-slate-500">Live reconciliation of all transactions</p>
        </div>

        {/* Total Cash Inflows */}
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Total Cash In (Received)</span>
            <ArrowDownRight size={16} className="text-emerald-400" />
          </div>
          <p className="text-2xl font-extrabold font-mono text-emerald-400">
            {formatCurrency(totalCashIn, settings.currency)}
          </p>
          <p className="text-[11px] text-slate-500">Sales collections + client receipts</p>
        </div>

        {/* Total Cash Outflows */}
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Total Cash Out (Disbursed)</span>
            <ArrowUpRight size={16} className="text-amber-400" />
          </div>
          <p className="text-2xl font-extrabold font-mono text-amber-400">
            {formatCurrency(totalCashOut, settings.currency)}
          </p>
          <p className="text-[11px] text-slate-500">Purchases + supplier pay + expenses</p>
        </div>

        {/* Operating Expenses */}
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>Operating Expenses</span>
            <TrendingDown size={16} className="text-rose-400" />
          </div>
          <p className="text-2xl font-extrabold font-mono text-rose-400">
            {formatCurrency(totalDirectExpenses, settings.currency)}
          </p>
          <p className="text-[11px] text-slate-500">{expenses.length} expense entries recorded</p>
        </div>
      </div>

      {/* Tabs navigation */}
      <div className="flex gap-2 border-b border-slate-800 pb-2 overflow-x-auto text-xs sm:text-sm">
        <button
          onClick={() => setActiveTab('overview')}
          className={`px-4 py-2 rounded-xl font-medium transition cursor-pointer ${
            activeTab === 'overview'
              ? 'bg-cyan-950 text-cyan-300 border border-cyan-800'
              : 'text-slate-400 hover:text-white hover:bg-slate-900'
          }`}
        >
          Transaction Ledger ({unifiedTransactions.length})
        </button>
        <button
          onClick={() => setActiveTab('expenses')}
          className={`px-4 py-2 rounded-xl font-medium transition cursor-pointer ${
            activeTab === 'expenses'
              ? 'bg-cyan-950 text-cyan-300 border border-cyan-800'
              : 'text-slate-400 hover:text-white hover:bg-slate-900'
          }`}
        >
          Expense Book ({expenses.length})
        </button>
        <button
          onClick={() => setActiveTab('customer_pay')}
          className={`px-4 py-2 rounded-xl font-medium transition cursor-pointer ${
            activeTab === 'customer_pay'
              ? 'bg-cyan-950 text-cyan-300 border border-cyan-800'
              : 'text-slate-400 hover:text-white hover:bg-slate-900'
          }`}
        >
          + Receive Customer Payment
        </button>
        <button
          onClick={() => setActiveTab('supplier_pay')}
          className={`px-4 py-2 rounded-xl font-medium transition cursor-pointer ${
            activeTab === 'supplier_pay'
              ? 'bg-cyan-950 text-cyan-300 border border-cyan-800'
              : 'text-slate-400 hover:text-white hover:bg-slate-900'
          }`}
        >
          + Disburse Supplier Payment
        </button>
      </div>

      {/* TAB CONTENT */}
      {activeTab === 'overview' && (
        <div className="space-y-4">
          <div className="bg-slate-900/70 border border-slate-800 p-3 sm:p-4 rounded-xl">
            <div className="relative">
              <Search size={18} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" />
              <input
                type="text"
                placeholder="Search ledger by party, category, method..."
                value={search}
                onChange={e => setSearch(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-10 pr-4 py-2 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-cyan-500"
              />
            </div>
          </div>

          {loading ? (
            <div className="text-center py-16 bg-slate-900/50 border border-slate-800 rounded-2xl">
              <span className="inline-block w-8 h-8 border-3 border-cyan-400 border-t-transparent rounded-full animate-spin" />
              <p className="text-slate-400 text-sm mt-3">Loading financial transactions...</p>
            </div>
          ) : filteredTxns.length === 0 ? (
            <div className="text-center py-14 bg-slate-900/40 border border-slate-800 rounded-2xl space-y-2">
              <FileSpreadsheet className="mx-auto text-slate-600" size={40} />
              <p className="text-slate-300 font-medium text-sm">No transaction ledger entries recorded</p>
              <p className="text-slate-500 text-xs">
                Payments recorded from sales, purchases, or expenses will automatically stream here.
              </p>
            </div>
          ) : (
            <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-sm">
                  <thead className="bg-slate-950/80 text-slate-400 border-b border-slate-800 text-xs uppercase tracking-wider">
                    <tr>
                      <th className="py-3 px-4">Date</th>
                      <th className="py-3 px-4">Transaction Type</th>
                      <th className="py-3 px-4">Party / Description</th>
                      <th className="py-3 px-4">Reference</th>
                      <th className="py-3 px-4">Method</th>
                      <th className="py-3 px-4 text-right">Inflow (KWD)</th>
                      <th className="py-3 px-4 text-right">Outflow (KWD)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60 text-slate-200">
                    {filteredTxns.map((t, idx) => (
                      <tr key={t.id || idx} className="hover:bg-slate-800/40 transition">
                        <td className="py-3 px-4 font-mono text-xs text-slate-400">{formatDate(t.date)}</td>
                        <td className="py-3 px-4">
                          <span
                            className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider border ${
                              t.direction === 'IN'
                                ? 'bg-emerald-950/80 text-emerald-300 border-emerald-800'
                                : 'bg-amber-950/80 text-amber-300 border-amber-800'
                            }`}
                          >
                            {t.type}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-xs font-medium text-white max-w-[200px] truncate">
                          {t.partyOrDesc}
                        </td>
                        <td className="py-3 px-4 font-mono text-xs text-cyan-400">
                          {t.reference}
                        </td>
                        <td className="py-3 px-4 text-xs text-slate-400">{t.method}</td>
                        <td className="py-3 px-4 text-right font-mono text-xs font-bold text-emerald-400">
                          {t.direction === 'IN' ? `+ ${formatCurrency(t.amount, settings.currency)}` : '-'}
                        </td>
                        <td className="py-3 px-4 text-right font-mono text-xs font-bold text-rose-400">
                          {t.direction === 'OUT' ? `- ${formatCurrency(t.amount, settings.currency)}` : '-'}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {/* EXPENSES TAB */}
      {activeTab === 'expenses' && (
        <div className="space-y-4">
          <div className="flex justify-between items-center bg-slate-900 border border-slate-800 p-4 rounded-xl">
            <div>
              <h3 className="font-bold text-white text-base">Operating Expenses Book</h3>
              <p className="text-xs text-slate-400">Track and categorize daily overhead and business costs.</p>
            </div>
            <button
              onClick={() => {
                setFormError(null);
                setIsExpenseModalOpen(true);
              }}
              className="bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold px-3 py-2 rounded-xl flex items-center gap-1.5 transition"
            >
              <Plus size={16} />
              <span>Add Expense</span>
            </button>
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead className="bg-slate-950/80 text-slate-400 border-b border-slate-800 text-xs uppercase tracking-wider">
                  <tr>
                    <th className="py-3 px-4">Date</th>
                    <th className="py-3 px-4">Category</th>
                    <th className="py-3 px-4">Description</th>
                    <th className="py-3 px-4">Method & Ref</th>
                    <th className="py-3 px-4 text-right">Amount</th>
                    <th className="py-3 px-4 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 text-slate-200">
                  {expenses.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="text-center py-10 text-slate-500 text-xs">
                        No expenses recorded yet. Click &quot;Add Expense&quot; above to log overhead.
                      </td>
                    </tr>
                  ) : (
                    expenses.map(e => (
                      <tr key={e.id} className="hover:bg-slate-800/40">
                        <td className="py-3 px-4 font-mono text-xs text-slate-400">{formatDate(e.date)}</td>
                        <td className="py-3 px-4 text-xs">
                          <span className="bg-slate-950 px-2 py-0.5 rounded-md border border-slate-800 text-cyan-300">
                            {e.category}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-xs text-white max-w-[200px] truncate">{e.description}</td>
                        <td className="py-3 px-4 text-xs text-slate-400">
                          {e.paymentMethod} {e.reference ? `(${e.reference})` : ''}
                        </td>
                        <td className="py-3 px-4 text-right font-mono text-xs font-bold text-rose-400">
                          {formatCurrency(e.amount, settings.currency)}
                        </td>
                        <td className="py-3 px-4 text-right">
                          <button
                            title="Delete Expense"
                            onClick={() => handleDeleteExpense(e.id)}
                            className="p-1.5 text-slate-500 hover:text-rose-400 transition"
                          >
                            <Trash2 size={16} />
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* CUSTOMER PAYMENT TAB */}
      {activeTab === 'customer_pay' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 max-w-xl mx-auto space-y-4 shadow-xl">
          <h3 className="text-lg font-bold text-white flex items-center gap-2">
            <DollarSign className="text-emerald-400" size={20} />
            <span>Record Customer Payment Received</span>
          </h3>
          <p className="text-xs text-slate-400">
            Receiving money from a customer reduces their outstanding receivables balance and logs positive cash inflow.
          </p>

          {formError && (
            <div className="p-3 bg-rose-950/80 border border-rose-800 text-rose-300 text-xs rounded-xl flex items-center gap-2">
              <AlertTriangle size={16} />
              <span>{formError}</span>
            </div>
          )}

          <form onSubmit={handleSaveCustomerPayment} className="space-y-4 text-xs sm:text-sm">
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-300">Select Customer *</label>
              <select
                required
                value={cpCustomerId}
                onChange={e => {
                  setCpCustomerId(e.target.value);
                  const cust = customers.find(c => c.id === e.target.value);
                  if (cust && cust.outstanding > 0) setCpAmount(cust.outstanding);
                }}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-white text-sm focus:outline-none focus:border-cyan-500"
              >
                <option value="">-- Choose Customer --</option>
                {customers.map(c => (
                  <option key={c.id} value={c.id}>
                    {c.name} ({c.code}) - Due: {formatCurrency(c.outstanding, settings.currency)}
                  </option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-300">Payment Amount ({settings.currency}) *</label>
                <input
                  type="number"
                  step="0.001"
                  min="0.001"
                  required
                  placeholder="0.000"
                  value={cpAmount}
                  onChange={e => setCpAmount(e.target.value === '' ? '' : Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-white font-mono text-sm focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-300">Receipt Date</label>
                <input
                  type="date"
                  required
                  value={cpDate}
                  onChange={e => setCpDate(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-white text-sm focus:outline-none focus:border-cyan-500 font-mono"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-300">Payment Method</label>
                <select
                  value={cpMethod}
                  onChange={e => setCpMethod(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:border-cyan-500"
                >
                  <option value="Cash">Cash</option>
                  <option value="K-Net / Card">K-Net / Debit Card</option>
                  <option value="Bank Transfer">Bank Transfer</option>
                  <option value="Cheque">Cheque</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-300">Transaction Reference</label>
                <input
                  type="text"
                  placeholder="Receipt #, Cheque #, Txn ID"
                  value={cpRef}
                  onChange={e => setCpRef(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-white text-xs focus:outline-none focus:border-cyan-500"
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-300">Notes</label>
              <textarea
                rows={2}
                placeholder="Optional payment notes..."
                value={cpNotes}
                onChange={e => setCpNotes(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white text-xs focus:outline-none focus:border-cyan-500 resize-none"
              />
            </div>

            <button
              type="submit"
              disabled={saving}
              className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-semibold py-2.5 rounded-xl transition cursor-pointer flex items-center justify-center gap-2 shadow-lg shadow-emerald-950 disabled:opacity-50"
            >
              {saving && <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />}
              <span>Save & Reduce Customer Balance</span>
            </button>
          </form>
        </div>
      )}

      {/* SUPPLIER PAYMENT TAB */}
      {activeTab === 'supplier_pay' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 max-w-xl mx-auto space-y-4 shadow-xl">
          <h3 className="text-lg font-bold text-white flex items-center gap-2">
            <DollarSign className="text-amber-400" size={20} />
            <span>Disburse Supplier Payment</span>
          </h3>
          <p className="text-xs text-slate-400">
            Paying a supplier reduces accounts payable obligations and records cash outflow.
          </p>

          {formError && (
            <div className="p-3 bg-rose-950/80 border border-rose-800 text-rose-300 text-xs rounded-xl flex items-center gap-2">
              <AlertTriangle size={16} />
              <span>{formError}</span>
            </div>
          )}

          <form onSubmit={handleSaveSupplierPayment} className="space-y-4 text-xs sm:text-sm">
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-300">Select Vendor / Supplier *</label>
              <select
                required
                value={spSupplierId}
                onChange={e => {
                  setSpSupplierId(e.target.value);
                  const sup = suppliers.find(s => s.id === e.target.value);
                  if (sup && sup.payable > 0) setSpAmount(sup.payable);
                }}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-white text-sm focus:outline-none focus:border-cyan-500"
              >
                <option value="">-- Choose Supplier --</option>
                {suppliers.map(s => (
                  <option key={s.id} value={s.id}>
                    {s.name} ({s.code}) - Due: {formatCurrency(s.payable, settings.currency)}
                  </option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-300">Payment Amount ({settings.currency}) *</label>
                <input
                  type="number"
                  step="0.001"
                  min="0.001"
                  required
                  placeholder="0.000"
                  value={spAmount}
                  onChange={e => setSpAmount(e.target.value === '' ? '' : Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-white font-mono text-sm focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-300">Payment Date</label>
                <input
                  type="date"
                  required
                  value={spDate}
                  onChange={e => setSpDate(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-white text-sm focus:outline-none focus:border-cyan-500 font-mono"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-300">Disbursement Method</label>
                <select
                  value={spMethod}
                  onChange={e => setSpMethod(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:border-cyan-500"
                >
                  <option value="Bank Transfer">Bank Transfer</option>
                  <option value="Cash">Cash</option>
                  <option value="Cheque">Cheque</option>
                  <option value="K-Net / Card">K-Net / Card</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-300">Bank Transfer / Voucher #</label>
                <input
                  type="text"
                  placeholder="Voucher #, Bank Ref"
                  value={spRef}
                  onChange={e => setSpRef(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-white text-xs focus:outline-none focus:border-cyan-500"
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-300">Notes</label>
              <textarea
                rows={2}
                placeholder="Optional notes or remittance remarks..."
                value={spNotes}
                onChange={e => setSpNotes(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-white text-xs focus:outline-none focus:border-cyan-500 resize-none"
              />
            </div>

            <button
              type="submit"
              disabled={saving}
              className="w-full bg-amber-600 hover:bg-amber-500 text-white font-semibold py-2.5 rounded-xl transition cursor-pointer flex items-center justify-center gap-2 shadow-lg shadow-amber-950 disabled:opacity-50"
            >
              {saving && <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />}
              <span>Save & Reduce Supplier Payable</span>
            </button>
          </form>
        </div>
      )}

      {/* RECORD EXPENSE MODAL */}
      {isExpenseModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl">
            <div className="flex justify-between items-center border-b border-slate-800 pb-3">
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <TrendingDown className="text-rose-400" size={20} />
                <span>Record Business Expense</span>
              </h3>
              <button
                onClick={() => setIsExpenseModalOpen(false)}
                className="text-slate-400 hover:text-white p-1"
              >
                <X size={18} />
              </button>
            </div>

            {formError && (
              <div className="p-3 bg-rose-950/80 border border-rose-800 text-rose-300 text-xs rounded-xl flex items-center gap-2">
                <AlertTriangle size={16} />
                <span>{formError}</span>
              </div>
            )}

            <form onSubmit={handleSaveExpense} className="space-y-3.5 text-xs sm:text-sm">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-300">Expense Category</label>
                  <select
                    value={expCategory}
                    onChange={e => setExpCategory(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:border-cyan-500"
                  >
                    <option value="Office Supplies">Office Supplies</option>
                    <option value="Rent & Facility">Rent & Facility</option>
                    <option value="Utilities & Bills">Utilities & Bills</option>
                    <option value="Staff Salaries">Staff Salaries</option>
                    <option value="Logistics & Delivery">Logistics & Delivery</option>
                    <option value="Marketing & Ads">Marketing & Ads</option>
                    <option value="Repairs & Maintenance">Repairs & Maintenance</option>
                    <option value="Legal & Govt Fees">Legal & Govt Fees</option>
                    <option value="Other Overhead">Other Overhead</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-300">Date</label>
                  <input
                    type="date"
                    required
                    value={expDate}
                    onChange={e => setExpDate(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:border-cyan-500 font-mono"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-300">Description *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Monthly office internet & cloud subscription"
                  value={expDesc}
                  onChange={e => setExpDesc(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-white text-sm focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-300">Amount ({settings.currency}) *</label>
                  <input
                    type="number"
                    step="0.001"
                    min="0.001"
                    required
                    placeholder="0.000"
                    value={expAmount}
                    onChange={e => setExpAmount(e.target.value === '' ? '' : Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-white font-mono text-sm focus:outline-none focus:border-cyan-500"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-300">Payment Method</label>
                  <select
                    value={expMethod}
                    onChange={e => setExpMethod(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:border-cyan-500"
                  >
                    <option value="Cash">Cash</option>
                    <option value="Debit Card">Debit Card</option>
                    <option value="Bank Transfer">Bank Transfer</option>
                    <option value="Cheque">Cheque</option>
                  </select>
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-300">Reference / Receipt Number</label>
                <input
                  type="text"
                  placeholder="Receipt #, Bill ID"
                  value={expRef}
                  onChange={e => setExpRef(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-white text-xs focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div className="flex justify-end gap-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsExpenseModalOpen(false)}
                  className="px-4 py-2 bg-slate-800 text-slate-300 rounded-xl text-xs font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-white rounded-xl text-xs font-semibold transition cursor-pointer flex items-center gap-1.5"
                >
                  {saving && <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />}
                  <span>Save Expense</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
