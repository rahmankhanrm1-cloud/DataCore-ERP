import React, { useState, useEffect } from 'react';
import { db } from '../firebase';
import {
  collection,
  addDoc,
  getDocs,
  updateDoc,
  deleteDoc,
  doc,
  serverTimestamp
} from 'firebase/firestore';
import { Employee, Settings } from '../types';
import { formatCurrency, generateCode, formatDate } from '../utils/formatters';
import {
  UserCheck,
  Plus,
  Search,
  Edit2,
  Trash2,
  Eye,
  AlertTriangle,
  X,
  Phone,
  Mail,
  Building,
  CheckCircle,
  XCircle,
  Calendar
} from 'lucide-react';

interface EmployeesProps {
  settings: Settings;
}

export const Employees: React.FC<EmployeesProps> = ({ settings }) => {
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [deptFilter, setDeptFilter] = useState('ALL');

  // Modal states
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingEmployee, setEditingEmployee] = useState<Employee | null>(null);
  const [viewEmployee, setViewEmployee] = useState<Employee | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  // Form Fields
  const [name, setName] = useState('');
  const [mobile, setMobile] = useState('');
  const [email, setEmail] = useState('');
  const [jobTitle, setJobTitle] = useState('');
  const [department, setDepartment] = useState('Operations');
  const [salary, setSalary] = useState<number | ''>('');
  const [joiningDate, setJoiningDate] = useState(new Date().toISOString().slice(0, 10));
  const [address, setAddress] = useState('');
  const [status, setStatus] = useState<'Active' | 'Inactive'>('Active');
  const [notes, setNotes] = useState('');

  const fetchEmployees = async () => {
    try {
      setLoading(true);
      const snap = await getDocs(collection(db, 'employees'));
      const list: Employee[] = snap.docs.map(d => {
        const data = d.data();
        return {
          id: d.id,
          employeeId: data.employeeId || `EMP-${d.id.slice(0, 5).toUpperCase()}`,
          name: data.name || 'Unnamed',
          mobile: data.mobile || '',
          email: data.email || '',
          jobTitle: data.jobTitle || 'Staff',
          department: data.department || 'Operations',
          salary: Number(data.salary || 0),
          joiningDate: data.joiningDate || '',
          address: data.address || '',
          status: data.status === 'Inactive' ? 'Inactive' : 'Active',
          notes: data.notes || '',
          createdAt: data.createdAt?.toDate ? data.createdAt.toDate().toISOString() : data.createdAt,
        };
      });
      list.sort((a, b) => b.employeeId.localeCompare(a.employeeId));
      setEmployees(list);
    } catch (err) {
      console.error('Error fetching employees:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchEmployees();
  }, []);

  const openAddModal = () => {
    setEditingEmployee(null);
    setName('');
    setMobile('');
    setEmail('');
    setJobTitle('');
    setDepartment('Operations');
    setSalary('');
    setJoiningDate(new Date().toISOString().slice(0, 10));
    setAddress('');
    setStatus('Active');
    setNotes('');
    setFormError(null);
    setIsModalOpen(true);
  };

  const openEditModal = (emp: Employee) => {
    setEditingEmployee(emp);
    setName(emp.name);
    setMobile(emp.mobile);
    setEmail(emp.email);
    setJobTitle(emp.jobTitle);
    setDepartment(emp.department);
    setSalary(emp.salary);
    setJoiningDate(emp.joiningDate || new Date().toISOString().slice(0, 10));
    setAddress(emp.address || '');
    setStatus(emp.status);
    setNotes(emp.notes || '');
    setFormError(null);
    setIsModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setFormError('Employee Name is required.');
      return;
    }
    const sal = Number(salary) || 0;
    if (sal < 0) {
      setFormError('Salary cannot be negative.');
      return;
    }

    setSaving(true);
    setFormError(null);
    try {
      if (editingEmployee) {
        await updateDoc(doc(db, 'employees', editingEmployee.id), {
          name: name.trim(),
          mobile: mobile.trim(),
          email: email.trim(),
          jobTitle: jobTitle.trim(),
          department: department.trim(),
          salary: sal,
          joiningDate,
          address: address.trim(),
          status,
          notes: notes.trim(),
          updatedAt: serverTimestamp(),
        });
      } else {
        const autoCode = generateCode('EMP', employees.length);
        await addDoc(collection(db, 'employees'), {
          employeeId: autoCode,
          name: name.trim(),
          mobile: mobile.trim(),
          email: email.trim(),
          jobTitle: jobTitle.trim() || 'Staff',
          department: department.trim(),
          salary: sal,
          joiningDate,
          address: address.trim(),
          status,
          notes: notes.trim(),
          createdAt: serverTimestamp(),
        });
      }
      setIsModalOpen(false);
      fetchEmployees();
    } catch (err: any) {
      console.error('Error saving employee:', err);
      setFormError(err.message || 'Failed to save employee profile.');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await deleteDoc(doc(db, 'employees', id));
      setDeleteConfirmId(null);
      fetchEmployees();
    } catch (err) {
      console.error('Error deleting employee:', err);
    }
  };

  const departments = ['ALL', ...Array.from(new Set(employees.map(e => e.department || 'Operations')))];

  const filteredEmployees = employees.filter(e => {
    const matchesSearch =
      e.name.toLowerCase().includes(search.toLowerCase()) ||
      e.employeeId.toLowerCase().includes(search.toLowerCase()) ||
      e.jobTitle.toLowerCase().includes(search.toLowerCase()) ||
      e.mobile.toLowerCase().includes(search.toLowerCase());

    const matchesDept = deptFilter === 'ALL' || e.department === deptFilter;
    const matchesStatus = statusFilter === 'ALL' || e.status === statusFilter;

    return matchesSearch && matchesDept && matchesStatus;
  });

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-slate-900 border border-slate-800 p-4 sm:p-5 rounded-2xl">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-white flex items-center gap-2.5">
            <UserCheck className="text-cyan-400" size={26} />
            <span>Human Resources & Employees</span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 mt-0.5">
            Manage company staff profiles, job roles, monthly compensation, and active statuses.
          </p>
        </div>
        <button
          onClick={openAddModal}
          className="bg-cyan-600 hover:bg-cyan-500 text-white font-medium px-4 py-2.5 rounded-xl flex items-center gap-2 transition cursor-pointer text-sm shadow-lg shadow-cyan-950 w-full sm:w-auto justify-center"
        >
          <Plus size={18} />
          <span>Add Employee</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 bg-slate-900/70 border border-slate-800 p-3 sm:p-4 rounded-xl">
        <div className="relative">
          <Search size={18} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" />
          <input
            type="text"
            placeholder="Search by name, ID, title, phone..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-10 pr-4 py-2 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-cyan-500"
          />
        </div>

        <div>
          <select
            value={deptFilter}
            onChange={e => setDeptFilter(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2 text-white text-sm focus:outline-none focus:border-cyan-500"
          >
            {departments.map(d => (
              <option key={d} value={d}>
                Department: {d}
              </option>
            ))}
          </select>
        </div>

        <div>
          <select
            value={statusFilter}
            onChange={e => setStatusFilter(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2 text-white text-sm focus:outline-none focus:border-cyan-500"
          >
            <option value="ALL">All Statuses</option>
            <option value="Active">Active Staff</option>
            <option value="Inactive">Inactive / Resigned</option>
          </select>
        </div>
      </div>

      {/* Employees Table */}
      {loading ? (
        <div className="text-center py-16 bg-slate-900/50 border border-slate-800 rounded-2xl">
          <span className="inline-block w-8 h-8 border-3 border-cyan-400 border-t-transparent rounded-full animate-spin" />
          <p className="text-slate-400 text-sm mt-3">Loading employee staff records...</p>
        </div>
      ) : filteredEmployees.length === 0 ? (
        <div className="text-center py-14 bg-slate-900/40 border border-slate-800 rounded-2xl space-y-3">
          <UserCheck className="mx-auto text-slate-600" size={44} />
          <p className="text-slate-300 font-medium text-base">No staff members found</p>
          <p className="text-slate-500 text-xs max-w-sm mx-auto">
            {search || deptFilter !== 'ALL' || statusFilter !== 'ALL'
              ? 'No employees match your search criteria.'
              : 'Add employees to track internal staff, job titles, and monthly payroll obligations.'}
          </p>
          <button
            onClick={openAddModal}
            className="mt-2 bg-slate-800 hover:bg-slate-750 text-cyan-400 border border-cyan-500/30 px-4 py-2 rounded-xl text-sm font-medium transition cursor-pointer"
          >
            + Add First Employee
          </button>
        </div>
      ) : (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-slate-950/80 text-slate-400 border-b border-slate-800 text-xs uppercase tracking-wider">
                <tr>
                  <th className="py-3 px-4">Employee ID</th>
                  <th className="py-3 px-4">Name & Title</th>
                  <th className="py-3 px-4">Department</th>
                  <th className="py-3 px-4">Contact</th>
                  <th className="py-3 px-4 text-right">Monthly Salary</th>
                  <th className="py-3 px-4 text-center">Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-slate-200">
                {filteredEmployees.map(emp => (
                  <tr key={emp.id} className="hover:bg-slate-800/40 transition">
                    <td className="py-3.5 px-4 font-mono text-xs font-semibold text-cyan-300">
                      {emp.employeeId}
                    </td>
                    <td className="py-3.5 px-4">
                      <span className="font-semibold text-white block text-sm">{emp.name}</span>
                      <span className="text-xs text-slate-400">{emp.jobTitle}</span>
                    </td>
                    <td className="py-3.5 px-4 text-xs text-slate-300">
                      <span className="bg-slate-950 px-2 py-0.5 rounded-md border border-slate-800">
                        {emp.department}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-xs text-slate-400">
                      <div>{emp.mobile || '-'}</div>
                      {emp.email && <div className="text-[11px] text-slate-500">{emp.email}</div>}
                    </td>
                    <td className="py-3.5 px-4 text-right font-mono text-xs font-bold text-white">
                      {formatCurrency(emp.salary, settings.currency)}
                    </td>
                    <td className="py-3.5 px-4 text-center">
                      {emp.status === 'Active' ? (
                        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-950/80 text-emerald-300 border border-emerald-800">
                          <CheckCircle size={12} /> Active
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-slate-950 text-slate-400 border border-slate-800">
                          <XCircle size={12} /> Inactive
                        </span>
                      )}
                    </td>
                    <td className="py-3.5 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          title="View Employee Profile"
                          onClick={() => setViewEmployee(emp)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-cyan-300 hover:bg-slate-800 transition"
                        >
                          <Eye size={16} />
                        </button>
                        <button
                          title="Edit Employee"
                          onClick={() => openEditModal(emp)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
                        >
                          <Edit2 size={16} />
                        </button>
                        <button
                          title="Delete Employee"
                          onClick={() => setDeleteConfirmId(emp.id)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-slate-800 transition"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteConfirmId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-sm w-full p-6 space-y-4">
            <h3 className="text-lg font-bold text-white flex items-center gap-2 text-rose-400">
              <AlertTriangle size={20} />
              Confirm Delete Employee
            </h3>
            <p className="text-sm text-slate-300">
              Are you sure you want to delete this employee record from company archives?
            </p>
            <div className="flex justify-end gap-3 pt-2">
              <button
                onClick={() => setDeleteConfirmId(null)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-sm font-medium rounded-xl transition"
              >
                Cancel
              </button>
              <button
                onClick={() => handleDelete(deleteConfirmId)}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white text-sm font-medium rounded-xl transition cursor-pointer"
              >
                Yes, Delete
              </button>
            </div>
          </div>
        </div>
      )}

      {/* View Employee Modal */}
      {viewEmployee && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-6 space-y-4">
            <div className="flex justify-between items-start border-b border-slate-800 pb-3">
              <div>
                <span className="text-xs font-mono text-cyan-400 font-semibold">{viewEmployee.employeeId}</span>
                <h3 className="text-xl font-bold text-white">{viewEmployee.name}</h3>
                <p className="text-xs text-slate-400">{viewEmployee.jobTitle} &bull; {viewEmployee.department}</p>
              </div>
              <button onClick={() => setViewEmployee(null)} className="text-slate-400 hover:text-white p-1">
                <X size={18} />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs bg-slate-950 p-3.5 rounded-xl border border-slate-800">
              <div>
                <span className="text-slate-500 block">Mobile:</span>
                <span className="text-slate-200 font-medium">{viewEmployee.mobile || '-'}</span>
              </div>
              <div>
                <span className="text-slate-500 block">Email:</span>
                <span className="text-slate-200 font-medium">{viewEmployee.email || '-'}</span>
              </div>
              <div>
                <span className="text-slate-500 block">Joining Date:</span>
                <span className="text-slate-200 font-mono">{formatDate(viewEmployee.joiningDate)}</span>
              </div>
              <div>
                <span className="text-slate-500 block">Monthly Salary:</span>
                <span className="text-cyan-400 font-mono font-bold">
                  {formatCurrency(viewEmployee.salary, settings.currency)}
                </span>
              </div>
            </div>

            {viewEmployee.address && (
              <div className="text-xs text-slate-400 bg-slate-950/60 p-3 rounded-xl border border-slate-800">
                <span className="text-slate-500 font-semibold block mb-0.5">Address:</span>
                {viewEmployee.address}
              </div>
            )}

            {viewEmployee.notes && (
              <div className="text-xs text-slate-400 bg-slate-950/60 p-3 rounded-xl border border-slate-800">
                <span className="text-slate-500 font-semibold block mb-0.5">Notes:</span>
                {viewEmployee.notes}
              </div>
            )}

            <div className="flex justify-end pt-2 border-t border-slate-800">
              <button
                onClick={() => setViewEmployee(null)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold rounded-xl"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add / Edit Employee Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-xs overflow-y-auto">
          <div className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl p-6 sm:p-7 space-y-5 my-8">
            <div className="flex justify-between items-center border-b border-slate-800 pb-4">
              <h3 className="text-lg sm:text-xl font-bold text-white flex items-center gap-2">
                <UserCheck className="text-cyan-400" size={22} />
                <span>{editingEmployee ? 'Edit Staff Member' : 'Add Employee Profile'}</span>
              </h3>
              <button onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:text-white p-1 rounded-lg">
                <X size={20} />
              </button>
            </div>

            {formError && (
              <div className="p-3 bg-rose-950/70 border border-rose-800 text-rose-300 text-xs rounded-xl flex items-center gap-2">
                <AlertTriangle size={16} />
                <span>{formError}</span>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4 text-xs sm:text-sm">
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-300">Employee Full Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Tariq Al-Otaibi"
                  value={name}
                  onChange={e => setName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-white text-sm focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-300">Job Title / Designation</label>
                  <input
                    type="text"
                    placeholder="e.g. Senior Accountant, Sales Exec"
                    value={jobTitle}
                    onChange={e => setJobTitle(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-white text-sm focus:outline-none focus:border-cyan-500"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-300">Department</label>
                  <select
                    value={department}
                    onChange={e => setDepartment(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:border-cyan-500"
                  >
                    <option value="Operations">Operations</option>
                    <option value="Sales & Marketing">Sales & Marketing</option>
                    <option value="Finance & Accounts">Finance & Accounts</option>
                    <option value="Warehouse & Logistics">Warehouse & Logistics</option>
                    <option value="Management">Management</option>
                    <option value="IT & Systems">IT & Systems</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-300">Mobile Phone</label>
                  <input
                    type="text"
                    placeholder="+965 9000 1122"
                    value={mobile}
                    onChange={e => setMobile(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-white text-sm focus:outline-none focus:border-cyan-500 font-mono"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-300">Email Address</label>
                  <input
                    type="email"
                    placeholder="staff@datacore.erp"
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-white text-sm focus:outline-none focus:border-cyan-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-300">
                    Salary ({settings.currency})
                  </label>
                  <input
                    type="number"
                    step="0.001"
                    min="0"
                    placeholder="0.000"
                    value={salary}
                    onChange={e => setSalary(e.target.value === '' ? '' : Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-white text-sm focus:outline-none focus:border-cyan-500 font-mono"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-300">Joining Date</label>
                  <input
                    type="date"
                    value={joiningDate}
                    onChange={e => setJoiningDate(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:border-cyan-500 font-mono"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-300">Status</label>
                  <select
                    value={status}
                    onChange={e => setStatus(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:border-cyan-500"
                  >
                    <option value="Active">Active</option>
                    <option value="Inactive">Inactive</option>
                  </select>
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-300">Residential Address</label>
                <input
                  type="text"
                  placeholder="Salmiya, Block 10, Street 2"
                  value={address}
                  onChange={e => setAddress(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-white text-sm focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-300">Notes / Remarks</label>
                <textarea
                  rows={2}
                  placeholder="Civil ID number, emergency contact, passport details..."
                  value={notes}
                  onChange={e => setNotes(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-white text-xs focus:outline-none focus:border-cyan-500 resize-none"
                />
              </div>

              <div className="flex justify-end gap-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-sm font-medium rounded-xl transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="px-5 py-2 bg-cyan-600 hover:bg-cyan-500 text-white text-sm font-medium rounded-xl transition cursor-pointer flex items-center gap-2 shadow-lg shadow-cyan-950 disabled:opacity-50"
                >
                  {saving && <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />}
                  <span>{editingEmployee ? 'Update Staff Member' : 'Save Employee'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
