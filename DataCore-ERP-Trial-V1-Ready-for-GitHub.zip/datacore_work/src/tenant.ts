import { auth, db } from './firebase';
import { collection, doc } from 'firebase/firestore';
export const OWNER_EMAIL = 'datacore.solutionswork@gmail.com';
export const isOwner = () => auth.currentUser?.email?.toLowerCase() === OWNER_EMAIL;
export function tenantPath(name: string): string[] {
  const user = auth.currentUser;
  if (!user) throw new Error('Authentication required');
  return isOwner() ? [name] : ['tenants', user.uid, name];
}
export function erpCollection(name: string) { return collection(db, tenantPath(name).join('/')); }
export function erpDoc(name: string, id: string) { return doc(db, tenantPath(name).join('/'), id); }
