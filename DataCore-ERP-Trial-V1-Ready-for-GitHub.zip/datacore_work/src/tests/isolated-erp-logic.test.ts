// Isolated validation test for DataCore ERP business logic and transaction algorithms
// Does NOT mutate live Firebase database

interface ProductFixture {
  id: string;
  name: string;
  stock: number;
}

interface CustomerFixture {
  id: string;
  name: string;
  outstanding: number;
}

interface SupplierFixture {
  id: string;
  name: string;
  payable: number;
}

interface InvoiceItemFixture {
  productId: string;
  productName: string;
  quantity: number;
  unitPrice: number;
}

interface PurchaseItemFixture {
  productId: string;
  productName: string;
  quantity: number;
  purchasePrice: number;
}

// 1. Transaction simulator simulating Firestore transaction constraints
class MockFirestoreTransaction {
  private readsAllowed = true;
  public readLog: string[] = [];
  public writeLog: string[] = [];
  public state: {
    products: Map<string, ProductFixture>;
    customers: Map<string, CustomerFixture>;
    suppliers: Map<string, SupplierFixture>;
  };

  constructor(initialState: {
    products: ProductFixture[];
    customers: CustomerFixture[];
    suppliers: SupplierFixture[];
  }) {
    this.state = {
      products: new Map(initialState.products.map(p => [p.id, { ...p }])),
      customers: new Map(initialState.customers.map(c => [c.id, { ...c }])),
      suppliers: new Map(initialState.suppliers.map(s => [s.id, { ...s }])),
    };
  }

  startTransaction() {
    this.readsAllowed = true;
  }

  get(collectionName: string, id: string) {
    if (!this.readsAllowed) {
      throw new Error(`FIRESTORE TRANSACTION ERROR: Cannot perform get() after writes have begun!`);
    }
    this.readLog.push(`READ ${collectionName}/${id}`);
    const col = (this.state as any)[collectionName];
    return col?.get(id) ? { exists: true, data: () => ({ ...col.get(id) }) } : { exists: false, data: () => null };
  }

  update(collectionName: string, id: string, data: any) {
    this.readsAllowed = false; // Once a write is staged, no more reads are allowed
    this.writeLog.push(`UPDATE ${collectionName}/${id}: ${JSON.stringify(data)}`);
    const col = (this.state as any)[collectionName];
    if (col && col.has(id)) {
      const existing = col.get(id);
      col.set(id, { ...existing, ...data });
    }
  }

  set(collectionName: string, id: string, data: any) {
    this.readsAllowed = false;
    this.writeLog.push(`SET ${collectionName}/${id}: ${JSON.stringify(data)}`);
  }
}

// Transaction logic for saving a sale
function executeSaleTransaction(
  txn: MockFirestoreTransaction,
  params: {
    editingSaleData: any | null;
    selectedCustomerId: string;
    items: InvoiceItemFixture[];
    paid: number;
    allowNegativeStock: boolean;
  }
) {
  // READ PHASE
  const affectedProductIds = new Set<string>();
  for (const it of params.items) affectedProductIds.add(it.productId);
  if (params.editingSaleData) {
    for (const oldIt of params.editingSaleData.items || []) affectedProductIds.add(oldIt.productId);
  }

  const productSnapshots = new Map<string, any>();
  for (const pid of affectedProductIds) {
    productSnapshots.set(pid, txn.get('products', pid));
  }

  const affectedCustomerIds = new Set<string>([params.selectedCustomerId]);
  if (params.editingSaleData) affectedCustomerIds.add(params.editingSaleData.customerId);
  const customerSnapshots = new Map<string, any>();
  for (const cid of affectedCustomerIds) {
    customerSnapshots.set(cid, txn.get('customers', cid));
  }

  // VALIDATE & CALCULATE
  const newCustSnap = customerSnapshots.get(params.selectedCustomerId);
  if (!newCustSnap || !newCustSnap.exists) throw new Error('Customer does not exist');

  const newQtyByProduct = new Map<string, number>();
  for (const it of params.items) {
    newQtyByProduct.set(it.productId, (newQtyByProduct.get(it.productId) || 0) + it.quantity);
  }

  const oldQtyByProduct = new Map<string, number>();
  if (params.editingSaleData) {
    for (const oldIt of params.editingSaleData.items || []) {
      oldQtyByProduct.set(oldIt.productId, (oldQtyByProduct.get(oldIt.productId) || 0) + oldIt.quantity);
    }
  }

  const finalProductStocks = new Map<string, number>();
  for (const pid of affectedProductIds) {
    const snap = productSnapshots.get(pid);
    if (!snap || !snap.exists) throw new Error(`Product ${pid} missing`);
    const curStock = snap.data().stock;
    const oldQty = oldQtyByProduct.get(pid) || 0;
    const newQty = newQtyByProduct.get(pid) || 0;
    const finalStock = curStock + oldQty - newQty;
    if (!params.allowNegativeStock && finalStock < 0) {
      throw new Error(`Insufficient stock for product ${pid}`);
    }
    finalProductStocks.set(pid, finalStock);
  }

  const subtotal = params.items.reduce((acc, it) => acc + it.quantity * it.unitPrice, 0);
  const outstanding = Math.max(0, subtotal - params.paid);
  const curCustBal = newCustSnap.data().outstanding || 0;
  let finalCustBal: number;
  if (!params.editingSaleData) {
    finalCustBal = curCustBal + outstanding;
  } else {
    finalCustBal = curCustBal - (params.editingSaleData.outstanding || 0) + outstanding;
  }

  // WRITE PHASE
  for (const [pid, finalStock] of finalProductStocks.entries()) {
    txn.update('products', pid, { stock: finalStock });
  }
  txn.update('customers', params.selectedCustomerId, { outstanding: finalCustBal });
  txn.set('sales', 'INV-MOCK', { total: subtotal, paid: params.paid, outstanding });
  return { finalProductStocks, finalCustBal, outstanding, subtotal };
}

// Transaction logic for saving a purchase
function executePurchaseTransaction(
  txn: MockFirestoreTransaction,
  params: {
    editingPoData: any | null;
    selectedSupplierId: string;
    items: PurchaseItemFixture[];
    paid: number;
    allowNegativeStock: boolean;
  }
) {
  // READ PHASE
  const affectedProductIds = new Set<string>();
  for (const it of params.items) affectedProductIds.add(it.productId);
  if (params.editingPoData) {
    for (const oldIt of params.editingPoData.items || []) affectedProductIds.add(oldIt.productId);
  }

  const productSnapshots = new Map<string, any>();
  for (const pid of affectedProductIds) {
    productSnapshots.set(pid, txn.get('products', pid));
  }

  const affectedSupplierIds = new Set<string>([params.selectedSupplierId]);
  if (params.editingPoData) affectedSupplierIds.add(params.editingPoData.supplierId);
  const supplierSnapshots = new Map<string, any>();
  for (const sid of affectedSupplierIds) {
    supplierSnapshots.set(sid, txn.get('suppliers', sid));
  }

  // VALIDATE & CALCULATE
  const newSupSnap = supplierSnapshots.get(params.selectedSupplierId);
  if (!newSupSnap || !newSupSnap.exists) throw new Error('Supplier does not exist');

  const newQtyByProduct = new Map<string, number>();
  for (const it of params.items) {
    newQtyByProduct.set(it.productId, (newQtyByProduct.get(it.productId) || 0) + it.quantity);
  }

  const oldQtyByProduct = new Map<string, number>();
  if (params.editingPoData) {
    for (const oldIt of params.editingPoData.items || []) {
      oldQtyByProduct.set(oldIt.productId, (oldQtyByProduct.get(oldIt.productId) || 0) + oldIt.quantity);
    }
  }

  const finalProductStocks = new Map<string, number>();
  for (const pid of affectedProductIds) {
    const snap = productSnapshots.get(pid);
    if (!snap || !snap.exists) throw new Error(`Product ${pid} missing`);
    const curStock = snap.data().stock;
    const oldQty = oldQtyByProduct.get(pid) || 0;
    const newQty = newQtyByProduct.get(pid) || 0;
    const finalStock = curStock - oldQty + newQty;
    if (!params.allowNegativeStock && finalStock < 0) {
      throw new Error(`Insufficient stock for product ${pid}`);
    }
    finalProductStocks.set(pid, finalStock);
  }

  const subtotal = params.items.reduce((acc, it) => acc + it.quantity * it.purchasePrice, 0);
  const outstanding = Math.max(0, subtotal - params.paid);
  const curSupPayable = newSupSnap.data().payable || 0;
  let finalSupPayable: number;
  if (!params.editingPoData) {
    finalSupPayable = curSupPayable + outstanding;
  } else {
    finalSupPayable = curSupPayable - (params.editingPoData.outstanding || 0) + outstanding;
  }

  // WRITE PHASE
  for (const [pid, finalStock] of finalProductStocks.entries()) {
    txn.update('products', pid, { stock: finalStock });
  }
  txn.update('suppliers', params.selectedSupplierId, { payable: finalSupPayable });
  txn.set('purchases', 'PO-MOCK', { total: subtotal, paid: params.paid, outstanding });
  return { finalProductStocks, finalSupPayable, outstanding, subtotal };
}

// RUN TESTS
console.log('--- RUNNING ISOLATED ERP BUSINESS LOGIC TESTS ---');

// Test 1: Starting stock 10; purchase 1 at 5 KWD fully paid -> stock 11
const sim1 = new MockFirestoreTransaction({
  products: [{ id: 'prod-1', name: 'Widget A', stock: 10 }],
  customers: [{ id: 'cust-1', name: 'Customer A', outstanding: 0 }],
  suppliers: [{ id: 'sup-1', name: 'Supplier A', payable: 0 }],
});

const poResult = executePurchaseTransaction(sim1, {
  editingPoData: null,
  selectedSupplierId: 'sup-1',
  items: [{ productId: 'prod-1', productName: 'Widget A', quantity: 1, purchasePrice: 5 }],
  paid: 5,
  allowNegativeStock: false,
});

if (sim1.state.products.get('prod-1')?.stock !== 11) {
  throw new Error(`Expected stock 11 after purchase, got ${sim1.state.products.get('prod-1')?.stock}`);
}
if (sim1.state.suppliers.get('sup-1')?.payable !== 0) {
  throw new Error(`Expected supplier payable 0, got ${sim1.state.suppliers.get('sup-1')?.payable}`);
}
console.log('✔ Test 1 passed: Starting stock 10; purchase 1 at 5 KWD fully paid -> stock 11, supplier outstanding 0');

// Test 2: Sale 1 at 7 KWD fully paid -> stock 10
sim1.startTransaction();
const saleResult = executeSaleTransaction(sim1, {
  editingSaleData: null,
  selectedCustomerId: 'cust-1',
  items: [{ productId: 'prod-1', productName: 'Widget A', quantity: 1, unitPrice: 7 }],
  paid: 7,
  allowNegativeStock: false,
});

if (sim1.state.products.get('prod-1')?.stock !== 10) {
  throw new Error(`Expected stock 10 after sale, got ${sim1.state.products.get('prod-1')?.stock}`);
}
if (sim1.state.customers.get('cust-1')?.outstanding !== 0) {
  throw new Error(`Expected customer outstanding 0, got ${sim1.state.customers.get('cust-1')?.outstanding}`);
}
console.log('✔ Test 2 passed: Sale 1 at 7 KWD fully paid -> stock 10, customer outstanding 0');

// Test 3: Cash In 7, Cash Out 5, Net Change +2 KWD
const sales = [{ id: 's1', invoiceNumber: 'INV-00001', customerName: 'Customer A', date: '2026-10-06', paid: 7 }];
const purchases = [{ id: 'p1', purchaseNumber: 'PO-00001', supplierName: 'Supplier A', date: '2026-10-06', paid: 5 }];
const payments: any[] = [];
const expenses: any[] = [];

const cashIn = sales.reduce((acc, s) => acc + s.paid, 0) + payments.filter(p => p.type === 'customer_payment').reduce((acc, p) => acc + p.amount, 0);
const cashOut = purchases.reduce((acc, p) => acc + p.paid, 0) + payments.filter(p => p.type === 'supplier_payment').reduce((acc, p) => acc + p.amount, 0) + expenses.reduce((acc, e) => acc + e.amount, 0);
const netChange = cashIn - cashOut;

if (cashIn !== 7 || cashOut !== 5 || netChange !== 2) {
  throw new Error(`Expected Cash In 7, Cash Out 5, Net +2, got In: ${cashIn}, Out: ${cashOut}, Net: ${netChange}`);
}
console.log('✔ Test 3 passed: Cash In 7, Cash Out 5, Net change +2 KWD');

// Test 4: Ledger visibility and no double counting
const unifiedTransactions = [
  ...sales.filter(s => s.paid > 0).map(s => ({ type: 'Sale Payment', ref: s.invoiceNumber, amount: s.paid, dir: 'IN' })),
  ...purchases.filter(p => p.paid > 0).map(p => ({ type: 'Purchase Payment', ref: p.purchaseNumber, amount: p.paid, dir: 'OUT' })),
];
if (unifiedTransactions.length !== 2) throw new Error('Expected exactly 2 entries in ledger');
console.log('✔ Test 4 passed: Both payments visible in transaction ledger without double counting');

// Test 5: Customer and Supplier party histories derived without extra database writes
const customerDerivedHistory = sales.filter(s => s.paid > 0).map(s => ({ ref: s.invoiceNumber, amount: s.paid }));
const supplierDerivedHistory = purchases.filter(p => p.paid > 0).map(p => ({ ref: p.purchaseNumber, amount: p.paid }));
if (customerDerivedHistory[0].amount !== 7 || supplierDerivedHistory[0].amount !== 5) {
  throw new Error('Party payment histories derived incorrectly');
}
console.log('✔ Test 5 passed: Party payment histories derived correctly without duplicate writes');

// Test 6: Editing an unchanged invoice leaves stock unchanged
sim1.startTransaction();
const preEditStock = sim1.state.products.get('prod-1')!.stock; // 10
const savedSale = {
  id: 's1',
  customerId: 'cust-1',
  items: [{ productId: 'prod-1', productName: 'Widget A', quantity: 1, unitPrice: 7 }],
  outstanding: 0,
};
executeSaleTransaction(sim1, {
  editingSaleData: savedSale,
  selectedCustomerId: 'cust-1',
  items: [{ productId: 'prod-1', productName: 'Widget A', quantity: 1, unitPrice: 7 }], // unchanged!
  paid: 7,
  allowNegativeStock: false,
});
if (sim1.state.products.get('prod-1')!.stock !== preEditStock) {
  throw new Error(`Expected stock to remain ${preEditStock}, got ${sim1.state.products.get('prod-1')?.stock}`);
}
console.log('✔ Test 6 passed: Editing an unchanged invoice leaves stock unchanged (10 -> 10)');

// Test 7: Duplicate product rows cannot oversell
sim1.startTransaction();
let oversellCaught = false;
try {
  executeSaleTransaction(sim1, {
    editingSaleData: null,
    selectedCustomerId: 'cust-1',
    // Stock is 10, Row 1 requests 6, Row 2 requests 5 (total 11 > 10)
    items: [
      { productId: 'prod-1', productName: 'Widget A', quantity: 6, unitPrice: 7 },
      { productId: 'prod-1', productName: 'Widget A', quantity: 5, unitPrice: 7 },
    ],
    paid: 77,
    allowNegativeStock: false,
  });
} catch (err: any) {
  oversellCaught = true;
}
if (!oversellCaught) throw new Error('Duplicate product rows overselling was not prevented!');
console.log('✔ Test 7 passed: Duplicate product rows correctly aggregate and prevent overselling');

// Test 8: Failed transaction leaves no partial writes
const simFail = new MockFirestoreTransaction({
  products: [{ id: 'prod-1', name: 'Widget A', stock: 10 }],
  customers: [{ id: 'cust-1', name: 'Customer A', outstanding: 0 }],
  suppliers: [],
});
let failedTxnCaught = false;
try {
  executeSaleTransaction(simFail, {
    editingSaleData: null,
    selectedCustomerId: 'cust-1',
    items: [{ productId: 'prod-1', productName: 'Widget A', quantity: 999, unitPrice: 7 }],
    paid: 0,
    allowNegativeStock: false,
  });
} catch {
  failedTxnCaught = true;
}
if (simFail.writeLog.length !== 0) throw new Error('Failed transaction left writes in the log!');
if (simFail.state.products.get('prod-1')!.stock !== 10) throw new Error('Product stock mutated on failed transaction!');
console.log('✔ Test 8 passed: Failed transaction executes no writes; state remains intact');

console.log('--- ALL ISOLATED ERP LOGIC TESTS PASSED SUCCESSFULLY ---');
