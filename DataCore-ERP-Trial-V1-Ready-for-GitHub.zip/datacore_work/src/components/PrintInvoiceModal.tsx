import React from 'react';
import { Printer, X, CheckCircle, Clock, AlertTriangle } from 'lucide-react';
import { formatCurrency, formatDate } from '../utils/formatters';
import { Settings } from '../types';

interface PrintInvoiceModalProps {
  type: 'sale' | 'purchase';
  data: any;
  settings: Settings;
  onClose: () => void;
}

export const PrintInvoiceModal: React.FC<PrintInvoiceModalProps> = ({
  type,
  data,
  settings,
  onClose,
}) => {
  const isSale = type === 'sale';
  const docTitle = isSale ? 'TAX INVOICE' : 'PURCHASE ORDER';
  const docNumber = isSale ? data.invoiceNumber : data.purchaseNumber;
  const partyTitle = isSale ? 'Bill To (Customer):' : 'Vendor (Supplier):';
  const partyName = isSale ? data.customerName : data.supplierName;
  const partyMobile = isSale ? data.customerMobile : data.supplierMobile;
  const partyAddress = isSale ? data.customerAddress : data.supplierAddress;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-xs overflow-y-auto">
      {/* Modal Container */}
      <div className="relative w-full max-w-3xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Modal Controls Bar (Hidden during print) */}
        <div className="print:hidden p-4 bg-slate-950/80 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-white text-base">Print Preview</span>
            <span className="text-xs px-2 py-0.5 rounded-full bg-cyan-950 text-cyan-300 border border-cyan-800">
              {docNumber}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="bg-cyan-600 hover:bg-cyan-500 text-white px-3.5 py-1.5 rounded-xl text-sm font-medium flex items-center gap-2 transition cursor-pointer"
            >
              <Printer size={16} />
              <span>Print / Download PDF</span>
            </button>
            <button
              onClick={onClose}
              className="text-slate-400 hover:text-white p-1.5 rounded-xl hover:bg-slate-800 transition"
            >
              <X size={20} />
            </button>
          </div>
        </div>

        {/* Printable Document Area */}
        <div className="p-6 sm:p-10 overflow-y-auto bg-white text-slate-900 print:p-0 print:m-0 print:w-full print:bg-white print:text-black">
          {/* Header */}
          <div className="flex flex-col sm:flex-row justify-between items-start gap-4 border-b border-slate-200 pb-6">
            <div>
              <h2 className="text-2xl font-black text-slate-900 tracking-tight">
                {settings.companyName || 'DataCore Solutions Co.'}
              </h2>
              <p className="text-xs text-slate-600 mt-1 max-w-xs">
                {settings.address || 'Kuwait City, Kuwait'}
              </p>
              <p className="text-xs text-slate-600">
                Tel: {settings.phone || '+965 2200 8800'} | Email: {settings.email || 'info@datacore.erp'}
              </p>
            </div>
            <div className="sm:text-right">
              <span className="inline-block text-xl font-extrabold uppercase tracking-wider text-cyan-700">
                {docTitle}
              </span>
              <p className="text-sm font-semibold text-slate-800 mt-1 font-mono">
                {docNumber}
              </p>
              <p className="text-xs text-slate-500 mt-0.5">
                Date: {formatDate(data.date)}
              </p>
              {data.dueDate && (
                <p className="text-xs text-slate-500">
                  Due: {formatDate(data.dueDate)}
                </p>
              )}
            </div>
          </div>

          {/* Party and Status Info */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 py-5 border-b border-slate-200 text-xs">
            <div>
              <span className="font-bold text-slate-700 uppercase tracking-wider block mb-1">
                {partyTitle}
              </span>
              <p className="font-semibold text-slate-900 text-sm">{partyName || 'N/A'}</p>
              {partyMobile && <p className="text-slate-600">Mobile: {partyMobile}</p>}
              {partyAddress && <p className="text-slate-600">{partyAddress}</p>}
            </div>
            <div className="sm:text-right flex flex-col sm:items-end justify-center">
              <span className="font-bold text-slate-700 uppercase tracking-wider block mb-1">
                Payment Status
              </span>
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold uppercase tracking-wider border">
                {data.paymentStatus === 'Paid' ? (
                  <span className="text-emerald-700 bg-emerald-50 border-emerald-300 flex items-center gap-1">
                    <CheckCircle size={14} /> Paid Full
                  </span>
                ) : data.paymentStatus === 'Partially Paid' ? (
                  <span className="text-amber-700 bg-amber-50 border-amber-300 flex items-center gap-1">
                    <Clock size={14} /> Partially Paid
                  </span>
                ) : (
                  <span className="text-rose-700 bg-rose-50 border-rose-300 flex items-center gap-1">
                    <AlertTriangle size={14} /> Unpaid
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Line Items Table */}
          <div className="py-6 overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b-2 border-slate-900 text-slate-700 font-bold uppercase tracking-wider">
                  <th className="py-2.5 pr-2">#</th>
                  <th className="py-2.5 px-2">Item Description</th>
                  <th className="py-2.5 px-2">SKU</th>
                  <th className="py-2.5 px-2 text-right">Qty</th>
                  <th className="py-2.5 px-2 text-right">Price ({settings.currency})</th>
                  <th className="py-2.5 px-2 text-right">Disc</th>
                  <th className="py-2.5 pl-2 text-right">Total ({settings.currency})</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {data.items?.map((item: any, idx: number) => (
                  <tr key={idx} className="text-slate-800">
                    <td className="py-2.5 pr-2 text-slate-500">{idx + 1}</td>
                    <td className="py-2.5 px-2 font-medium">{item.productName}</td>
                    <td className="py-2.5 px-2 text-slate-500 font-mono">{item.sku || '-'}</td>
                    <td className="py-2.5 px-2 text-right font-semibold">{item.quantity}</td>
                    <td className="py-2.5 px-2 text-right font-mono">
                      {(isSale ? item.sellingPrice : item.purchasePrice)?.toFixed(3)}
                    </td>
                    <td className="py-2.5 px-2 text-right font-mono">
                      {item.discount > 0 ? `${item.discount}` : '-'}
                    </td>
                    <td className="py-2.5 pl-2 text-right font-mono font-semibold">
                      {item.lineTotal?.toFixed(3)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Financial Totals Summary */}
          <div className="flex flex-col sm:flex-row justify-between items-start gap-4 pt-4 border-t-2 border-slate-900 text-xs">
            <div className="max-w-xs text-slate-600">
              {data.notes && (
                <>
                  <span className="font-bold text-slate-800 block mb-1">Notes:</span>
                  <p className="italic">{data.notes}</p>
                </>
              )}
            </div>
            <div className="w-full sm:w-64 space-y-1.5 text-right font-mono">
              <div className="flex justify-between text-slate-600">
                <span>Subtotal:</span>
                <span>{formatCurrency(data.subtotal, settings.currency)}</span>
              </div>
              {data.discount > 0 && (
                <div className="flex justify-between text-slate-600">
                  <span>Discount:</span>
                  <span>- {formatCurrency(data.discount, settings.currency)}</span>
                </div>
              )}
              {data.tax > 0 && (
                <div className="flex justify-between text-slate-600">
                  <span>Tax:</span>
                  <span>+ {formatCurrency(data.tax, settings.currency)}</span>
                </div>
              )}
              <div className="flex justify-between font-bold text-slate-900 text-sm pt-2 border-t border-slate-300">
                <span>Grand Total:</span>
                <span className="text-cyan-800">{formatCurrency(data.total, settings.currency)}</span>
              </div>
              <div className="flex justify-between text-emerald-700 font-medium pt-1">
                <span>Amount Paid:</span>
                <span>{formatCurrency(data.paid, settings.currency)}</span>
              </div>
              <div className="flex justify-between text-rose-700 font-bold text-xs pt-1 border-t border-slate-200">
                <span>Outstanding Balance:</span>
                <span>{formatCurrency(data.outstanding, settings.currency)}</span>
              </div>
            </div>
          </div>

          {/* Footer note */}
          <div className="mt-10 pt-4 border-t border-slate-200 text-center text-[10px] text-slate-500">
            <p>Thank you for doing business with {settings.companyName || 'DataCore Solutions Co.'}.</p>
            <p className="mt-0.5">Computer-generated business record. Authorized Signature not required.</p>
          </div>
        </div>
      </div>
    </div>
  );
};
