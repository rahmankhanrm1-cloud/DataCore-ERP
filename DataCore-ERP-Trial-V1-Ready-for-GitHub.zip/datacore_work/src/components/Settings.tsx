import { erpCollection, erpDoc } from '../tenant';
import React, { useState } from 'react';
import { db } from '../firebase';
import { doc, setDoc, serverTimestamp } from 'firebase/firestore';
import { Settings as SettingsType } from '../types';
import {
  Settings as SettingsIcon,
  Building,
  Save,
  CheckCircle,
  AlertTriangle,
  Sliders,
  DollarSign,
  ShieldAlert,
  Hash
} from 'lucide-react';

interface SettingsProps {
  settings: SettingsType;
  onUpdateSettings: (newSettings: SettingsType) => void;
}

export const Settings: React.FC<SettingsProps> = ({ settings, onUpdateSettings }) => {
  const [form, setForm] = useState<SettingsType>({ ...settings });
  const [saving, setSaving] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setSuccess(false);
    setError(null);

    try {
      await setDoc(erpDoc('settings', 'general'), {
        ...form,
        updatedAt: serverTimestamp(),
      });
      onUpdateSettings(form);
      setSuccess(true);
      setTimeout(() => setSuccess(false), 4000);
    } catch (err: any) {
      console.error('Error saving settings:', err);
      setError(err.message || 'Failed to update system settings.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6 max-w-4xl">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl">
        <h2 className="text-xl sm:text-2xl font-bold text-white flex items-center gap-2.5">
          <SettingsIcon className="text-cyan-400" size={26} />
          <span>System & Enterprise Settings</span>
        </h2>
        <p className="text-xs sm:text-sm text-slate-400 mt-0.5">
          Configure company profile information, default tax, invoice number numbering, and currency formats.
        </p>
      </div>

      {success && (
        <div className="p-4 bg-emerald-950/80 border border-emerald-800 text-emerald-300 text-sm rounded-xl flex items-center gap-2.5">
          <CheckCircle size={18} className="text-emerald-400" />
          <span>Settings saved and updated successfully across the ERP!</span>
        </div>
      )}

      {error && (
        <div className="p-4 bg-rose-950/80 border border-rose-800 text-rose-300 text-sm rounded-xl flex items-center gap-2.5">
          <AlertTriangle size={18} className="text-rose-400" />
          <span>{error}</span>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Company Profile Section */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
          <h3 className="text-base font-bold text-white flex items-center gap-2 border-b border-slate-800 pb-3">
            <Building className="text-cyan-400" size={18} />
            <span>Company Profile & Branding</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs sm:text-sm">
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-300">Company Legal Name *</label>
              <input
                type="text"
                required
                value={form.companyName}
                onChange={e => setForm({ ...form, companyName: e.target.value })}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-white text-sm focus:outline-none focus:border-cyan-500"
              />
            </div>

            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-300">Official Phone Number</label>
              <input
                type="text"
                value={form.phone}
                onChange={e => setForm({ ...form, phone: e.target.value })}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-white text-sm focus:outline-none focus:border-cyan-500 font-mono"
              />
            </div>

            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-300">Official Email</label>
              <input
                type="email"
                value={form.email}
                onChange={e => setForm({ ...form, email: e.target.value })}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-white text-sm focus:outline-none focus:border-cyan-500"
              />
            </div>

            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-300">Corporate Address</label>
              <input
                type="text"
                value={form.address}
                onChange={e => setForm({ ...form, address: e.target.value })}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-white text-sm focus:outline-none focus:border-cyan-500"
              />
            </div>
          </div>
        </div>

        {/* Currency & Financial Configuration */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
          <h3 className="text-base font-bold text-white flex items-center gap-2 border-b border-slate-800 pb-3">
            <DollarSign className="text-emerald-400" size={18} />
            <span>Financial & Currency Formats</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs sm:text-sm">
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-300">Operating Currency</label>
              <input
                type="text"
                value={form.currency}
                onChange={e => setForm({ ...form, currency: e.target.value.toUpperCase() })}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-white text-sm focus:outline-none focus:border-cyan-500 font-mono font-bold"
              />
              <p className="text-[11px] text-slate-500">Default: KWD (Kuwaiti Dinar)</p>
            </div>

            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-300">Default Tax Rate (%)</label>
              <input
                type="number"
                step="0.1"
                min="0"
                value={form.taxRate}
                onChange={e => setForm({ ...form, taxRate: Number(e.target.value) })}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-white text-sm focus:outline-none focus:border-cyan-500 font-mono"
              />
              <p className="text-[11px] text-slate-500">Auto-applied on sales/purchases</p>
            </div>

            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-300">Low Stock Alert Threshold</label>
              <input
                type="number"
                min="1"
                value={form.lowStockThreshold}
                onChange={e => setForm({ ...form, lowStockThreshold: Number(e.target.value) })}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-white text-sm focus:outline-none focus:border-cyan-500 font-mono"
              />
              <p className="text-[11px] text-slate-500">Highlights items in inventory & dashboard</p>
            </div>
          </div>
        </div>

        {/* Numbering & Inventory Policy */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
          <h3 className="text-base font-bold text-white flex items-center gap-2 border-b border-slate-800 pb-3">
            <Hash className="text-amber-400" size={18} />
            <span>Document Numbering & Inventory Rules</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs sm:text-sm">
            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-300">Sales Invoice Prefix</label>
              <input
                type="text"
                value={form.invoicePrefix}
                onChange={e => setForm({ ...form, invoicePrefix: e.target.value })}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-white text-sm focus:outline-none focus:border-cyan-500 font-mono"
              />
              <p className="text-[11px] text-slate-500">e.g. INV produces INV-00001</p>
            </div>

            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-300">Purchase Order Prefix</label>
              <input
                type="text"
                value={form.purchasePrefix}
                onChange={e => setForm({ ...form, purchasePrefix: e.target.value })}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-white text-sm focus:outline-none focus:border-cyan-500 font-mono"
              />
              <p className="text-[11px] text-slate-500">e.g. PO produces PO-00001</p>
            </div>
          </div>

          {/* Negative stock toggle */}
          <div className="pt-2">
            <label className="flex items-center gap-3 p-3 bg-slate-950 border border-slate-800 rounded-xl cursor-pointer hover:bg-slate-900/50 transition">
              <input
                type="checkbox"
                checked={form.allowNegativeStock}
                onChange={e => setForm({ ...form, allowNegativeStock: e.target.checked })}
                className="w-4 h-4 rounded text-cyan-600 focus:ring-cyan-500 border-slate-700 bg-slate-900"
              />
              <div>
                <span className="text-xs font-semibold text-white block">
                  Allow Negative Stock Sales
                </span>
                <span className="text-[11px] text-slate-400 block">
                  When enabled, sales invoices can be processed even if requested quantity exceeds current on-hand stock.
                </span>
              </div>
            </label>
          </div>
        </div>

        {/* Submit Button */}
        <div className="flex justify-end pt-2">
          <button
            type="submit"
            disabled={saving}
            className="bg-cyan-600 hover:bg-cyan-500 text-white font-semibold px-6 py-2.5 rounded-xl transition cursor-pointer flex items-center gap-2 shadow-lg shadow-cyan-950 disabled:opacity-50 text-sm"
          >
            {saving && <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />}
            <Save size={16} />
            <span>Save System Settings</span>
          </button>
        </div>
      </form>
    </div>
  );
};
