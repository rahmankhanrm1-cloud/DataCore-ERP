import { erpCollection, erpDoc } from '../tenant';
import React, { useState, useEffect } from 'react';
import { db } from '../firebase';
import {
  collection,
  addDoc,
  getDocs,
  updateDoc,
  deleteDoc,
  doc,
  serverTimestamp,
  query,
  where,
  runTransaction
} from 'firebase/firestore';
import { Supplier, Settings } from '../types';
import { formatCurrency, generateCode, formatDate } from '../utils/formatters';
import {
  Truck,
  Plus,
  Search,
  Edit2,
  Trash2,
  Eye,
  AlertTriangle,
  X,
  CreditCard,
  ShoppingCart,
  Phone,
  Mail,
  DollarSign
} from 'lucide-react';

interface SuppliersProps {
  settings: Settings;
}

export const Suppliers: React.FC<SuppliersProps> = ({ settings }) => {
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingSupplier, setEditingSupplier] = useState<Supplier | null>(null);
  const [viewSupplier, setViewSupplier] = useState<Supplier | null>(null);
  const [supplierPurchases, setSupplierPurchases] = useState<any[]>([]);
  const [supplierPayments, setSupplierPayments] = useState<any[]>([]);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  // Quick Payment Modal
  const [payModalSupplier, setPayModalSupplier] = useState<Supplier | null>(null);
  const [payAmount, setPayAmount] = useState<number | ''>('');
  const [payMethod, setPayMethod] = useState('Bank Transfer');
  const [payRef, setPayRef] = useState('');

  // Form Fields
  const [name, setName] = useState('');
  const [mobile, setMobile] = useState('');
  const [email, setEmail] = useState('');
  const [address, setAddress] = useState('');
  const [openingBalance, setOpeningBalance] = useState<number | ''>(0);
  const [notes, setNotes] = useState('');
  const [formError, setFormError] = useState<string | null>(null);

  const fetchSuppliers = async () => {
    try {
      setLoading(true);
      const snap = await getDocs(erpCollection('suppliers'));
      const list: Supplier[] = snap.docs.map(d => {
        const data = d.data();
        return {
          id: d.id,
          code: data.code || `SUP-${d.id.slice(0, 5).toUpperCase()}`,
          name: data.name || 'Unnamed Supplier',
          mobile: data.mobile || '',
          email: data.email || '',
          address: data.address || '',
          openingBalance: Number(data.openingBalance || 0),
          payable: Number(data.payable ?? (data.openingBalance || 0)),
          notes: data.notes || '',
          createdAt: data.createdAt?.toDate ? data.createdAt.toDate().toISOString() : data.createdAt,
        };
      });
      list.sort((a, b) => b.code.localeCompare(a.code));
      setSuppliers(list);
    } catch (err) {
      console.error('Error fetching suppliers:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSuppliers();
  }, []);

  const openAddModal = () => {
    setEditingSupplier(null);
    setName('');
    setMobile('');
    setEmail('');
    setAddress('');
    setOpeningBalance(0);
    setNotes('');
    setFormError(null);
    setIsModalOpen(true);
  };

  const openEditModal = (s: Supplier) => {
    setEditingSupplier(s);
    setName(s.name);
    setMobile(s.mobile);
    setEmail(s.email);
    setAddress(s.address);
    setOpeningBalance(s.openingBalance);
    setNotes(s.notes || '');
    setFormError(null);
    setIsModalOpen(true);
  };

  const openViewSupplier = async (s: Supplier) => {
    // Clear previous supplier's history immediately
    setSupplierPurchases([]);
    setSupplierPayments([]);
    setViewSupplier(s);

    try {
      const [puSnap, paySnap] = await Promise.all([
        getDocs(query(erpCollection('purchases'), where('supplierId', '==', s.id))),
        getDocs(query(erpCollection('payments'), where('partyId', '==', s.id))),
      ]);

      const purchases = puSnap.docs.map(d => ({ id: d.id, ...d.data() }));
      purchases.sort((a: any, b: any) => (b.date || '').localeCompare(a.date || ''));
      setSupplierPurchases(purchases);

      // Derive payments from both purchase orders with paid > 0 and separate disbursements
      const orderPayments = purchases
        .filter((po: any) => (Number(po.paid) || 0) > 0)
        .map((po: any) => ({
          id: `po-pay-${po.id}`,
          date: po.date,
          paymentMethod: po.paymentMethod || po.method || '-',
          reference: po.purchaseNumber,
          amount: Number(po.paid) || 0,
          source: 'Order Payment',
        }));

      const separatePayments = paySnap.docs
        .map(d => ({ id: d.id, ...d.data() }))
        .filter((p: any) => p.type === 'supplier_payment' || !p.type)
        .map((p: any) => ({
          id: p.id,
          date: p.date,
          paymentMethod: p.paymentMethod || '-',
          reference: p.reference || '-',
          amount: Number(p.amount) || 0,
          source: 'Disbursement',
        }));

      const allPayments = [...orderPayments, ...separatePayments];
      allPayments.sort((a, b) => (b.date || '').localeCompare(a.date || ''));
      setSupplierPayments(allPayments);
    } catch (err) {
      console.error('Error fetching supplier history:', err);
      setSupplierPurchases([]);
      setSupplierPayments([]);
    }
  };

  const closeViewSupplier = () => {
    setViewSupplier(null);
    setSupplierPurchases([]);
    setSupplierPayments([]);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setFormError('Supplier Name is required.');
      return;
    }

    const opBal = Number(openingBalance) || 0;
    setSaving(true);
    setFormError(null);

    try {
      if (editingSupplier) {
        await updateDoc(erpDoc('suppliers', editingSupplier.id), {
          name: name.trim(),
          mobile: mobile.trim(),
          email: email.trim(),
          address: address.trim(),
          notes: notes.trim(),
          updatedAt: serverTimestamp(),
        });
      } else {
        const autoCode = generateCode('SUP', suppliers.length);
        await addDoc(erpCollection('suppliers'), {
          code: autoCode,
          name: name.trim(),
          mobile: mobile.trim(),
          email: email.trim(),
          address: address.trim(),
          openingBalance: opBal,
          payable: opBal, // initial payable is opening balance
          notes: notes.trim(),
          createdAt: serverTimestamp(),
        });
      }
      setIsModalOpen(false);
      fetchSuppliers();
    } catch (err: any) {
      console.error('Error saving supplier:', err);
      setFormError(err.message || 'Failed to save supplier.');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await deleteDoc(erpDoc('suppliers', id));
      setDeleteConfirmId(null);
      fetchSuppliers();
    } catch (err) {
      console.error('Error deleting supplier:', err);
    }
  };

  const handleRecordPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!payModalSupplier) return;
    const amount = Number(payAmount);
    if (isNaN(amount) || amount <= 0) return;

    setSaving(true);
    try {
      await runTransaction(db, async transaction => {
        const sRef = erpDoc('suppliers', payModalSupplier.id);
        const sDoc = await transaction.get(sRef);
        if (!sDoc.exists()) throw new Error('Supplier not found');
        const currentPayable = Number(sDoc.data().payable || 0);
        const newPayable = currentPayable - amount;

        transaction.update(sRef, {
          payable: newPayable,
          updatedAt: serverTimestamp(),
        });

        // Record in payments collection
        const payRefDoc = doc(erpCollection('payments'));
        transaction.set(payRefDoc, {
          type: 'supplier_payment',
          partyId: payModalSupplier.id,
          partyName: payModalSupplier.name,
          amount,
          date: new Date().toISOString().slice(0, 10),
          paymentMethod: payMethod,
          reference: payRef.trim(),
          createdAt: serverTimestamp(),
        });
      });

      setPayModalSupplier(null);
      setPayAmount('');
      setPayRef('');
      fetchSuppliers();
    } catch (err) {
      console.error('Error recording supplier payment:', err);
    } finally {
      setSaving(false);
    }
  };

  const filteredSuppliers = suppliers.filter(s =>
    s.name.toLowerCase().includes(search.toLowerCase()) ||
    s.code.toLowerCase().includes(search.toLowerCase()) ||
    s.mobile.toLowerCase().includes(search.toLowerCase()) ||
    s.email.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-slate-900 border border-slate-800 p-4 sm:p-5 rounded-2xl">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-white flex items-center gap-2.5">
            <Truck className="text-cyan-400" size={26} />
            <span>Supplier & Vendor Directory</span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 mt-0.5">
            Manage product vendors, procurement sources, and track accounts payable balances.
          </p>
        </div>
        <button
          onClick={openAddModal}
          className="bg-cyan-600 hover:bg-cyan-500 text-white font-medium px-4 py-2.5 rounded-xl flex items-center gap-2 transition cursor-pointer text-sm shadow-lg shadow-cyan-950 w-full sm:w-auto justify-center"
        >
          <Plus size={18} />
          <span>Add Supplier</span>
        </button>
      </div>

      {/* Search Bar */}
      <div className="bg-slate-900/70 border border-slate-800 p-3 sm:p-4 rounded-xl">
        <div className="relative">
          <Search size={18} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" />
          <input
            type="text"
            placeholder="Search by supplier name, code, phone, email..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-10 pr-4 py-2 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-cyan-500"
          />
        </div>
      </div>

      {/* Suppliers Table */}
      {loading ? (
        <div className="text-center py-16 bg-slate-900/50 border border-slate-800 rounded-2xl">
          <span className="inline-block w-8 h-8 border-3 border-cyan-400 border-t-transparent rounded-full animate-spin" />
          <p className="text-slate-400 text-sm mt-3">Loading supplier directory...</p>
        </div>
      ) : filteredSuppliers.length === 0 ? (
        <div className="text-center py-14 bg-slate-900/40 border border-slate-800 rounded-2xl space-y-3">
          <Truck className="mx-auto text-slate-600" size={44} />
          <p className="text-slate-300 font-medium text-base">No suppliers found</p>
          <p className="text-slate-500 text-xs max-w-sm mx-auto">
            {search
              ? 'No matching supplier names or records found.'
              : 'Add your first supplier to enable recording purchases and inventory stock additions.'}
          </p>
          <button
            onClick={openAddModal}
            className="mt-2 bg-slate-800 hover:bg-slate-750 text-cyan-400 border border-cyan-500/30 px-4 py-2 rounded-xl text-sm font-medium transition cursor-pointer"
          >
            + Add First Supplier
          </button>
        </div>
      ) : (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-slate-950/80 text-slate-400 border-b border-slate-800 text-xs uppercase tracking-wider">
                <tr>
                  <th className="py-3 px-4">Supplier Code</th>
                  <th className="py-3 px-4">Supplier & Contact</th>
                  <th className="py-3 px-4">Address</th>
                  <th className="py-3 px-4 text-right">Opening Bal</th>
                  <th className="py-3 px-4 text-right">Payable Balance</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-slate-200">
                {filteredSuppliers.map(s => {
                  const hasPayable = s.payable > 0;
                  return (
                    <tr key={s.id} className="hover:bg-slate-800/40 transition">
                      <td className="py-3.5 px-4 font-mono text-xs">
                        <span className="font-semibold text-cyan-300">{s.code}</span>
                      </td>
                      <td className="py-3.5 px-4">
                        <span className="font-semibold text-white block text-sm">{s.name}</span>
                        <div className="flex items-center gap-3 text-xs text-slate-400 mt-0.5">
                          {s.mobile && (
                            <span className="flex items-center gap-1">
                              <Phone size={12} className="text-slate-500" /> {s.mobile}
                            </span>
                          )}
                          {s.email && (
                            <span className="flex items-center gap-1">
                              <Mail size={12} className="text-slate-500" /> {s.email}
                            </span>
                          )}
                        </div>
                      </td>
                      <td className="py-3.5 px-4 text-xs text-slate-400 max-w-[180px] truncate">
                        {s.address || '-'}
                      </td>
                      <td className="py-3.5 px-4 text-right font-mono text-xs text-slate-400">
                        {formatCurrency(s.openingBalance, settings.currency)}
                      </td>
                      <td className="py-3.5 px-4 text-right font-mono text-xs font-bold">
                        <span className={hasPayable ? 'text-amber-400' : 'text-slate-300'}>
                          {formatCurrency(s.payable, settings.currency)}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {hasPayable && (
                            <button
                              title="Make Payment to Supplier"
                              onClick={() => {
                                setPayModalSupplier(s);
                                setPayAmount(s.payable);
                              }}
                              className="px-2 py-1 bg-amber-950 hover:bg-amber-900 border border-amber-800 text-amber-300 text-xs rounded-lg flex items-center gap-1 font-medium transition"
                            >
                              <DollarSign size={13} />
                              <span>Pay</span>
                            </button>
                          )}
                          <button
                            title="View Profile & Orders"
                            onClick={() => openViewSupplier(s)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-cyan-300 hover:bg-slate-800 transition"
                          >
                            <Eye size={16} />
                          </button>
                          <button
                            title="Edit Supplier"
                            onClick={() => openEditModal(s)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
                          >
                            <Edit2 size={16} />
                          </button>
                          <button
                            title="Delete Supplier"
                            onClick={() => setDeleteConfirmId(s.id)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-slate-800 transition"
                          >
                            <Trash2 size={16} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Record Quick Payment to Supplier Modal */}
      {payModalSupplier && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-6 space-y-4">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="text-lg font-bold text-white flex items-center gap-2">
                  <CreditCard className="text-amber-400" size={20} />
                  <span>Make Supplier Payment</span>
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Vendor: <span className="text-white font-semibold">{payModalSupplier.name}</span>
                </p>
                <p className="text-xs text-amber-400 font-mono mt-0.5">
                  Payable Due: {formatCurrency(payModalSupplier.payable, settings.currency)}
                </p>
              </div>
              <button
                onClick={() => setPayModalSupplier(null)}
                className="text-slate-400 hover:text-white p-1"
              >
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleRecordPayment} className="space-y-3 text-xs sm:text-sm">
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-300">Payment Amount ({settings.currency}) *</label>
                <input
                  type="number"
                  step="0.001"
                  min="0.001"
                  required
                  value={payAmount}
                  onChange={e => setPayAmount(e.target.value === '' ? '' : Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-white font-mono text-sm focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-300">Payment Method</label>
                <select
                  value={payMethod}
                  onChange={e => setPayMethod(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:border-cyan-500"
                >
                  <option value="Bank Transfer">Bank Transfer</option>
                  <option value="Cash">Cash</option>
                  <option value="Cheque">Cheque</option>
                  <option value="K-Net / Card">K-Net / Debit Card</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-300">Reference / Notes</label>
                <input
                  type="text"
                  placeholder="Voucher #, Bank Transfer Ref"
                  value={payRef}
                  onChange={e => setPayRef(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-white text-xs focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div className="flex justify-end gap-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setPayModalSupplier(null)}
                  className="px-4 py-2 bg-slate-800 text-slate-300 rounded-xl text-xs font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="px-4 py-2 bg-amber-600 hover:bg-amber-500 text-white rounded-xl text-xs font-semibold transition cursor-pointer flex items-center gap-1.5"
                >
                  {saving && <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />}
                  <span>Record Disbursement</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteConfirmId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-sm w-full p-6 space-y-4">
            <h3 className="text-lg font-bold text-white flex items-center gap-2 text-rose-400">
              <AlertTriangle size={20} />
              Confirm Delete Supplier
            </h3>
            <p className="text-sm text-slate-300">
              Are you sure you want to delete this supplier? Recorded purchase orders will remain intact.
            </p>
            <div className="flex justify-end gap-3 pt-2">
              <button
                onClick={() => setDeleteConfirmId(null)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-sm font-medium rounded-xl transition"
              >
                Cancel
              </button>
              <button
                onClick={() => handleDelete(deleteConfirmId)}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white text-sm font-medium rounded-xl transition cursor-pointer"
              >
                Yes, Delete
              </button>
            </div>
          </div>
        </div>
      )}

      {/* View Supplier Details Modal */}
      {viewSupplier && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-xs overflow-y-auto">
          <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl p-6 sm:p-7 space-y-5 my-8 max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-start border-b border-slate-800 pb-4">
              <div>
                <span className="text-xs font-mono text-cyan-400 font-semibold">{viewSupplier.code}</span>
                <h3 className="text-xl font-bold text-white">{viewSupplier.name}</h3>
                <div className="flex flex-wrap gap-4 text-xs text-slate-400 mt-1">
                  {viewSupplier.mobile && <span>Tel: {viewSupplier.mobile}</span>}
                  {viewSupplier.email && <span>Email: {viewSupplier.email}</span>}
                  {viewSupplier.address && <span>Address: {viewSupplier.address}</span>}
                </div>
              </div>
              <button onClick={closeViewSupplier} className="text-slate-400 hover:text-white p-1">
                <X size={20} />
              </button>
            </div>

            {/* Financial Summary */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800">
                <span className="text-xs text-slate-500 block">Opening Balance</span>
                <span className="font-mono text-sm text-slate-300">{formatCurrency(viewSupplier.openingBalance, settings.currency)}</span>
              </div>
              <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800">
                <span className="text-xs text-slate-500 block">Total Purchases</span>
                <span className="font-mono text-sm text-cyan-400 font-bold">{supplierPurchases.length} orders</span>
              </div>
              <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 col-span-2 sm:col-span-1">
                <span className="text-xs text-slate-500 block">Payable Balance</span>
                <span className={`font-mono text-sm font-bold ${viewSupplier.payable > 0 ? 'text-amber-400' : 'text-emerald-400'}`}>
                  {formatCurrency(viewSupplier.payable, settings.currency)}
                </span>
              </div>
            </div>

            {/* Purchases History */}
            <div className="space-y-2">
              <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                <ShoppingCart size={14} className="text-cyan-400" />
                <span>Purchase Orders History ({supplierPurchases.length})</span>
              </h4>
              {supplierPurchases.length === 0 ? (
                <p className="text-xs text-slate-500 italic py-2">No purchases recorded yet for this supplier.</p>
              ) : (
                <div className="border border-slate-800 rounded-xl overflow-hidden max-h-48 overflow-y-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-950 text-slate-400 border-b border-slate-800">
                      <tr>
                        <th className="p-2">PO #</th>
                        <th className="p-2">Date</th>
                        <th className="p-2 text-right">Total</th>
                        <th className="p-2 text-right">Balance Due</th>
                        <th className="p-2 text-center">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800">
                      {supplierPurchases.map((po: any) => (
                        <tr key={po.id}>
                          <td className="p-2 font-mono text-cyan-400 font-semibold">{po.purchaseNumber}</td>
                          <td className="p-2 text-slate-400">{formatDate(po.date)}</td>
                          <td className="p-2 text-right font-mono">{formatCurrency(po.total, settings.currency)}</td>
                          <td className="p-2 text-right font-mono text-amber-400">{formatCurrency(po.outstanding, settings.currency)}</td>
                          <td className="p-2 text-center">
                            <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-950 border border-slate-800 text-slate-300">
                              {po.paymentStatus || 'Paid'}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>

            {/* Payment Disbursements History */}
            <div className="space-y-2">
              <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                <DollarSign size={14} className="text-amber-400" />
                <span>Payments Disbursed History ({supplierPayments.length})</span>
              </h4>
              {supplierPayments.length === 0 ? (
                <p className="text-xs text-slate-500 italic py-2">No separate payments recorded yet.</p>
              ) : (
                <div className="border border-slate-800 rounded-xl overflow-hidden max-h-40 overflow-y-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-950 text-slate-400 border-b border-slate-800">
                      <tr>
                        <th className="p-2">Date</th>
                        <th className="p-2">Method</th>
                        <th className="p-2">Reference</th>
                        <th className="p-2 text-right">Amount Paid</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800">
                      {supplierPayments.map((p: any) => (
                        <tr key={p.id}>
                          <td className="p-2 text-slate-400">{formatDate(p.date)}</td>
                          <td className="p-2 text-slate-300">{p.paymentMethod || 'Bank Transfer'}</td>
                          <td className="p-2 text-slate-500">{p.reference || '-'}</td>
                          <td className="p-2 text-right font-mono font-bold text-amber-400">
                            {formatCurrency(p.amount, settings.currency)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>

            <div className="flex justify-end pt-2 border-t border-slate-800">
              <button
                onClick={closeViewSupplier}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold rounded-xl"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add / Edit Supplier Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-xs overflow-y-auto">
          <div className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl p-6 sm:p-7 space-y-5 my-8">
            <div className="flex justify-between items-center border-b border-slate-800 pb-4">
              <h3 className="text-lg sm:text-xl font-bold text-white flex items-center gap-2">
                <Truck className="text-cyan-400" size={22} />
                <span>{editingSupplier ? 'Edit Supplier' : 'Add New Supplier'}</span>
              </h3>
              <button onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:text-white p-1 rounded-lg">
                <X size={20} />
              </button>
            </div>

            {formError && (
              <div className="p-3 bg-rose-950/70 border border-rose-800 text-rose-300 text-xs rounded-xl flex items-center gap-2">
                <AlertTriangle size={16} />
                <span>{formError}</span>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4 text-xs sm:text-sm">
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-300">Supplier / Company Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Al-Bahar Equipment Wholesale"
                  value={name}
                  onChange={e => setName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-white text-sm focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-300">Mobile / Phone</label>
                  <input
                    type="text"
                    placeholder="+965 2481 0000"
                    value={mobile}
                    onChange={e => setMobile(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-white text-sm focus:outline-none focus:border-cyan-500 font-mono"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-300">Email Address</label>
                  <input
                    type="email"
                    placeholder="sales@albahar.com"
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-white text-sm focus:outline-none focus:border-cyan-500"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-300">Warehouse / Office Address</label>
                <input
                  type="text"
                  placeholder="Ardiya Industrial Area, Plot 12"
                  value={address}
                  onChange={e => setAddress(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-white text-sm focus:outline-none focus:border-cyan-500"
                />
              </div>

              {!editingSupplier && (
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-300">
                    Opening Payable Balance ({settings.currency})
                  </label>
                  <input
                    type="number"
                    step="0.001"
                    min="0"
                    placeholder="0.000"
                    value={openingBalance}
                    onChange={e => setOpeningBalance(e.target.value === '' ? '' : Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-white text-sm focus:outline-none focus:border-cyan-500 font-mono"
                  />
                  <p className="text-[11px] text-slate-500">
                    Pre-existing balance owed to supplier prior to system setup.
                  </p>
                </div>
              )}

              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-300">Notes / Credit Terms</label>
                <textarea
                  rows={2}
                  placeholder="Credit facility details, contact person, payment terms..."
                  value={notes}
                  onChange={e => setNotes(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-white text-xs focus:outline-none focus:border-cyan-500 resize-none"
                />
              </div>

              <div className="flex justify-end gap-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-sm font-medium rounded-xl transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="px-5 py-2 bg-cyan-600 hover:bg-cyan-500 text-white text-sm font-medium rounded-xl transition cursor-pointer flex items-center gap-2 shadow-lg shadow-cyan-950 disabled:opacity-50"
                >
                  {saving && <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />}
                  <span>{editingSupplier ? 'Update Supplier' : 'Save Supplier'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
