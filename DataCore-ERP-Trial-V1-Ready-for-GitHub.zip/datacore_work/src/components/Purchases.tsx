import { erpCollection, erpDoc } from '../tenant';
import React, { useState, useEffect } from 'react';
import { db } from '../firebase';
import {
  collection,
  addDoc,
  getDocs,
  updateDoc,
  deleteDoc,
  doc,
  serverTimestamp,
  runTransaction
} from 'firebase/firestore';
import { PurchaseOrder, Supplier, Product, PurchaseItem, Settings } from '../types';
import { formatCurrency, generateCode, formatDate } from '../utils/formatters';
import { PrintInvoiceModal } from './PrintInvoiceModal';
import {
  ShoppingCart,
  Plus,
  Search,
  Printer,
  Trash2,
  Eye,
  AlertTriangle,
  X,
  PlusCircle,
  MinusCircle,
  Truck,
  Package,
  Calendar,
  DollarSign
} from 'lucide-react';

interface PurchasesProps {
  settings: Settings;
  onNavigateToSuppliers?: () => void;
  onNavigateToInventory?: () => void;
}

export const Purchases: React.FC<PurchasesProps> = ({
  settings,
  onNavigateToSuppliers,
  onNavigateToInventory,
}) => {
  const [purchases, setPurchases] = useState<PurchaseOrder[]>([]);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');

  // Form View State
  const [isCreating, setIsCreating] = useState(false);
  const [editingPurchase, setEditingPurchase] = useState<PurchaseOrder | null>(null);
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  // Print & Delete
  const [printPurchase, setPrintPurchase] = useState<PurchaseOrder | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  // Form Fields
  const [selectedSupplierId, setSelectedSupplierId] = useState('');
  const [purchaseDate, setPurchaseDate] = useState(new Date().toISOString().slice(0, 10));
  const [items, setItems] = useState<PurchaseItem[]>([]);
  const [paidAmount, setPaidAmount] = useState<number | ''>(0);
  const [notes, setNotes] = useState('');

  const loadData = async () => {
    try {
      setLoading(true);
      const [puSnap, supSnap, pSnap] = await Promise.all([
        getDocs(erpCollection('purchases')),
        getDocs(erpCollection('suppliers')),
        getDocs(erpCollection('products')),
      ]);

      const puList: PurchaseOrder[] = puSnap.docs.map(d => ({ id: d.id, ...d.data() } as PurchaseOrder));
      puList.sort((a, b) => (b.purchaseNumber || '').localeCompare(a.purchaseNumber || ''));
      setPurchases(puList);

      setSuppliers(supSnap.docs.map(d => ({ id: d.id, ...d.data() } as Supplier)));
      setProducts(pSnap.docs.map(d => ({ id: d.id, ...d.data() } as Product)));
    } catch (err) {
      console.error('Error loading purchase data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const openNewPurchase = () => {
    setEditingPurchase(null);
    setSelectedSupplierId(suppliers[0]?.id || '');
    setPurchaseDate(new Date().toISOString().slice(0, 10));
    setNotes('');
    setFormError(null);

    if (products.length > 0) {
      const p = products[0];
      setItems([
        {
          productId: p.id,
          productName: p.name,
          sku: p.sku || p.code,
          currentStock: p.stock,
          quantity: 1,
          purchasePrice: p.purchasePrice || 0,
          discount: 0,
          tax: 0,
          lineTotal: p.purchasePrice || 0,
        },
      ]);
      setPaidAmount(p.purchasePrice || 0);
    } else {
      setItems([]);
      setPaidAmount(0);
    }
    setIsCreating(true);
  };

  const openEditPurchase = (po: PurchaseOrder) => {
    setEditingPurchase(po);
    setSelectedSupplierId(po.supplierId);
    setPurchaseDate(po.date || new Date().toISOString().slice(0, 10));
    setItems(po.items.map(it => ({ ...it })));
    setPaidAmount(po.paid);
    setNotes(po.notes || '');
    setFormError(null);
    setIsCreating(true);
  };

  const handleAddItem = () => {
    if (products.length === 0) return;
    const p = products[0];
    setItems(prev => [
      ...prev,
      {
        productId: p.id,
        productName: p.name,
        sku: p.sku || p.code,
        currentStock: p.stock,
        quantity: 1,
        purchasePrice: p.purchasePrice || 0,
        discount: 0,
        tax: 0,
        lineTotal: p.purchasePrice || 0,
      },
    ]);
  };

  const handleRemoveItem = (idx: number) => {
    setItems(prev => prev.filter((_, i) => i !== idx));
  };

  const handleProductChange = (idx: number, productId: string) => {
    const prod = products.find(p => p.id === productId);
    if (!prod) return;
    setItems(prev => {
      const copy = [...prev];
      const cur = copy[idx];
      const qty = cur.quantity || 1;
      const price = prod.purchasePrice || 0;
      const sub = qty * price;
      const disc = cur.discount || 0;
      const tax = cur.tax || 0;
      const total = Math.max(0, sub - disc + tax);
      copy[idx] = {
        ...cur,
        productId: prod.id,
        productName: prod.name,
        sku: prod.sku || prod.code,
        currentStock: prod.stock,
        purchasePrice: price,
        lineTotal: total,
      };
      return copy;
    });
  };

  const handleItemFieldChange = (
    idx: number,
    field: 'quantity' | 'purchasePrice' | 'discount' | 'tax',
    val: number
  ) => {
    setItems(prev => {
      const copy = [...prev];
      const item = { ...copy[idx], [field]: val };
      const sub = (item.quantity || 0) * (item.purchasePrice || 0);
      const disc = item.discount || 0;
      const tax = item.tax || 0;
      item.lineTotal = Math.max(0, sub - disc + tax);
      copy[idx] = item;
      return copy;
    });
  };

  // Calculations
  const subtotal = items.reduce((acc, it) => acc + (it.quantity || 0) * (it.purchasePrice || 0), 0);
  const totalDiscount = items.reduce((acc, it) => acc + (it.discount || 0), 0);
  const totalTax = items.reduce((acc, it) => acc + (it.tax || 0), 0);
  const grandTotal = Math.max(0, subtotal - totalDiscount + totalTax);
  const paid = typeof paidAmount === 'number' ? paidAmount : 0;
  const outstanding = Math.max(0, grandTotal - paid);

  let paymentStatus: 'Paid' | 'Partially Paid' | 'Unpaid' = 'Unpaid';
  if (paid >= grandTotal && grandTotal > 0) {
    paymentStatus = 'Paid';
  } else if (paid > 0 && paid < grandTotal) {
    paymentStatus = 'Partially Paid';
  }

  const handleSavePurchase = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    if (!selectedSupplierId) {
      setFormError('Please select a supplier for this purchase order.');
      return;
    }
    if (items.length === 0) {
      setFormError('Please add at least one product item to the purchase order.');
      return;
    }

    for (const it of items) {
      if (it.quantity <= 0) {
        setFormError(`Quantity for "${it.productName}" must be greater than zero.`);
        return;
      }
    }

    const supplier = suppliers.find(s => s.id === selectedSupplierId);
    if (!supplier) {
      setFormError('Supplier not found.');
      return;
    }

    setSaving(true);
    try {
      await runTransaction(db, async transaction => {
        // ================= 1. ALL READS FIRST =================
        let existingPoData: PurchaseOrder | null = null;
        let poRef: any = null;
        if (editingPurchase) {
          poRef = erpDoc('purchases', editingPurchase.id);
          const poDoc = await transaction.get(poRef);
          if (!poDoc.exists()) {
            throw new Error(`Purchase order ${editingPurchase.purchaseNumber} no longer exists in database.`);
          }
          existingPoData = poDoc.data() as PurchaseOrder;
        }

        // Collect all affected product IDs (new items + old items if editing)
        const affectedProductIds = new Set<string>();
        for (const it of items) {
          if (it.productId) affectedProductIds.add(it.productId);
        }
        if (existingPoData) {
          for (const oldIt of existingPoData.items || []) {
            if (oldIt.productId) affectedProductIds.add(oldIt.productId);
          }
        }

        // Read all affected product documents
        const productDocsMap = new Map<string, { ref: any; doc: any }>();
        for (const pid of affectedProductIds) {
          const pRef = erpDoc('products', pid);
          const pDoc = await transaction.get(pRef);
          productDocsMap.set(pid, { ref: pRef, doc: pDoc });
        }

        // Collect all affected supplier IDs (new supplier + old supplier if changed)
        const affectedSupplierIds = new Set<string>();
        affectedSupplierIds.add(selectedSupplierId);
        if (existingPoData && existingPoData.supplierId) {
          affectedSupplierIds.add(existingPoData.supplierId);
        }

        // Read all affected supplier documents
        const supplierDocsMap = new Map<string, { ref: any; doc: any }>();
        for (const sid of affectedSupplierIds) {
          const sRef = erpDoc('suppliers', sid);
          const sDoc = await transaction.get(sRef);
          supplierDocsMap.set(sid, { ref: sRef, doc: sDoc });
        }

        // ================= 2. VALIDATION & CALCULATIONS (SNAPSHOT-BASED) =================
        // Validate new supplier exists
        const newSupEntry = supplierDocsMap.get(selectedSupplierId);
        if (!newSupEntry || !newSupEntry.doc.exists()) {
          throw new Error('Supplier no longer exists in database.');
        }

        // Validate old supplier exists if changed
        let oldSupEntry: { ref: any; doc: any } | null = null;
        if (existingPoData && existingPoData.supplierId !== selectedSupplierId) {
          oldSupEntry = supplierDocsMap.get(existingPoData.supplierId) || null;
          if (!oldSupEntry || !oldSupEntry.doc.exists()) {
            throw new Error('Original supplier no longer exists in database.');
          }
        }

        // Aggregate quantities per product across all item rows
        const newQtyByProduct = new Map<string, number>();
        for (const it of items) {
          newQtyByProduct.set(it.productId, (newQtyByProduct.get(it.productId) || 0) + Number(it.quantity || 0));
        }

        const oldQtyByProduct = new Map<string, number>();
        if (existingPoData) {
          for (const oldIt of existingPoData.items || []) {
            oldQtyByProduct.set(oldIt.productId, (oldQtyByProduct.get(oldIt.productId) || 0) + Number(oldIt.quantity || 0));
          }
        }

        // Verify all affected products exist and calculate net stock changes
        const productFinalStocks = new Map<string, number>();
        for (const pid of affectedProductIds) {
          const pEntry = productDocsMap.get(pid);
          if (!pEntry || !pEntry.doc.exists()) {
            throw new Error(`Product with ID "${pid}" does not exist in database.`);
          }
          const curStock = Number(pEntry.doc.data().stock || 0);
          const oldQty = oldQtyByProduct.get(pid) || 0;
          const newQty = newQtyByProduct.get(pid) || 0;
          // Reversing old purchase subtracts oldQty, applying new purchase adds newQty
          const finalStock = curStock - oldQty + newQty;

          if (!settings.allowNegativeStock && finalStock < 0) {
            const pName = pEntry.doc.data().name || pid;
            throw new Error(
              `Insufficient stock for "${pName}". Current stock: ${curStock}. Reversing previous purchase leaves stock at ${finalStock}, which is negative.`
            );
          }
          productFinalStocks.set(pid, finalStock);
        }

        // Calculate supplier payable balances from database snapshots
        const newSupCurrentPayable = Number(newSupEntry.doc.data().payable || 0);
        let finalNewSupPayable: number;
        let finalOldSupPayable: number | null = null;

        if (!existingPoData) {
          finalNewSupPayable = newSupCurrentPayable + outstanding;
        } else if (existingPoData.supplierId === selectedSupplierId) {
          const oldOutstanding = Number(existingPoData.outstanding || 0);
          finalNewSupPayable = newSupCurrentPayable - oldOutstanding + outstanding;
        } else {
          const oldOutstanding = Number(existingPoData.outstanding || 0);
          const oldSupCurrentPayable = Number(oldSupEntry!.doc.data().payable || 0);
          finalOldSupPayable = oldSupCurrentPayable - oldOutstanding;
          finalNewSupPayable = newSupCurrentPayable + outstanding;
        }

        // ================= 3. ALL WRITES STAGED ATOMICALLY =================
        for (const [pid, finalStock] of productFinalStocks.entries()) {
          const pEntry = productDocsMap.get(pid)!;
          const lastItem = items.find(it => it.productId === pid);
          transaction.update(pEntry.ref, {
            stock: finalStock,
            ...(lastItem?.purchasePrice !== undefined ? { purchasePrice: lastItem.purchasePrice } : {}),
            updatedAt: serverTimestamp(),
          });
        }

        transaction.update(newSupEntry.ref, {
          payable: finalNewSupPayable,
          updatedAt: serverTimestamp(),
        });
        if (oldSupEntry && finalOldSupPayable !== null) {
          transaction.update(oldSupEntry.ref, {
            payable: finalOldSupPayable,
            updatedAt: serverTimestamp(),
          });
        }

        const purchaseNumber = existingPoData
          ? existingPoData.purchaseNumber
          : generateCode(settings.purchasePrefix || 'PO', purchases.length);

        const poData = {
          purchaseNumber,
          supplierId: selectedSupplierId,
          supplierName: newSupEntry.doc.data().name || supplier.name,
          supplierMobile: newSupEntry.doc.data().mobile || supplier.mobile || '',
          date: purchaseDate,
          items,
          subtotal,
          discount: totalDiscount,
          tax: totalTax,
          total: grandTotal,
          paid,
          outstanding,
          paymentStatus,
          notes: notes.trim(),
          updatedAt: serverTimestamp(),
        };

        if (existingPoData) {
          transaction.update(poRef, poData);
        } else {
          const newPoRef = doc(erpCollection('purchases'));
          transaction.set(newPoRef, {
            ...poData,
            createdAt: serverTimestamp(),
          });
        }
      });

      setIsCreating(false);
      setEditingPurchase(null);
      await loadData();
    } catch (err: any) {
      console.error('Error saving purchase:', err);
      setFormError(err.message || 'Failed to complete purchase transaction.');
    } finally {
      setSaving(false);
    }
  };

  const handleDeletePurchase = async (id: string) => {
    const poToDelete = purchases.find(p => p.id === id);
    if (!poToDelete) return;

    try {
      await runTransaction(db, async transaction => {
        // 1. ALL READS FIRST
        const poRef = erpDoc('purchases', id);
        const poDoc = await transaction.get(poRef);
        if (!poDoc.exists()) {
          throw new Error('Purchase order no longer exists in database.');
        }
        const poData = poDoc.data() as PurchaseOrder;

        // Aggregate quantities per product
        const oldQtyByProduct = new Map<string, number>();
        for (const item of poData.items || []) {
          oldQtyByProduct.set(item.productId, (oldQtyByProduct.get(item.productId) || 0) + Number(item.quantity || 0));
        }

        // Read all product docs
        const productDocsMap = new Map<string, { ref: any; doc: any }>();
        for (const pid of oldQtyByProduct.keys()) {
          const pRef = erpDoc('products', pid);
          const pDoc = await transaction.get(pRef);
          productDocsMap.set(pid, { ref: pRef, doc: pDoc });
        }

        // Read supplier doc
        const sRef = erpDoc('suppliers', poData.supplierId);
        const sDoc = await transaction.get(sRef);

        // 2. VALIDATION
        if (!sDoc.exists()) {
          throw new Error('Supplier no longer exists in database.');
        }
        for (const [pid, oldQty] of oldQtyByProduct.entries()) {
          const pEntry = productDocsMap.get(pid);
          if (!pEntry || !pEntry.doc.exists()) {
            throw new Error(`Product ${pid} no longer exists in database.`);
          }
          const curStock = Number(pEntry.doc.data().stock || 0);
          const finalStock = curStock - oldQty;
          if (!settings.allowNegativeStock && finalStock < 0) {
            const pName = pEntry.doc.data().name || pid;
            throw new Error(
              `Cannot delete purchase: stock for "${pName}" would become ${finalStock}.`
            );
          }
        }

        // 3. ALL WRITES AFTER ALL READS
        // Reverse inventory stock addition (reduce stock by purchased quantities)
        for (const [pid, oldQty] of oldQtyByProduct.entries()) {
          const pEntry = productDocsMap.get(pid)!;
          const currentStock = Number(pEntry.doc.data().stock || 0);
          transaction.update(pEntry.ref, {
            stock: currentStock - oldQty,
            updatedAt: serverTimestamp(),
          });
        }

        // Reverse supplier payable balance
        const curPayable = Number(sDoc.data().payable || 0);
        const poOutstanding = Number(poData.outstanding || 0);
        transaction.update(sRef, {
          payable: curPayable - poOutstanding,
          updatedAt: serverTimestamp(),
        });

        // Delete doc
        transaction.delete(poRef);
      });

      setDeleteConfirmId(null);
      await loadData();
    } catch (err: any) {
      console.error('Error deleting purchase:', err);
    }
  };

  const filteredPurchases = purchases.filter(p => {
    const matchesSearch =
      p.purchaseNumber.toLowerCase().includes(search.toLowerCase()) ||
      p.supplierName.toLowerCase().includes(search.toLowerCase());
    const matchesStatus = statusFilter === 'ALL' || p.paymentStatus === statusFilter;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-slate-900 border border-slate-800 p-4 sm:p-5 rounded-2xl">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-white flex items-center gap-2.5">
            <ShoppingCart className="text-cyan-400" size={26} />
            <span>Purchase Orders & Procurement</span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 mt-0.5">
            Record supplier orders, automatically increase warehouse stock, and track accounts payable.
          </p>
        </div>
        {!isCreating && (
          <button
            onClick={openNewPurchase}
            className="bg-cyan-600 hover:bg-cyan-500 text-white font-medium px-4 py-2.5 rounded-xl flex items-center gap-2 transition cursor-pointer text-sm shadow-lg shadow-cyan-950 w-full sm:w-auto justify-center"
          >
            <Plus size={18} />
            <span>New Purchase Order</span>
          </button>
        )}
      </div>

      {isCreating ? (
        /* ================= CREATE / EDIT PURCHASE FORM ================= */
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-7 space-y-6 shadow-xl">
          <div className="flex justify-between items-center border-b border-slate-800 pb-4">
            <div>
              <span className="text-xs font-mono text-cyan-400 uppercase tracking-widest font-semibold">
                {editingPurchase ? editingPurchase.purchaseNumber : 'NEW PROCUREMENT'}
              </span>
              <h3 className="text-lg sm:text-xl font-bold text-white mt-0.5">
                {editingPurchase ? 'Edit Purchase Order' : 'Create Purchase Order'}
              </h3>
            </div>
            <button
              onClick={() => setIsCreating(false)}
              className="text-slate-400 hover:text-white p-1 rounded-lg"
            >
              <X size={20} />
            </button>
          </div>

          {formError && (
            <div className="p-3 bg-rose-950/80 border border-rose-800 text-rose-300 text-xs rounded-xl flex items-center gap-2">
              <AlertTriangle size={16} className="shrink-0" />
              <span>{formError}</span>
            </div>
          )}

          <form onSubmit={handleSavePurchase} className="space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-300 flex justify-between">
                  <span>Vendor / Supplier *</span>
                  {suppliers.length === 0 && (
                    <button
                      type="button"
                      onClick={onNavigateToSuppliers}
                      className="text-cyan-400 hover:underline text-[11px]"
                    >
                      + Add Supplier First
                    </button>
                  )}
                </label>
                {suppliers.length === 0 ? (
                  <div className="p-2.5 bg-amber-950/40 border border-amber-800/80 rounded-xl text-amber-300 text-xs flex items-center justify-between">
                    <span>No suppliers found</span>
                    <button
                      type="button"
                      onClick={onNavigateToSuppliers}
                      className="text-cyan-400 font-medium hover:underline ml-2"
                    >
                      Create Supplier
                    </button>
                  </div>
                ) : (
                  <select
                    required
                    value={selectedSupplierId}
                    onChange={e => setSelectedSupplierId(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-white text-sm focus:outline-none focus:border-cyan-500"
                  >
                    <option value="" disabled>
                      Select Supplier
                    </option>
                    {suppliers.map(s => (
                      <option key={s.id} value={s.id}>
                        {s.name} ({s.code}) - Payable: {formatCurrency(s.payable, settings.currency)}
                      </option>
                    ))}
                  </select>
                )}
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-300">Purchase Date</label>
                <input
                  type="date"
                  required
                  value={purchaseDate}
                  onChange={e => setPurchaseDate(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-white text-sm focus:outline-none focus:border-cyan-500 font-mono"
                />
              </div>
            </div>

            {/* Products Selector Table */}
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                  <Package size={14} className="text-cyan-400" />
                  <span>Purchased Product Items ({items.length})</span>
                </h4>
                {products.length === 0 ? (
                  <button
                    type="button"
                    onClick={onNavigateToInventory}
                    className="text-xs text-cyan-400 hover:underline"
                  >
                    + Add Product in Inventory
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={handleAddItem}
                    className="text-xs bg-slate-800 hover:bg-slate-750 text-cyan-300 border border-cyan-500/30 px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition cursor-pointer"
                  >
                    <PlusCircle size={14} />
                    <span>Add Item Line</span>
                  </button>
                )}
              </div>

              {products.length === 0 ? (
                <div className="p-4 bg-amber-950/40 border border-amber-800/80 rounded-xl text-amber-300 text-xs">
                  No products available in inventory. Please add products to inventory first.
                </div>
              ) : items.length === 0 ? (
                <div className="p-6 text-center border border-dashed border-slate-800 rounded-xl text-slate-500 text-xs">
                  No items added yet. Click &quot;Add Item Line&quot; above.
                </div>
              ) : (
                <div className="border border-slate-800 rounded-xl overflow-x-auto">
                  <table className="w-full text-left text-xs min-w-[700px]">
                    <thead className="bg-slate-950 text-slate-400 border-b border-slate-800 uppercase font-semibold">
                      <tr>
                        <th className="py-2.5 px-3">Product Item</th>
                        <th className="py-2.5 px-3 w-28 text-center">Current Stock</th>
                        <th className="py-2.5 px-3 w-24 text-center">Add Qty</th>
                        <th className="py-2.5 px-3 w-32 text-right">Cost Price</th>
                        <th className="py-2.5 px-3 w-24 text-right">Discount</th>
                        <th className="py-2.5 px-3 w-24 text-right">Tax</th>
                        <th className="py-2.5 px-3 w-32 text-right">Line Total</th>
                        <th className="py-2.5 px-2 w-10"></th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/80">
                      {items.map((item, idx) => (
                        <tr key={idx} className="hover:bg-slate-950/30">
                          <td className="p-2.5">
                            <select
                              value={item.productId}
                              onChange={e => handleProductChange(idx, e.target.value)}
                              className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-white text-xs focus:outline-none focus:border-cyan-500 font-medium"
                            >
                              {products.map(p => (
                                <option key={p.id} value={p.id}>
                                  {p.name} ({p.sku || p.code}) - current stock: {p.stock}
                                </option>
                              ))}
                            </select>
                          </td>
                          <td className="p-2.5 text-center font-mono">
                            <span className="bg-slate-950 border border-slate-800 px-2 py-0.5 rounded-md text-slate-300">
                              {item.currentStock}
                            </span>
                          </td>
                          <td className="p-2.5">
                            <input
                              type="number"
                              min="1"
                              value={item.quantity}
                              onChange={e =>
                                handleItemFieldChange(idx, 'quantity', Math.max(1, Number(e.target.value)))
                              }
                              className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-center text-xs font-mono font-bold text-white focus:outline-none focus:border-cyan-500"
                            />
                          </td>
                          <td className="p-2.5">
                            <input
                              type="number"
                              step="0.001"
                              min="0"
                              value={item.purchasePrice}
                              onChange={e =>
                                handleItemFieldChange(idx, 'purchasePrice', Number(e.target.value))
                              }
                              className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-right text-xs font-mono text-cyan-400 font-semibold focus:outline-none focus:border-cyan-500"
                            />
                          </td>
                          <td className="p-2.5">
                            <input
                              type="number"
                              step="0.001"
                              min="0"
                              value={item.discount}
                              onChange={e =>
                                handleItemFieldChange(idx, 'discount', Number(e.target.value))
                              }
                              className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-right text-xs font-mono text-slate-300 focus:outline-none focus:border-cyan-500"
                            />
                          </td>
                          <td className="p-2.5">
                            <input
                              type="number"
                              step="0.001"
                              min="0"
                              value={item.tax}
                              onChange={e =>
                                handleItemFieldChange(idx, 'tax', Number(e.target.value))
                              }
                              className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-right text-xs font-mono text-slate-300 focus:outline-none focus:border-cyan-500"
                            />
                          </td>
                          <td className="p-2.5 text-right font-mono font-bold text-white">
                            {formatCurrency(item.lineTotal, settings.currency)}
                          </td>
                          <td className="p-2.5 text-center">
                            <button
                              type="button"
                              onClick={() => handleRemoveItem(idx)}
                              className="text-slate-500 hover:text-rose-400 p-1 transition"
                            >
                              <MinusCircle size={16} />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>

            {/* Bottom summary and payment section */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-2 border-t border-slate-800">
              <div className="space-y-3">
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-300">Purchase Order Notes</label>
                  <textarea
                    rows={3}
                    placeholder="Delivery terms, supplier invoice reference number, payment conditions..."
                    value={notes}
                    onChange={e => setNotes(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-white text-xs focus:outline-none focus:border-cyan-500 resize-none"
                  />
                </div>
              </div>

              {/* Financial Calculation Summary Card */}
              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2 text-xs font-mono">
                <div className="flex justify-between text-slate-400">
                  <span>Subtotal:</span>
                  <span>{formatCurrency(subtotal, settings.currency)}</span>
                </div>
                {totalDiscount > 0 && (
                  <div className="flex justify-between text-slate-400">
                    <span>Discount:</span>
                    <span>- {formatCurrency(totalDiscount, settings.currency)}</span>
                  </div>
                )}
                {totalTax > 0 && (
                  <div className="flex justify-between text-slate-400">
                    <span>Tax:</span>
                    <span>+ {formatCurrency(totalTax, settings.currency)}</span>
                  </div>
                )}
                <div className="flex justify-between text-white font-bold text-sm pt-2 border-t border-slate-800">
                  <span>Grand Total:</span>
                  <span className="text-cyan-400">{formatCurrency(grandTotal, settings.currency)}</span>
                </div>

                <div className="pt-3 border-t border-slate-800 space-y-2">
                  <div className="flex items-center justify-between gap-3">
                    <span className="text-slate-300 font-semibold">Amount Paid ({settings.currency}):</span>
                    <input
                      type="number"
                      step="0.001"
                      min="0"
                      value={paidAmount}
                      onChange={e => setPaidAmount(e.target.value === '' ? '' : Number(e.target.value))}
                      className="w-36 bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-right font-bold text-emerald-400 focus:outline-none focus:border-cyan-500"
                    />
                  </div>
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-slate-400">Payment Status:</span>
                    <span
                      className={`px-2 py-0.5 rounded-full font-bold uppercase text-[10px] ${
                        paymentStatus === 'Paid'
                          ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                          : paymentStatus === 'Partially Paid'
                          ? 'bg-amber-950 text-amber-300 border border-amber-800'
                          : 'bg-rose-950 text-rose-300 border border-rose-800'
                      }`}
                    >
                      {paymentStatus}
                    </span>
                  </div>
                  <div className="flex justify-between items-center text-xs pt-1 border-t border-slate-800/80">
                    <span className="text-slate-400 font-semibold">Payable Balance (Due):</span>
                    <span className="text-amber-400 font-bold">
                      {formatCurrency(outstanding, settings.currency)}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Actions Bar */}
            <div className="flex justify-end gap-3 pt-4 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setIsCreating(false)}
                className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-sm font-medium transition"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={saving}
                className="px-6 py-2.5 bg-cyan-600 hover:bg-cyan-500 text-white rounded-xl text-sm font-semibold transition cursor-pointer flex items-center gap-2 shadow-lg shadow-cyan-950 disabled:opacity-50"
              >
                {saving && (
                  <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                )}
                <span>{editingPurchase ? 'Update Purchase Order' : 'Confirm Purchase & Add Stock'}</span>
              </button>
            </div>
          </form>
        </div>
      ) : (
        /* ================= PURCHASE HISTORY TABLE ================= */
        <div className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 bg-slate-900/70 border border-slate-800 p-3 sm:p-4 rounded-xl">
            <div className="relative">
              <Search size={18} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" />
              <input
                type="text"
                placeholder="Search PO number or supplier name..."
                value={search}
                onChange={e => setSearch(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-10 pr-4 py-2 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-cyan-500"
              />
            </div>
            <div>
              <select
                value={statusFilter}
                onChange={e => setStatusFilter(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2 text-white text-sm focus:outline-none focus:border-cyan-500"
              >
                <option value="ALL">All Payment Statuses</option>
                <option value="Paid">Fully Paid</option>
                <option value="Partially Paid">Partially Paid</option>
                <option value="Unpaid">Unpaid (Full Due)</option>
              </select>
            </div>
          </div>

          {loading ? (
            <div className="text-center py-16 bg-slate-900/50 border border-slate-800 rounded-2xl">
              <span className="inline-block w-8 h-8 border-3 border-cyan-400 border-t-transparent rounded-full animate-spin" />
              <p className="text-slate-400 text-sm mt-3">Loading purchase records...</p>
            </div>
          ) : filteredPurchases.length === 0 ? (
            <div className="text-center py-14 bg-slate-900/40 border border-slate-800 rounded-2xl space-y-3">
              <ShoppingCart className="mx-auto text-slate-600" size={44} />
              <p className="text-slate-300 font-medium text-base">No purchase orders found</p>
              <p className="text-slate-500 text-xs max-w-sm mx-auto">
                {search || statusFilter !== 'ALL'
                  ? 'No purchase orders match your filters.'
                  : 'Record purchases from suppliers to increase inventory stock and track payables.'}
              </p>
              <button
                onClick={openNewPurchase}
                className="mt-2 bg-slate-800 hover:bg-slate-750 text-cyan-400 border border-cyan-500/30 px-4 py-2 rounded-xl text-sm font-medium transition cursor-pointer"
              >
                + Record First Purchase
              </button>
            </div>
          ) : (
            <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-sm">
                  <thead className="bg-slate-950/80 text-slate-400 border-b border-slate-800 text-xs uppercase tracking-wider">
                    <tr>
                      <th className="py-3 px-4">PO #</th>
                      <th className="py-3 px-4">Date</th>
                      <th className="py-3 px-4">Supplier</th>
                      <th className="py-3 px-4 text-center">Items</th>
                      <th className="py-3 px-4 text-right">Grand Total</th>
                      <th className="py-3 px-4 text-right">Paid</th>
                      <th className="py-3 px-4 text-right">Payable Due</th>
                      <th className="py-3 px-4 text-center">Status</th>
                      <th className="py-3 px-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60 text-slate-200">
                    {filteredPurchases.map(po => (
                      <tr key={po.id} className="hover:bg-slate-800/40 transition">
                        <td className="py-3.5 px-4 font-mono text-xs font-bold text-cyan-300">
                          {po.purchaseNumber}
                        </td>
                        <td className="py-3.5 px-4 text-slate-400 text-xs font-mono">
                          {formatDate(po.date)}
                        </td>
                        <td className="py-3.5 px-4 font-medium text-white max-w-[180px] truncate">
                          {po.supplierName}
                        </td>
                        <td className="py-3.5 px-4 text-center text-xs font-mono text-slate-400">
                          {po.items?.length || 0}
                        </td>
                        <td className="py-3.5 px-4 text-right font-mono text-xs font-bold text-white">
                          {formatCurrency(po.total, settings.currency)}
                        </td>
                        <td className="py-3.5 px-4 text-right font-mono text-xs text-emerald-400">
                          {formatCurrency(po.paid, settings.currency)}
                        </td>
                        <td className="py-3.5 px-4 text-right font-mono text-xs font-semibold text-amber-400">
                          {formatCurrency(po.outstanding, settings.currency)}
                        </td>
                        <td className="py-3.5 px-4 text-center">
                          <span
                            className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                              po.paymentStatus === 'Paid'
                                ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-800'
                                : po.paymentStatus === 'Partially Paid'
                                ? 'bg-amber-950/80 text-amber-300 border border-amber-800'
                                : 'bg-rose-950/80 text-rose-300 border border-rose-800'
                            }`}
                          >
                            {po.paymentStatus}
                          </span>
                        </td>
                        <td className="py-3.5 px-4 text-right">
                          <div className="flex items-center justify-end gap-1">
                            <button
                              title="Print Purchase Order"
                              onClick={() => setPrintPurchase(po)}
                              className="p-1.5 rounded-lg text-slate-400 hover:text-cyan-300 hover:bg-slate-800 transition"
                            >
                              <Printer size={16} />
                            </button>
                            <button
                              title="Edit Purchase Order"
                              onClick={() => openEditPurchase(po)}
                              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
                            >
                              <Eye size={16} />
                            </button>
                            <button
                              title="Delete Purchase Order"
                              onClick={() => setDeleteConfirmId(po.id)}
                              className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-slate-800 transition"
                            >
                              <Trash2 size={16} />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteConfirmId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-sm w-full p-6 space-y-4">
            <h3 className="text-lg font-bold text-white flex items-center gap-2 text-rose-400">
              <AlertTriangle size={20} />
              Confirm Delete Purchase Order
            </h3>
            <p className="text-sm text-slate-300">
              Deleting this purchase order will automatically <strong className="text-white">reverse the inventory stock addition</strong> and decrease the supplier payable balance.
            </p>
            <div className="flex justify-end gap-3 pt-2">
              <button
                onClick={() => setDeleteConfirmId(null)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-sm font-medium rounded-xl transition"
              >
                Cancel
              </button>
              <button
                onClick={() => handleDeletePurchase(deleteConfirmId)}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white text-sm font-medium rounded-xl transition cursor-pointer"
              >
                Yes, Reverse & Delete
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Print Modal */}
      {printPurchase && (
        <PrintInvoiceModal
          type="purchase"
          data={printPurchase}
          settings={settings}
          onClose={() => setPrintPurchase(null)}
        />
      )}
    </div>
  );
};
