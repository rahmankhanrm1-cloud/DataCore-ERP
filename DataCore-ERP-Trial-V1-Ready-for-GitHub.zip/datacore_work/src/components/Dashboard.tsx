import { erpCollection, erpDoc } from '../tenant';
import React, { useState, useEffect } from 'react';
import { db } from '../firebase';
import { collection, getDocs } from 'firebase/firestore';
import { SaleInvoice, PurchaseOrder, Product, Customer, Supplier, Expense, PaymentRecord, Employee, Settings } from '../types';
import { formatCurrency, formatDate } from '../utils/formatters';
import {
  TrendingUp,
  TrendingDown,
  DollarSign,
  ShoppingCart,
  FileText,
  Package,
  Users,
  Truck,
  UserCheck,
  AlertTriangle,
  ArrowUpRight,
  ArrowDownRight,
  Wallet,
  Clock,
  CheckCircle,
  Plus,
  Boxes
} from 'lucide-react';

interface DashboardProps {
  settings: Settings;
  onNavigate: (module: string) => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ settings, onNavigate }) => {
  const [sales, setSales] = useState<SaleInvoice[]>([]);
  const [purchases, setPurchases] = useState<PurchaseOrder[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [payments, setPayments] = useState<PaymentRecord[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchDashboardData = async () => {
    try {
      setLoading(true);
      const [sSnap, puSnap, prSnap, cSnap, supSnap, empSnap, eSnap, paySnap] = await Promise.all([
        getDocs(erpCollection('sales')),
        getDocs(erpCollection('purchases')),
        getDocs(erpCollection('products')),
        getDocs(erpCollection('customers')),
        getDocs(erpCollection('suppliers')),
        getDocs(erpCollection('employees')),
        getDocs(erpCollection('expenses')),
        getDocs(erpCollection('payments')),
      ]);

      const sList: SaleInvoice[] = sSnap.docs.map(d => ({ id: d.id, ...d.data() } as SaleInvoice));
      sList.sort((a, b) => (b.date || '').localeCompare(a.date || ''));
      setSales(sList);

      const puList: PurchaseOrder[] = puSnap.docs.map(d => ({ id: d.id, ...d.data() } as PurchaseOrder));
      puList.sort((a, b) => (b.date || '').localeCompare(a.date || ''));
      setPurchases(puList);

      setProducts(prSnap.docs.map(d => ({ id: d.id, ...d.data() } as Product)));
      setCustomers(cSnap.docs.map(d => ({ id: d.id, ...d.data() } as Customer)));
      setSuppliers(supSnap.docs.map(d => ({ id: d.id, ...d.data() } as Supplier)));
      setEmployees(empSnap.docs.map(d => ({ id: d.id, ...d.data() } as Employee)));
      setExpenses(eSnap.docs.map(d => ({ id: d.id, ...d.data() } as Expense)));
      setPayments(paySnap.docs.map(d => ({ id: d.id, ...d.data() } as PaymentRecord)));
    } catch (err) {
      console.error('Error fetching dashboard metrics:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboardData();
  }, []);

  // Aggregated KPIs
  const totalRevenue = sales.reduce((acc, s) => acc + (s.total || 0), 0);
  const totalPurchasesCost = purchases.reduce((acc, p) => acc + (p.total || 0), 0);
  const customerReceivables = customers.reduce((acc, c) => acc + (c.outstanding || 0), 0);
  const supplierPayables = suppliers.reduce((acc, s) => acc + (s.payable || 0), 0);
  const totalDirectExpenses = expenses.reduce((acc, e) => acc + (e.amount || 0), 0);

  // Cash In / Out
  const salesPaidCash = sales.reduce((acc, s) => acc + (s.paid || 0), 0);
  const customerPaymentsIn = payments
    .filter(p => p.type === 'customer_payment')
    .reduce((acc, p) => acc + (p.amount || 0), 0);
  const totalCashIn = salesPaidCash + customerPaymentsIn;

  const purchasesPaidCash = purchases.reduce((acc, p) => acc + (p.paid || 0), 0);
  const supplierPaymentsOut = payments
    .filter(p => p.type === 'supplier_payment')
    .reduce((acc, p) => acc + (p.amount || 0), 0);
  const totalCashOut = purchasesPaidCash + supplierPaymentsOut + totalDirectExpenses;
  const netCashBalance = totalCashIn - totalCashOut;

  // Stock status counts
  const lowStockThreshold = settings.lowStockThreshold || 5;
  const lowStockItems = products.filter(p => p.stock > 0 && p.stock <= (p.minStock || lowStockThreshold));
  const outOfStockItems = products.filter(p => p.stock <= 0);

  return (
    <div className="space-y-6">
      {/* Welcome Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-cyan-950/40 border border-slate-800 p-5 sm:p-6 rounded-2xl flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <span className="text-xs font-mono font-bold text-cyan-400 uppercase tracking-widest">
            {settings.companyName || 'DataCore Solutions Co.'}
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight mt-0.5">
            Executive Dashboard
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Real-time live enterprise financial metrics and stock movements.
          </p>
        </div>
        <div className="flex flex-wrap gap-2 w-full md:w-auto">
          <button
            onClick={() => onNavigate('Sales')}
            className="flex-1 md:flex-initial bg-cyan-600 hover:bg-cyan-500 text-white font-medium px-3.5 py-2 rounded-xl text-xs flex items-center justify-center gap-1.5 transition cursor-pointer shadow-lg shadow-cyan-950"
          >
            <Plus size={15} />
            <span>New Sale</span>
          </button>
          <button
            onClick={() => onNavigate('Purchase')}
            className="flex-1 md:flex-initial bg-slate-800 hover:bg-slate-750 border border-cyan-500/30 text-cyan-300 font-medium px-3.5 py-2 rounded-xl text-xs flex items-center justify-center gap-1.5 transition cursor-pointer"
          >
            <Plus size={15} />
            <span>New Purchase</span>
          </button>
          <button
            onClick={() => onNavigate('Inventory')}
            className="flex-1 md:flex-initial bg-slate-950 hover:bg-slate-850 border border-slate-800 text-slate-300 font-medium px-3.5 py-2 rounded-xl text-xs flex items-center justify-center gap-1.5 transition cursor-pointer"
          >
            <Boxes size={15} />
            <span>Inventory</span>
          </button>
        </div>
      </div>

      {loading ? (
        <div className="text-center py-20 bg-slate-900/40 border border-slate-800 rounded-2xl">
          <span className="inline-block w-8 h-8 border-3 border-cyan-400 border-t-transparent rounded-full animate-spin" />
          <p className="text-slate-400 text-sm mt-3">Aggregating live business figures...</p>
        </div>
      ) : (
        <>
          {/* Top 4 Core Financial KPI Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* 1. Total Sales Revenue */}
            <div
              onClick={() => onNavigate('Sales')}
              className="bg-slate-900 hover:bg-slate-850 border border-slate-800 hover:border-cyan-500/40 p-5 rounded-2xl space-y-2 transition cursor-pointer group shadow-lg"
            >
              <div className="flex justify-between items-center text-slate-400 text-xs">
                <span className="font-medium">Total Sales Revenue</span>
                <span className="p-2 rounded-xl bg-cyan-950 border border-cyan-800/80 text-cyan-400 group-hover:scale-110 transition">
                  <TrendingUp size={16} />
                </span>
              </div>
              <p className="text-2xl font-black text-white font-mono tracking-tight">
                {formatCurrency(totalRevenue, settings.currency)}
              </p>
              <div className="flex justify-between items-center text-[11px] text-slate-500 pt-1 border-t border-slate-800/80">
                <span>{sales.length} Invoices Issued</span>
                <span className="text-cyan-400 font-medium flex items-center gap-0.5">
                  View <ArrowUpRight size={12} />
                </span>
              </div>
            </div>

            {/* 2. Customer Receivables */}
            <div
              onClick={() => onNavigate('Customers')}
              className="bg-slate-900 hover:bg-slate-850 border border-slate-800 hover:border-rose-500/40 p-5 rounded-2xl space-y-2 transition cursor-pointer group shadow-lg"
            >
              <div className="flex justify-between items-center text-slate-400 text-xs">
                <span className="font-medium">Customer Receivables (Due)</span>
                <span className="p-2 rounded-xl bg-rose-950 border border-rose-800/80 text-rose-400 group-hover:scale-110 transition">
                  <ArrowDownRight size={16} />
                </span>
              </div>
              <p className="text-2xl font-black text-rose-400 font-mono tracking-tight">
                {formatCurrency(customerReceivables, settings.currency)}
              </p>
              <div className="flex justify-between items-center text-[11px] text-slate-500 pt-1 border-t border-slate-800/80">
                <span>{customers.length} Client Accounts</span>
                <span className="text-rose-400 font-medium flex items-center gap-0.5">
                  Collect <ArrowUpRight size={12} />
                </span>
              </div>
            </div>

            {/* 3. Total Procurement (Purchases) */}
            <div
              onClick={() => onNavigate('Purchase')}
              className="bg-slate-900 hover:bg-slate-850 border border-slate-800 hover:border-amber-500/40 p-5 rounded-2xl space-y-2 transition cursor-pointer group shadow-lg"
            >
              <div className="flex justify-between items-center text-slate-400 text-xs">
                <span className="font-medium">Total Procurement</span>
                <span className="p-2 rounded-xl bg-amber-950 border border-amber-800/80 text-amber-400 group-hover:scale-110 transition">
                  <ShoppingCart size={16} />
                </span>
              </div>
              <p className="text-2xl font-black text-amber-400 font-mono tracking-tight">
                {formatCurrency(totalPurchasesCost, settings.currency)}
              </p>
              <div className="flex justify-between items-center text-[11px] text-slate-500 pt-1 border-t border-slate-800/80">
                <span>{purchases.length} Purchase Orders</span>
                <span className="text-amber-400 font-medium flex items-center gap-0.5">
                  Orders <ArrowUpRight size={12} />
                </span>
              </div>
            </div>

            {/* 4. Net Cash / Bank Balance */}
            <div
              onClick={() => onNavigate('Accounts')}
              className="bg-slate-900 hover:bg-slate-850 border border-slate-800 hover:border-emerald-500/40 p-5 rounded-2xl space-y-2 transition cursor-pointer group shadow-lg"
            >
              <div className="flex justify-between items-center text-slate-400 text-xs">
                <span className="font-medium">Net Cash & Bank Balance</span>
                <span className="p-2 rounded-xl bg-emerald-950 border border-emerald-800/80 text-emerald-400 group-hover:scale-110 transition">
                  <Wallet size={16} />
                </span>
              </div>
              <p className={`text-2xl font-black font-mono tracking-tight ${netCashBalance >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                {formatCurrency(netCashBalance, settings.currency)}
              </p>
              <div className="flex justify-between items-center text-[11px] text-slate-500 pt-1 border-t border-slate-800/80">
                <span>Inflows - Outflows</span>
                <span className="text-emerald-400 font-medium flex items-center gap-0.5">
                  Ledger <ArrowUpRight size={12} />
                </span>
              </div>
            </div>
          </div>

          {/* Secondary Stats Row */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
            <div
              onClick={() => onNavigate('Inventory')}
              className="bg-slate-900/80 hover:bg-slate-850 border border-slate-800 p-3.5 rounded-xl cursor-pointer transition"
            >
              <span className="text-[11px] text-slate-400 block">Total Catalog Items</span>
              <span className="text-lg font-bold text-white font-mono">{products.length}</span>
            </div>

            <div
              onClick={() => onNavigate('Inventory')}
              className="bg-slate-900/80 hover:bg-slate-850 border border-slate-800 p-3.5 rounded-xl cursor-pointer transition"
            >
              <span className="text-[11px] text-slate-400 block">Low Stock Alerts</span>
              <span className={`text-lg font-bold font-mono ${lowStockItems.length > 0 ? 'text-amber-400' : 'text-slate-300'}`}>
                {lowStockItems.length}
              </span>
            </div>

            <div
              onClick={() => onNavigate('Inventory')}
              className="bg-slate-900/80 hover:bg-slate-850 border border-slate-800 p-3.5 rounded-xl cursor-pointer transition"
            >
              <span className="text-[11px] text-slate-400 block">Out of Stock</span>
              <span className={`text-lg font-bold font-mono ${outOfStockItems.length > 0 ? 'text-rose-400' : 'text-slate-300'}`}>
                {outOfStockItems.length}
              </span>
            </div>

            <div
              onClick={() => onNavigate('Suppliers')}
              className="bg-slate-900/80 hover:bg-slate-850 border border-slate-800 p-3.5 rounded-xl cursor-pointer transition"
            >
              <span className="text-[11px] text-slate-400 block">Supplier Payables</span>
              <span className="text-lg font-bold text-amber-400 font-mono">
                {formatCurrency(supplierPayables, settings.currency)}
              </span>
            </div>

            <div
              onClick={() => onNavigate('Accounts')}
              className="bg-slate-900/80 hover:bg-slate-850 border border-slate-800 p-3.5 rounded-xl cursor-pointer transition"
            >
              <span className="text-[11px] text-slate-400 block">Direct Expenses</span>
              <span className="text-lg font-bold text-rose-400 font-mono">
                {formatCurrency(totalDirectExpenses, settings.currency)}
              </span>
            </div>

            <div
              onClick={() => onNavigate('Employees')}
              className="bg-slate-900/80 hover:bg-slate-850 border border-slate-800 p-3.5 rounded-xl cursor-pointer transition"
            >
              <span className="text-[11px] text-slate-400 block">Active Employees</span>
              <span className="text-lg font-bold text-cyan-300 font-mono">
                {employees.filter(e => e.status === 'Active').length} staff
              </span>
            </div>
          </div>

          {/* Low Stock Warning Banner if items exist */}
          {(lowStockItems.length > 0 || outOfStockItems.length > 0) && (
            <div className="bg-amber-950/40 border border-amber-800/80 rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-xl bg-amber-900/50 text-amber-400 shrink-0">
                  <AlertTriangle size={20} />
                </div>
                <div>
                  <h4 className="font-bold text-white text-sm">
                    Inventory Replenishment Required ({lowStockItems.length + outOfStockItems.length} items)
                  </h4>
                  <p className="text-amber-200/80 mt-0.5">
                    {outOfStockItems.length > 0 && `${outOfStockItems.length} products are out of stock. `}
                    {lowStockItems.length > 0 && `${lowStockItems.length} products reached minimum reorder levels.`}
                  </p>
                </div>
              </div>
              <button
                onClick={() => onNavigate('Inventory')}
                className="bg-amber-600 hover:bg-amber-500 text-white font-semibold px-3.5 py-1.5 rounded-xl transition cursor-pointer text-xs"
              >
                Inspect Low Stock
              </button>
            </div>
          )}

          {/* Recent Sales & Purchases Grids */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Recent Sales */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4 shadow-xl">
              <div className="flex justify-between items-center border-b border-slate-800 pb-3">
                <h3 className="font-bold text-white text-sm flex items-center gap-2">
                  <FileText className="text-cyan-400" size={17} />
                  <span>Recent Sales Invoices</span>
                </h3>
                <button
                  onClick={() => onNavigate('Sales')}
                  className="text-xs text-cyan-400 hover:underline"
                >
                  View All &rarr;
                </button>
              </div>

              {sales.length === 0 ? (
                <p className="text-xs text-slate-500 italic py-6 text-center">
                  No sales recorded yet. Click &quot;New Sale&quot; to issue your first invoice.
                </p>
              ) : (
                <div className="divide-y divide-slate-800 text-xs">
                  {sales.slice(0, 5).map(s => (
                    <div key={s.id} className="py-2.5 flex justify-between items-center">
                      <div>
                        <span className="font-mono font-bold text-cyan-400 block">{s.invoiceNumber}</span>
                        <span className="text-white font-medium">{s.customerName}</span>
                        <span className="text-[11px] text-slate-500 block">{formatDate(s.date)}</span>
                      </div>
                      <div className="text-right space-y-1">
                        <span className="font-mono font-bold text-white block">
                          {formatCurrency(s.total, settings.currency)}
                        </span>
                        <span
                          className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                            s.paymentStatus === 'Paid'
                              ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                              : s.paymentStatus === 'Partially Paid'
                              ? 'bg-amber-950 text-amber-300 border border-amber-800'
                              : 'bg-rose-950 text-rose-300 border border-rose-800'
                          }`}
                        >
                          {s.paymentStatus}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Recent Purchases */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4 shadow-xl">
              <div className="flex justify-between items-center border-b border-slate-800 pb-3">
                <h3 className="font-bold text-white text-sm flex items-center gap-2">
                  <ShoppingCart className="text-amber-400" size={17} />
                  <span>Recent Purchase Orders</span>
                </h3>
                <button
                  onClick={() => onNavigate('Purchase')}
                  className="text-xs text-cyan-400 hover:underline"
                >
                  View All &rarr;
                </button>
              </div>

              {purchases.length === 0 ? (
                <p className="text-xs text-slate-500 italic py-6 text-center">
                  No purchase orders recorded yet. Record purchases to replenish warehouse stock.
                </p>
              ) : (
                <div className="divide-y divide-slate-800 text-xs">
                  {purchases.slice(0, 5).map(po => (
                    <div key={po.id} className="py-2.5 flex justify-between items-center">
                      <div>
                        <span className="font-mono font-bold text-cyan-400 block">{po.purchaseNumber}</span>
                        <span className="text-white font-medium">{po.supplierName}</span>
                        <span className="text-[11px] text-slate-500 block">{formatDate(po.date)}</span>
                      </div>
                      <div className="text-right space-y-1">
                        <span className="font-mono font-bold text-white block">
                          {formatCurrency(po.total, settings.currency)}
                        </span>
                        <span
                          className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                            po.paymentStatus === 'Paid'
                              ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                              : po.paymentStatus === 'Partially Paid'
                              ? 'bg-amber-950 text-amber-300 border border-amber-800'
                              : 'bg-rose-950 text-rose-300 border border-rose-800'
                          }`}
                        >
                          {po.paymentStatus}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </>
      )}
    </div>
  );
};
