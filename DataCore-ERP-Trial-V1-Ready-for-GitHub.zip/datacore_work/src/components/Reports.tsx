import { erpCollection, erpDoc } from '../tenant';
import React, { useState, useEffect } from 'react';
import { db } from '../firebase';
import { collection, getDocs } from 'firebase/firestore';
import { SaleInvoice, PurchaseOrder, Product, Customer, Supplier, Expense, PaymentRecord, Settings } from '../types';
import { formatCurrency, formatDate, exportToCSV } from '../utils/formatters';
import {
  FileText,
  Printer,
  Download,
  Calendar,
  Filter,
  TrendingUp,
  TrendingDown,
  DollarSign,
  Package,
  Users,
  Truck,
  Layers,
  ArrowRight
} from 'lucide-react';

interface ReportsProps {
  settings: Settings;
}

type ReportType =
  | 'sales'
  | 'purchases'
  | 'profit_loss'
  | 'inventory'
  | 'customer_due'
  | 'supplier_payable'
  | 'expenses'
  | 'cash_flow';

type DatePreset = 'all' | 'today' | 'this_week' | 'this_month' | 'custom';

export const Reports: React.FC<ReportsProps> = ({ settings }) => {
  const [reportType, setReportType] = useState<ReportType>('sales');
  const [datePreset, setDatePreset] = useState<DatePreset>('this_month');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');

  // Firestore raw data
  const [sales, setSales] = useState<SaleInvoice[]>([]);
  const [purchases, setPurchases] = useState<PurchaseOrder[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [payments, setPayments] = useState<PaymentRecord[]>([]);
  const [loading, setLoading] = useState(true);

  const loadData = async () => {
    try {
      setLoading(true);
      const [sSnap, puSnap, prSnap, cSnap, supSnap, eSnap, paySnap] = await Promise.all([
        getDocs(erpCollection('sales')),
        getDocs(erpCollection('purchases')),
        getDocs(erpCollection('products')),
        getDocs(erpCollection('customers')),
        getDocs(erpCollection('suppliers')),
        getDocs(erpCollection('expenses')),
        getDocs(erpCollection('payments')),
      ]);

      setSales(sSnap.docs.map(d => ({ id: d.id, ...d.data() } as SaleInvoice)));
      setPurchases(puSnap.docs.map(d => ({ id: d.id, ...d.data() } as PurchaseOrder)));
      setProducts(prSnap.docs.map(d => ({ id: d.id, ...d.data() } as Product)));
      setCustomers(cSnap.docs.map(d => ({ id: d.id, ...d.data() } as Customer)));
      setSuppliers(supSnap.docs.map(d => ({ id: d.id, ...d.data() } as Supplier)));
      setExpenses(eSnap.docs.map(d => ({ id: d.id, ...d.data() } as Expense)));
      setPayments(paySnap.docs.map(d => ({ id: d.id, ...d.data() } as PaymentRecord)));
    } catch (err) {
      console.error('Error fetching report data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  // Filter items by selected date range
  const filterByDate = (dateStr?: string) => {
    if (!dateStr) return true;
    if (datePreset === 'all') return true;

    const itemDate = new Date(dateStr).toISOString().slice(0, 10);
    const today = new Date().toISOString().slice(0, 10);

    if (datePreset === 'today') {
      return itemDate === today;
    }

    if (datePreset === 'this_week') {
      const now = new Date();
      const firstDay = new Date(now.setDate(now.getDate() - now.getDay())).toISOString().slice(0, 10);
      return itemDate >= firstDay && itemDate <= today;
    }

    if (datePreset === 'this_month') {
      const currentMonth = today.slice(0, 7); // YYYY-MM
      return itemDate.startsWith(currentMonth);
    }

    if (datePreset === 'custom') {
      if (startDate && itemDate < startDate) return false;
      if (endDate && itemDate > endDate) return false;
      return true;
    }

    return true;
  };

  const filteredSales = sales.filter(s => filterByDate(s.date));
  const filteredPurchases = purchases.filter(p => filterByDate(p.date));
  const filteredExpenses = expenses.filter(e => filterByDate(e.date));

  // Calculations for Profit & Loss
  const salesRevenue = filteredSales.reduce((acc, s) => acc + (s.total || 0), 0);
  // Estimate COGS from line items: for each sale item, find product cost or line quantity * product.purchasePrice
  const cogs = filteredSales.reduce((acc, s) => {
    const saleCost = (s.items || []).reduce((itemAcc, item) => {
      const prod = products.find(p => p.id === item.productId);
      const costPerUnit = prod?.purchasePrice || 0;
      return itemAcc + item.quantity * costPerUnit;
    }, 0);
    return acc + saleCost;
  }, 0);

  const totalExpenseAmount = filteredExpenses.reduce((acc, e) => acc + (e.amount || 0), 0);
  const grossProfit = salesRevenue - cogs;
  const netProfit = grossProfit - totalExpenseAmount;

  // Print Report Handler
  const handlePrint = () => {
    window.print();
  };

  // Export CSV Handler
  const handleExportCSV = () => {
    const dateTag = new Date().toISOString().slice(0, 10);

    if (reportType === 'sales') {
      const headers = ['Invoice #', 'Date', 'Customer', 'Subtotal', 'Discount', 'Tax', 'Total (KWD)', 'Paid', 'Outstanding', 'Status'];
      const rows = filteredSales.map(s => [
        s.invoiceNumber,
        s.date,
        s.customerName,
        s.subtotal,
        s.discount,
        s.tax,
        s.total,
        s.paid,
        s.outstanding,
        s.paymentStatus,
      ]);
      exportToCSV(`Sales_Report_${dateTag}`, headers, rows);
    } else if (reportType === 'purchases') {
      const headers = ['PO #', 'Date', 'Supplier', 'Subtotal', 'Discount', 'Tax', 'Total (KWD)', 'Paid', 'Payable Due', 'Status'];
      const rows = filteredPurchases.map(p => [
        p.purchaseNumber,
        p.date,
        p.supplierName,
        p.subtotal,
        p.discount,
        p.tax,
        p.total,
        p.paid,
        p.outstanding,
        p.paymentStatus,
      ]);
      exportToCSV(`Purchase_Report_${dateTag}`, headers, rows);
    } else if (reportType === 'inventory') {
      const headers = ['Code', 'Product Name', 'SKU', 'Category', 'Unit', 'Stock Qty', 'Cost Price', 'Selling Price', 'Inventory Valuation (KWD)'];
      const rows = products.map(p => [
        p.code,
        p.name,
        p.sku,
        p.category,
        p.unit,
        p.stock,
        p.purchasePrice,
        p.sellingPrice,
        (p.stock * p.purchasePrice).toFixed(3),
      ]);
      exportToCSV(`Inventory_Valuation_${dateTag}`, headers, rows);
    } else if (reportType === 'customer_due') {
      const headers = ['Customer Code', 'Name', 'Mobile', 'Email', 'Opening Bal', 'Outstanding Due (KWD)'];
      const rows = customers.map(c => [
        c.code,
        c.name,
        c.mobile,
        c.email,
        c.openingBalance,
        c.outstanding,
      ]);
      exportToCSV(`Customer_Receivables_${dateTag}`, headers, rows);
    } else if (reportType === 'supplier_payable') {
      const headers = ['Supplier Code', 'Name', 'Mobile', 'Email', 'Opening Bal', 'Payable Due (KWD)'];
      const rows = suppliers.map(s => [
        s.code,
        s.name,
        s.mobile,
        s.email,
        s.openingBalance,
        s.payable,
      ]);
      exportToCSV(`Supplier_Payables_${dateTag}`, headers, rows);
    } else if (reportType === 'expenses') {
      const headers = ['Date', 'Category', 'Description', 'Method', 'Reference', 'Amount (KWD)'];
      const rows = filteredExpenses.map(e => [
        e.date,
        e.category,
        e.description,
        e.paymentMethod,
        e.reference || '',
        e.amount,
      ]);
      exportToCSV(`Expenses_Report_${dateTag}`, headers, rows);
    } else {
      // General Summary
      const headers = ['Metric', 'Amount (KWD)'];
      const rows = [
        ['Sales Revenue', salesRevenue],
        ['Cost of Goods Sold (COGS)', cogs],
        ['Gross Profit', grossProfit],
        ['Operating Expenses', totalExpenseAmount],
        ['Net Profit', netProfit],
      ];
      exportToCSV(`Profit_Loss_Report_${dateTag}`, headers, rows);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-slate-900 border border-slate-800 p-4 sm:p-5 rounded-2xl print:hidden">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-white flex items-center gap-2.5">
            <Layers className="text-cyan-400" size={26} />
            <span>Business Reports & Analytics</span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 mt-0.5">
            Generate audited statements, profitability calculations, tax records, and export CSV files.
          </p>
        </div>
        <div className="flex items-center gap-2 w-full sm:w-auto">
          <button
            onClick={handleExportCSV}
            className="flex-1 sm:flex-initial bg-slate-800 hover:bg-slate-750 border border-cyan-500/30 text-cyan-300 font-medium px-3.5 py-2 rounded-xl text-xs flex items-center justify-center gap-1.5 transition cursor-pointer"
          >
            <Download size={15} />
            <span>Export CSV</span>
          </button>
          <button
            onClick={handlePrint}
            className="flex-1 sm:flex-initial bg-cyan-600 hover:bg-cyan-500 text-white font-medium px-3.5 py-2 rounded-xl text-xs flex items-center justify-center gap-1.5 transition cursor-pointer shadow-lg shadow-cyan-950"
          >
            <Printer size={15} />
            <span>Print Report</span>
          </button>
        </div>
      </div>

      {/* Report Type Selector + Date Range Bar (Hidden during print) */}
      <div className="space-y-3 print:hidden">
        {/* Report Selector Pills */}
        <div className="flex gap-2 overflow-x-auto pb-2 text-xs sm:text-sm">
          {[
            { id: 'sales', label: 'Sales Report', icon: FileText },
            { id: 'purchases', label: 'Purchase Report', icon: Package },
            { id: 'profit_loss', label: 'Profit & Loss (P&L)', icon: TrendingUp },
            { id: 'inventory', label: 'Inventory Valuation', icon: Layers },
            { id: 'customer_due', label: 'Customer Receivables', icon: Users },
            { id: 'supplier_payable', label: 'Supplier Payables', icon: Truck },
            { id: 'expenses', label: 'Expense Analysis', icon: TrendingDown },
          ].map(r => (
            <button
              key={r.id}
              onClick={() => setReportType(r.id as any)}
              className={`px-3.5 py-2 rounded-xl font-medium transition cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
                reportType === r.id
                  ? 'bg-cyan-950 text-cyan-300 border border-cyan-800 shadow-md'
                  : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              <r.icon size={15} />
              <span>{r.label}</span>
            </button>
          ))}
        </div>

        {/* Date Filter Bar */}
        <div className="flex flex-wrap items-center gap-2 bg-slate-900/70 border border-slate-800 p-3 rounded-xl text-xs">
          <span className="text-slate-400 font-semibold flex items-center gap-1 mr-1">
            <Calendar size={14} className="text-cyan-400" />
            <span>Period:</span>
          </span>
          {(['all', 'today', 'this_week', 'this_month', 'custom'] as DatePreset[]).map(dp => (
            <button
              key={dp}
              onClick={() => setDatePreset(dp)}
              className={`px-3 py-1.5 rounded-lg font-medium transition cursor-pointer uppercase text-[11px] ${
                datePreset === dp
                  ? 'bg-cyan-600 text-white font-bold'
                  : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
              }`}
            >
              {dp.replace('_', ' ')}
            </button>
          ))}

          {datePreset === 'custom' && (
            <div className="flex items-center gap-2 ml-auto w-full sm:w-auto mt-2 sm:mt-0">
              <input
                type="date"
                value={startDate}
                onChange={e => setStartDate(e.target.value)}
                className="bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1 text-white text-xs font-mono"
              />
              <span className="text-slate-500">to</span>
              <input
                type="date"
                value={endDate}
                onChange={e => setEndDate(e.target.value)}
                className="bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1 text-white text-xs font-mono"
              />
            </div>
          )}
        </div>
      </div>

      {/* REPORT CONTENT AREA */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-7 space-y-6 shadow-xl print:bg-white print:text-black print:border-none print:shadow-none print:p-0">
        {/* Printable Title Block */}
        <div className="border-b border-slate-800 pb-4 flex justify-between items-start">
          <div>
            <h3 className="text-xl font-bold text-white print:text-black">
              {reportType === 'sales' && 'Sales Invoices & Revenue Report'}
              {reportType === 'purchases' && 'Purchase Orders & Procurement Report'}
              {reportType === 'profit_loss' && 'Profit & Loss Statement (Income vs Expenses)'}
              {reportType === 'inventory' && 'Inventory Stock Valuation & Reorder Report'}
              {reportType === 'customer_due' && 'Customer Accounts Receivable & Outstanding Aging'}
              {reportType === 'supplier_payable' && 'Supplier Accounts Payable & Due Obligations'}
              {reportType === 'expenses' && 'Operating Expenses & Cost Allocation Report'}
            </h3>
            <p className="text-xs text-slate-400 print:text-slate-600 mt-1">
              Company: {settings.companyName || 'DataCore Solutions Co.'} | Generated:{' '}
              {formatDate(new Date().toISOString())}
            </p>
          </div>
          <span className="text-xs font-mono text-cyan-400 print:text-cyan-700 uppercase font-semibold">
            Currency: {settings.currency}
          </span>
        </div>

        {/* 1. SALES REPORT */}
        {reportType === 'sales' && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-950 p-4 rounded-xl border border-slate-800 print:bg-slate-100">
              <div>
                <span className="text-xs text-slate-400 block">Total Invoices:</span>
                <span className="text-lg font-bold text-white print:text-black">{filteredSales.length}</span>
              </div>
              <div>
                <span className="text-xs text-slate-400 block">Total Revenue:</span>
                <span className="text-lg font-bold text-cyan-400 font-mono">
                  {formatCurrency(salesRevenue, settings.currency)}
                </span>
              </div>
              <div>
                <span className="text-xs text-slate-400 block">Cash Collected:</span>
                <span className="text-lg font-bold text-emerald-400 font-mono">
                  {formatCurrency(
                    filteredSales.reduce((acc, s) => acc + (s.paid || 0), 0),
                    settings.currency
                  )}
                </span>
              </div>
              <div>
                <span className="text-xs text-slate-400 block">Outstanding Due:</span>
                <span className="text-lg font-bold text-rose-400 font-mono">
                  {formatCurrency(
                    filteredSales.reduce((acc, s) => acc + (s.outstanding || 0), 0),
                    settings.currency
                  )}
                </span>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="border-b border-slate-800 text-slate-400 font-semibold uppercase">
                  <tr>
                    <th className="py-2.5 px-3">Invoice #</th>
                    <th className="py-2.5 px-3">Date</th>
                    <th className="py-2.5 px-3">Customer</th>
                    <th className="py-2.5 px-3 text-right">Subtotal</th>
                    <th className="py-2.5 px-3 text-right">Tax</th>
                    <th className="py-2.5 px-3 text-right">Total</th>
                    <th className="py-2.5 px-3 text-right">Paid</th>
                    <th className="py-2.5 px-3 text-right">Due</th>
                    <th className="py-2.5 px-3 text-center">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/80">
                  {filteredSales.map(s => (
                    <tr key={s.id}>
                      <td className="py-2.5 px-3 font-mono font-bold text-cyan-400">{s.invoiceNumber}</td>
                      <td className="py-2.5 px-3 text-slate-400">{formatDate(s.date)}</td>
                      <td className="py-2.5 px-3 text-white font-medium">{s.customerName}</td>
                      <td className="py-2.5 px-3 text-right font-mono">{formatCurrency(s.subtotal, settings.currency)}</td>
                      <td className="py-2.5 px-3 text-right font-mono text-slate-400">{formatCurrency(s.tax, settings.currency)}</td>
                      <td className="py-2.5 px-3 text-right font-mono font-bold text-white">{formatCurrency(s.total, settings.currency)}</td>
                      <td className="py-2.5 px-3 text-right font-mono text-emerald-400">{formatCurrency(s.paid, settings.currency)}</td>
                      <td className="py-2.5 px-3 text-right font-mono text-rose-400">{formatCurrency(s.outstanding, settings.currency)}</td>
                      <td className="py-2.5 px-3 text-center">{s.paymentStatus}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* 2. PURCHASE REPORT */}
        {reportType === 'purchases' && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-950 p-4 rounded-xl border border-slate-800 print:bg-slate-100">
              <div>
                <span className="text-xs text-slate-400 block">Total Orders:</span>
                <span className="text-lg font-bold text-white print:text-black">{filteredPurchases.length}</span>
              </div>
              <div>
                <span className="text-xs text-slate-400 block">Total Procurement:</span>
                <span className="text-lg font-bold text-cyan-400 font-mono">
                  {formatCurrency(
                    filteredPurchases.reduce((acc, p) => acc + (p.total || 0), 0),
                    settings.currency
                  )}
                </span>
              </div>
              <div>
                <span className="text-xs text-slate-400 block">Paid to Vendors:</span>
                <span className="text-lg font-bold text-emerald-400 font-mono">
                  {formatCurrency(
                    filteredPurchases.reduce((acc, p) => acc + (p.paid || 0), 0),
                    settings.currency
                  )}
                </span>
              </div>
              <div>
                <span className="text-xs text-slate-400 block">Payable Balance Due:</span>
                <span className="text-lg font-bold text-amber-400 font-mono">
                  {formatCurrency(
                    filteredPurchases.reduce((acc, p) => acc + (p.outstanding || 0), 0),
                    settings.currency
                  )}
                </span>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="border-b border-slate-800 text-slate-400 font-semibold uppercase">
                  <tr>
                    <th className="py-2.5 px-3">PO #</th>
                    <th className="py-2.5 px-3">Date</th>
                    <th className="py-2.5 px-3">Supplier</th>
                    <th className="py-2.5 px-3 text-right">Subtotal</th>
                    <th className="py-2.5 px-3 text-right">Tax</th>
                    <th className="py-2.5 px-3 text-right">Grand Total</th>
                    <th className="py-2.5 px-3 text-right">Paid</th>
                    <th className="py-2.5 px-3 text-right">Payable Due</th>
                    <th className="py-2.5 px-3 text-center">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/80">
                  {filteredPurchases.map(p => (
                    <tr key={p.id}>
                      <td className="py-2.5 px-3 font-mono font-bold text-cyan-400">{p.purchaseNumber}</td>
                      <td className="py-2.5 px-3 text-slate-400">{formatDate(p.date)}</td>
                      <td className="py-2.5 px-3 text-white font-medium">{p.supplierName}</td>
                      <td className="py-2.5 px-3 text-right font-mono">{formatCurrency(p.subtotal, settings.currency)}</td>
                      <td className="py-2.5 px-3 text-right font-mono text-slate-400">{formatCurrency(p.tax, settings.currency)}</td>
                      <td className="py-2.5 px-3 text-right font-mono font-bold text-white">{formatCurrency(p.total, settings.currency)}</td>
                      <td className="py-2.5 px-3 text-right font-mono text-emerald-400">{formatCurrency(p.paid, settings.currency)}</td>
                      <td className="py-2.5 px-3 text-right font-mono text-amber-400">{formatCurrency(p.outstanding, settings.currency)}</td>
                      <td className="py-2.5 px-3 text-center">{p.paymentStatus}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* 3. PROFIT & LOSS REPORT */}
        {reportType === 'profit_loss' && (
          <div className="space-y-6 max-w-2xl mx-auto">
            <div className="bg-slate-950 border border-slate-800 rounded-2xl p-6 space-y-4 font-mono text-sm print:bg-white print:border-black">
              <h4 className="font-bold text-base text-cyan-400 border-b border-slate-800 pb-2">
                Income Statement (P&L)
              </h4>

              <div className="flex justify-between items-center text-slate-300">
                <span>Gross Invoiced Sales Revenue:</span>
                <span className="font-bold text-white">{formatCurrency(salesRevenue, settings.currency)}</span>
              </div>

              <div className="flex justify-between items-center text-rose-400">
                <span>Less: Cost of Goods Sold (COGS):</span>
                <span>- {formatCurrency(cogs, settings.currency)}</span>
              </div>

              <div className="flex justify-between items-center text-emerald-400 font-bold border-t border-b border-slate-800 py-2">
                <span>Gross Trading Profit:</span>
                <span>{formatCurrency(grossProfit, settings.currency)}</span>
              </div>

              <div className="flex justify-between items-center text-rose-400">
                <span>Less: Operating Expenses & Overhead:</span>
                <span>- {formatCurrency(totalExpenseAmount, settings.currency)}</span>
              </div>

              <div className="flex justify-between items-center text-lg font-extrabold border-t-2 border-slate-700 pt-3">
                <span className="text-white">Net Business Profit / (Loss):</span>
                <span className={netProfit >= 0 ? 'text-emerald-400' : 'text-rose-400'}>
                  {formatCurrency(netProfit, settings.currency)}
                </span>
              </div>
            </div>
          </div>
        )}

        {/* 4. INVENTORY VALUATION REPORT */}
        {reportType === 'inventory' && (
          <div className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 bg-slate-950 p-4 rounded-xl border border-slate-800 print:bg-slate-100">
              <div>
                <span className="text-xs text-slate-400 block">Total Catalog Items:</span>
                <span className="text-lg font-bold text-white print:text-black">{products.length} products</span>
              </div>
              <div>
                <span className="text-xs text-slate-400 block">Total Asset Valuation (Cost):</span>
                <span className="text-lg font-bold text-cyan-400 font-mono">
                  {formatCurrency(
                    products.reduce((acc, p) => acc + (p.stock || 0) * (p.purchasePrice || 0), 0),
                    settings.currency
                  )}
                </span>
              </div>
              <div>
                <span className="text-xs text-slate-400 block">Potential Retail Valuation:</span>
                <span className="text-lg font-bold text-emerald-400 font-mono">
                  {formatCurrency(
                    products.reduce((acc, p) => acc + (p.stock || 0) * (p.sellingPrice || 0), 0),
                    settings.currency
                  )}
                </span>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="border-b border-slate-800 text-slate-400 font-semibold uppercase">
                  <tr>
                    <th className="py-2.5 px-3">Code / SKU</th>
                    <th className="py-2.5 px-3">Product Name</th>
                    <th className="py-2.5 px-3">Category</th>
                    <th className="py-2.5 px-3 text-center">Stock Qty</th>
                    <th className="py-2.5 px-3 text-right">Cost Price</th>
                    <th className="py-2.5 px-3 text-right">Selling Price</th>
                    <th className="py-2.5 px-3 text-right">Total Valuation (Cost)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/80">
                  {products.map(p => (
                    <tr key={p.id}>
                      <td className="py-2.5 px-3 font-mono text-cyan-400">{p.code}</td>
                      <td className="py-2.5 px-3 font-medium text-white">{p.name}</td>
                      <td className="py-2.5 px-3 text-slate-400">{p.category}</td>
                      <td className="py-2.5 px-3 text-center font-bold">
                        {p.stock} {p.unit}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono">{formatCurrency(p.purchasePrice, settings.currency)}</td>
                      <td className="py-2.5 px-3 text-right font-mono">{formatCurrency(p.sellingPrice, settings.currency)}</td>
                      <td className="py-2.5 px-3 text-right font-mono font-bold text-cyan-300">
                        {formatCurrency((p.stock || 0) * (p.purchasePrice || 0), settings.currency)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* 5. CUSTOMER OUTSTANDING REPORT */}
        {reportType === 'customer_due' && (
          <div className="space-y-4">
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 flex justify-between items-center">
              <div>
                <span className="text-xs text-slate-400 block">Total Accounts Receivable (Due from Clients):</span>
                <span className="text-2xl font-extrabold text-rose-400 font-mono">
                  {formatCurrency(
                    customers.reduce((acc, c) => acc + (c.outstanding || 0), 0),
                    settings.currency
                  )}
                </span>
              </div>
              <span className="text-xs text-slate-400">{customers.filter(c => c.outstanding > 0).length} customers with balance</span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="border-b border-slate-800 text-slate-400 font-semibold uppercase">
                  <tr>
                    <th className="py-2.5 px-3">Customer Code</th>
                    <th className="py-2.5 px-3">Customer Name</th>
                    <th className="py-2.5 px-3">Contact</th>
                    <th className="py-2.5 px-3 text-right">Opening Bal</th>
                    <th className="py-2.5 px-3 text-right">Outstanding Due (KWD)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/80">
                  {customers.map(c => (
                    <tr key={c.id}>
                      <td className="py-2.5 px-3 font-mono text-cyan-400">{c.code}</td>
                      <td className="py-2.5 px-3 font-medium text-white">{c.name}</td>
                      <td className="py-2.5 px-3 text-slate-400">{c.mobile || '-'}</td>
                      <td className="py-2.5 px-3 text-right font-mono">{formatCurrency(c.openingBalance, settings.currency)}</td>
                      <td className="py-2.5 px-3 text-right font-mono font-bold text-rose-400">
                        {formatCurrency(c.outstanding, settings.currency)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* 6. SUPPLIER PAYABLE REPORT */}
        {reportType === 'supplier_payable' && (
          <div className="space-y-4">
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 flex justify-between items-center">
              <div>
                <span className="text-xs text-slate-400 block">Total Accounts Payable (Owed to Vendors):</span>
                <span className="text-2xl font-extrabold text-amber-400 font-mono">
                  {formatCurrency(
                    suppliers.reduce((acc, s) => acc + (s.payable || 0), 0),
                    settings.currency
                  )}
                </span>
              </div>
              <span className="text-xs text-slate-400">{suppliers.filter(s => s.payable > 0).length} suppliers with balance</span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="border-b border-slate-800 text-slate-400 font-semibold uppercase">
                  <tr>
                    <th className="py-2.5 px-3">Supplier Code</th>
                    <th className="py-2.5 px-3">Supplier Name</th>
                    <th className="py-2.5 px-3">Contact</th>
                    <th className="py-2.5 px-3 text-right">Opening Bal</th>
                    <th className="py-2.5 px-3 text-right">Payable Due (KWD)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/80">
                  {suppliers.map(s => (
                    <tr key={s.id}>
                      <td className="py-2.5 px-3 font-mono text-cyan-400">{s.code}</td>
                      <td className="py-2.5 px-3 font-medium text-white">{s.name}</td>
                      <td className="py-2.5 px-3 text-slate-400">{s.mobile || '-'}</td>
                      <td className="py-2.5 px-3 text-right font-mono">{formatCurrency(s.openingBalance, settings.currency)}</td>
                      <td className="py-2.5 px-3 text-right font-mono font-bold text-amber-400">
                        {formatCurrency(s.payable, settings.currency)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* 7. EXPENSES REPORT */}
        {reportType === 'expenses' && (
          <div className="space-y-4">
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 flex justify-between items-center">
              <div>
                <span className="text-xs text-slate-400 block">Total Expenses in Period:</span>
                <span className="text-2xl font-extrabold text-rose-400 font-mono">
                  {formatCurrency(totalExpenseAmount, settings.currency)}
                </span>
              </div>
              <span className="text-xs text-slate-400">{filteredExpenses.length} entries</span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="border-b border-slate-800 text-slate-400 font-semibold uppercase">
                  <tr>
                    <th className="py-2.5 px-3">Date</th>
                    <th className="py-2.5 px-3">Category</th>
                    <th className="py-2.5 px-3">Description</th>
                    <th className="py-2.5 px-3">Payment Method</th>
                    <th className="py-2.5 px-3 text-right">Amount (KWD)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/80">
                  {filteredExpenses.map(e => (
                    <tr key={e.id}>
                      <td className="py-2.5 px-3 font-mono text-slate-400">{formatDate(e.date)}</td>
                      <td className="py-2.5 px-3 text-cyan-300 font-medium">{e.category}</td>
                      <td className="py-2.5 px-3 text-white">{e.description}</td>
                      <td className="py-2.5 px-3 text-slate-400">{e.paymentMethod}</td>
                      <td className="py-2.5 px-3 text-right font-mono font-bold text-rose-400">
                        {formatCurrency(e.amount, settings.currency)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
