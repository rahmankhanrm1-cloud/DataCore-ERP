export interface Product {
  id: string; // firestore doc ID
  code: string; // PRD-00001
  name: string;
  sku: string;
  barcode?: string;
  category: string;
  unit: string;
  purchasePrice: number;
  sellingPrice: number;
  openingStock: number;
  stock: number;
  minStock: number;
  description?: string;
  createdAt?: string;
}

export interface Customer {
  id: string; // firestore doc ID
  code: string; // CUS-00001
  name: string;
  mobile: string;
  email: string;
  address: string;
  openingBalance: number;
  outstanding: number;
  notes?: string;
  createdAt?: string;
}

export interface Supplier {
  id: string; // firestore doc ID
  code: string; // SUP-00001
  name: string;
  mobile: string;
  email: string;
  address: string;
  openingBalance: number;
  payable: number;
  notes?: string;
  createdAt?: string;
}

export interface InvoiceItem {
  productId: string;
  productName: string;
  sku: string;
  availableStock: number;
  quantity: number;
  unitPrice: number;
  discount: number; // percentage or fixed amount
  tax: number; // tax amount
  lineTotal: number;
}

export interface SaleInvoice {
  id: string;
  invoiceNumber: string; // INV-00001
  customerId: string;
  customerName: string;
  customerMobile?: string;
  customerAddress?: string;
  date: string; // YYYY-MM-DD
  dueDate?: string;
  items: InvoiceItem[];
  subtotal: number;
  discount: number;
  tax: number;
  total: number;
  paid: number;
  outstanding: number;
  paymentStatus: 'Paid' | 'Partially Paid' | 'Unpaid';
  notes?: string;
  createdAt?: string;
}

export interface PurchaseItem {
  productId: string;
  productName: string;
  sku: string;
  currentStock: number;
  quantity: number;
  purchasePrice: number;
  discount: number;
  tax: number;
  lineTotal: number;
}

export interface PurchaseOrder {
  id: string;
  purchaseNumber: string; // PO-00001
  supplierId: string;
  supplierName: string;
  supplierMobile?: string;
  date: string;
  items: PurchaseItem[];
  subtotal: number;
  discount: number;
  tax: number;
  total: number;
  paid: number;
  outstanding: number;
  paymentStatus: 'Paid' | 'Partially Paid' | 'Unpaid';
  notes?: string;
  createdAt?: string;
}

export interface Expense {
  id: string;
  date: string;
  category: string;
  description: string;
  amount: number;
  paymentMethod: string;
  reference?: string;
  notes?: string;
  createdAt?: string;
}

export interface PaymentRecord {
  id: string;
  type: 'customer_payment' | 'supplier_payment';
  partyId: string;
  partyName: string;
  amount: number;
  date: string;
  paymentMethod: string;
  reference?: string;
  notes?: string;
  createdAt?: string;
}

export interface Employee {
  id: string;
  employeeId: string; // EMP-00001
  name: string;
  mobile: string;
  email: string;
  jobTitle: string;
  department: string;
  salary: number;
  joiningDate: string;
  address: string;
  status: 'Active' | 'Inactive';
  notes?: string;
  createdAt?: string;
}

export interface Settings {
  companyName: string;
  phone: string;
  email: string;
  address: string;
  currency: string;
  currencyDecimals: number;
  taxRate: number;
  invoicePrefix: string;
  purchasePrefix: string;
  lowStockThreshold: number;
  allowNegativeStock: boolean;
}
