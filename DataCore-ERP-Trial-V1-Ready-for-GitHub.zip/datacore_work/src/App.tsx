import { TrialManager } from './components/TrialManager';
import { isOwner } from './tenant';
import { erpCollection, erpDoc } from './tenant';
import React, { useState, useEffect } from 'react';
import { auth, db } from './firebase';
import { onAuthStateChanged, signOut, User as FirebaseUser } from 'firebase/auth';
import { doc, getDoc, setDoc, onSnapshot, Timestamp } from 'firebase/firestore';
import { Settings as SettingsType } from './types';
import { LoginScreen } from './components/LoginScreen';
import { Dashboard } from './components/Dashboard';
import { Inventory } from './components/Inventory';
import { Sales } from './components/Sales';
import { Purchases } from './components/Purchases';
import { Accounts } from './components/Accounts';
import { Customers } from './components/Customers';
import { Suppliers } from './components/Suppliers';
import { Employees } from './components/Employees';
import { Reports } from './components/Reports';
import { Settings } from './components/Settings';

import {
  LayoutDashboard,
  ShoppingCart,
  Boxes,
  FileText,
  Briefcase,
  Users,
  Truck,
  UserCheck,
  Layers,
  Settings as SettingsIcon,
  Menu,
  X,
  LogOut,
  ShieldCheck,
  ChevronRight
} from 'lucide-react';

const DEFAULT_SETTINGS: SettingsType = {
  companyName: 'DataCore Solutions Co.',
  phone: '+965 2200 8800',
  email: 'contact@datacore.erp',
  address: 'Kuwait City, Al Hamra Tower, Floor 22',
  currency: 'KWD',
  currencyDecimals: 3,
  taxRate: 0,
  invoicePrefix: 'INV',
  purchasePrefix: 'PO',
  lowStockThreshold: 5,
  allowNegativeStock: false,
};

export default function App() {
  const [currentUser, setCurrentUser] = useState<FirebaseUser | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [trialStatus, setTrialStatus] = useState<'checking'|'active'|'blocked'>('checking');
  const [trialExpiry, setTrialExpiry] = useState<number>(0);
  const [activeModule, setActiveModule] = useState('Dashboard');
  const [isMobileDrawerOpen, setIsMobileDrawerOpen] = useState(false);
  const [settings, setSettings] = useState<SettingsType>(DEFAULT_SETTINGS);

  // Listen to Auth State
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, user => {
      setCurrentUser(user);
      setTrialStatus(user && user.email?.toLowerCase() === 'datacore.solutionswork@gmail.com' ? 'active' : 'checking');
      setAuthLoading(false);
    });
    return () => unsubscribe();
  }, []);

  // Live trial status, with server-side enforcement by Firestore rules.
  useEffect(() => {
    if (!currentUser || isOwner()) return;
    const unsub = onSnapshot(doc(db, 'trialAccounts', currentUser.uid), snapshot => {
      const data = snapshot.data();
      const expiry = data?.expiresAt instanceof Timestamp ? data.expiresAt.toMillis() : 0;
      setTrialExpiry(expiry);
      setTrialStatus(data?.status === 'active' && expiry > Date.now() ? 'active' : 'blocked');
    }, () => setTrialStatus('blocked'));
    return unsub;
  }, [currentUser]);
  useEffect(() => {
    if (isOwner() || trialStatus !== 'active') return;
    const timer = window.setInterval(() => {
      if (trialExpiry && Date.now() >= trialExpiry) setTrialStatus('blocked');
    }, 30000);
    return () => window.clearInterval(timer);
  }, [trialStatus, trialExpiry]);

  // Fetch Settings once user is authenticated
  useEffect(() => {
    if (!currentUser || trialStatus !== 'active') return;

    const loadSettings = async () => {
      try {
        const sDoc = await getDoc(erpDoc('settings', 'general'));
        if (sDoc.exists()) {
          setSettings({ ...DEFAULT_SETTINGS, ...sDoc.data() });
        } else {
          // Initialize default settings doc
          await setDoc(erpDoc('settings', 'general'), DEFAULT_SETTINGS);
        }
      } catch (err) {
        console.error('Error fetching settings:', err);
      }
    };
    loadSettings();
  }, [currentUser, trialStatus]);

  const handleLogout = async () => {
    try {
      await signOut(auth);
    } catch (err) {
      console.error('Error signing out:', err);
    }
  };

  // Auth Loading Screen
  if (authLoading) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-4">
        <div className="w-12 h-12 rounded-2xl bg-cyan-950 border border-cyan-500/30 flex items-center justify-center text-cyan-400 mb-4 animate-pulse">
          <ShieldCheck size={28} />
        </div>
        <p className="text-slate-400 text-sm font-medium">Verifying DataCore Security Session...</p>
      </div>
    );
  }

  // Not Logged In -> Show Login / Register Screen
  if (!currentUser) {
    return <LoginScreen />;
  }

  if (trialStatus !== 'active') {
    return <div className="min-h-screen bg-slate-950 text-white flex flex-col justify-center items-center p-8 text-center gap-4">
      <h1 className="text-2xl font-bold">{trialStatus === 'checking' ? 'Checking trial access...' : 'Trial expired or awaiting admin approval'}</h1>
      <p className="text-slate-400">Please contact DataCore ERP administrator.</p>
      <button className="bg-cyan-700 px-5 py-3 rounded-lg" onClick={handleLogout}>Sign Out</button>
    </div>;
  }

  // Navigation Items
  const navItems = [
    { name: 'Dashboard', icon: LayoutDashboard },
    { name: 'Sales', icon: FileText },
    { name: 'Inventory', icon: Boxes },
    { name: 'Purchase', icon: ShoppingCart },
    { name: 'Accounts', icon: Briefcase },
    { name: 'Customers', icon: Users },
    { name: 'Suppliers', icon: Truck },
    { name: 'Employees', icon: UserCheck },
    { name: 'Reports', icon: Layers },
    { name: 'Settings', icon: SettingsIcon },
    ...(isOwner() ? [{ name: 'Trial Manager', icon: ShieldCheck }] : []),
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col antialiased selection:bg-cyan-500 selection:text-white">
      {/* Top Navbar Header */}
      <header className="sticky top-0 z-40 bg-slate-900/90 backdrop-blur-md border-b border-slate-800 px-4 sm:px-6 py-3 flex justify-between items-center print:hidden">
        <div className="flex items-center gap-3">
          <button
            onClick={() => setIsMobileDrawerOpen(!isMobileDrawerOpen)}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition lg:hidden"
            aria-label="Toggle Navigation Menu"
          >
            {isMobileDrawerOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
          <div
            onClick={() => setActiveModule('Dashboard')}
            className="flex items-center gap-2.5 cursor-pointer select-none"
          >
            <div className="w-8 h-8 rounded-xl bg-cyan-950 border border-cyan-500/40 flex items-center justify-center text-cyan-400 shadow-inner">
              <ShieldCheck size={18} />
            </div>
            <div>
              <span className="font-extrabold text-base sm:text-lg text-white tracking-tight">
                DataCore <span className="text-cyan-400">ERP</span>
              </span>
              <span className="hidden sm:inline-block ml-2 text-[10px] uppercase font-mono px-2 py-0.5 rounded-full bg-slate-800 text-slate-400 border border-slate-700">
                Enterprise v2.4
              </span>
            </div>
          </div>
        </div>

        {/* User Info & Logout Button */}
        <div className="flex items-center gap-2 sm:gap-4">
          <div className="hidden sm:flex flex-col text-right">
            <span className="text-xs font-semibold text-white truncate max-w-[180px]">
              {currentUser.email || 'Admin User'}
            </span>
            <span className="text-[10px] text-cyan-400 font-mono">
              Role: Authenticated User
            </span>
          </div>

          <button
            onClick={handleLogout}
            title="Sign Out"
            className="p-2 rounded-xl text-slate-400 hover:text-rose-400 hover:bg-slate-800 transition cursor-pointer flex items-center gap-1.5 text-xs font-medium"
          >
            <LogOut size={18} />
            <span className="hidden sm:inline">Sign Out</span>
          </button>
        </div>
      </header>

      {/* Main Layout Area */}
      <div className="flex flex-1 relative overflow-hidden">
        {/* Desktop Sidebar */}
        <aside className="w-64 bg-slate-900 border-r border-slate-800 hidden lg:flex flex-col justify-between p-4 shrink-0 overflow-y-auto">
          <div className="space-y-6">
            <div className="space-y-1">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 px-3">
                Core Modules
              </span>
              <nav className="space-y-1 pt-1">
                {navItems.map(item => {
                  const isActive = activeModule === item.name;
                  return (
                    <button
                      key={item.name}
                      onClick={() => setActiveModule(item.name)}
                      className={`flex items-center justify-between w-full px-3.5 py-2.5 rounded-xl text-sm font-medium transition cursor-pointer group ${
                        isActive
                          ? 'bg-cyan-950 text-cyan-300 border border-cyan-800 shadow-md font-semibold'
                          : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <item.icon
                          size={18}
                          className={isActive ? 'text-cyan-400' : 'text-slate-500 group-hover:text-slate-300'}
                        />
                        <span>{item.name}</span>
                      </div>
                      {isActive && <ChevronRight size={14} className="text-cyan-400" />}
                    </button>
                  );
                })}
              </nav>
            </div>
          </div>

          {/* Sidebar Footer info */}
          <div className="pt-4 border-t border-slate-800/80 text-[11px] text-slate-500 space-y-1">
            <p className="font-semibold text-slate-400">{settings.companyName}</p>
            <p>Currency: <span className="text-cyan-400 font-mono">{settings.currency} (3 dec)</span></p>
          </div>
        </aside>

        {/* Mobile Drawer (Backdrop + Slide-in Sidebar) */}
        {isMobileDrawerOpen && (
          <div className="fixed inset-0 z-50 lg:hidden flex">
            {/* Backdrop */}
            <div
              onClick={() => setIsMobileDrawerOpen(false)}
              className="fixed inset-0 bg-black/80 backdrop-blur-xs transition-opacity"
            />

            {/* Off-canvas Menu Panel */}
            <div className="relative w-72 max-w-[85vw] bg-slate-900 border-r border-slate-800 h-full p-4 flex flex-col justify-between z-10 overflow-y-auto">
              <div className="space-y-4">
                <div className="flex justify-between items-center border-b border-slate-800 pb-3">
                  <span className="font-bold text-white text-base">Navigation Menu</span>
                  <button
                    onClick={() => setIsMobileDrawerOpen(false)}
                    className="p-1 rounded-lg text-slate-400 hover:text-white"
                  >
                    <X size={20} />
                  </button>
                </div>

                <nav className="space-y-1">
                  {navItems.map(item => {
                    const isActive = activeModule === item.name;
                    return (
                      <button
                        key={item.name}
                        onClick={() => {
                          setActiveModule(item.name);
                          setIsMobileDrawerOpen(false);
                        }}
                        className={`flex items-center justify-between w-full px-3.5 py-2.5 rounded-xl text-sm font-medium transition cursor-pointer ${
                          isActive
                            ? 'bg-cyan-950 text-cyan-300 border border-cyan-800 font-semibold'
                            : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <item.icon size={18} className={isActive ? 'text-cyan-400' : 'text-slate-500'} />
                          <span>{item.name}</span>
                        </div>
                        {isActive && <ChevronRight size={14} className="text-cyan-400" />}
                      </button>
                    );
                  })}
                </nav>
              </div>

              {/* Drawer footer with logout */}
              <div className="pt-4 border-t border-slate-800 space-y-3">
                <div className="text-xs text-slate-400">
                  <p className="truncate font-semibold text-white">{currentUser.email}</p>
                  <p className="text-[10px] text-cyan-400 font-mono">Authenticated User</p>
                </div>
                <button
                  onClick={handleLogout}
                  className="w-full bg-slate-800 hover:bg-slate-750 text-rose-400 py-2 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition"
                >
                  <LogOut size={16} />
                  <span>Sign Out</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Content Viewport */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto pb-20 lg:pb-8">
          {activeModule === 'Dashboard' && (
            <Dashboard settings={settings} onNavigate={m => setActiveModule(m)} />
          )}

          {activeModule === 'Inventory' && <Inventory settings={settings} />}

          {activeModule === 'Sales' && (
            <Sales
              settings={settings}
              onNavigateToCustomers={() => setActiveModule('Customers')}
              onNavigateToInventory={() => setActiveModule('Inventory')}
            />
          )}

          {activeModule === 'Purchase' && (
            <Purchases
              settings={settings}
              onNavigateToSuppliers={() => setActiveModule('Suppliers')}
              onNavigateToInventory={() => setActiveModule('Inventory')}
            />
          )}

          {activeModule === 'Accounts' && (
            <Accounts
              settings={settings}
              onNavigateToCustomers={() => setActiveModule('Customers')}
              onNavigateToSuppliers={() => setActiveModule('Suppliers')}
            />
          )}

          {activeModule === 'Customers' && <Customers settings={settings} />}

          {activeModule === 'Suppliers' && <Suppliers settings={settings} />}

          {activeModule === 'Employees' && <Employees settings={settings} />}

          {activeModule === 'Reports' && <Reports settings={settings} />}

          {activeModule === 'Trial Manager' && isOwner() && <TrialManager />}
          {activeModule === 'Settings' && (
            <Settings settings={settings} onUpdateSettings={s => setSettings(s)} />
          )}
        </main>
      </div>

      {/* Mobile Bottom Quick Navigation Bar (Hidden during print) */}
      <nav className="fixed bottom-0 inset-x-0 bg-slate-900/95 backdrop-blur-md border-t border-slate-800 py-1.5 px-3 flex justify-around items-center z-30 lg:hidden print:hidden">
        {[
          { name: 'Dashboard', icon: LayoutDashboard },
          { name: 'Sales', icon: FileText },
          { name: 'Inventory', icon: Boxes },
          { name: 'Purchase', icon: ShoppingCart },
          { name: 'Accounts', icon: Briefcase },
        ].map(item => {
          const isActive = activeModule === item.name;
          return (
            <button
              key={item.name}
              onClick={() => setActiveModule(item.name)}
              className={`flex flex-col items-center gap-0.5 p-1 rounded-xl transition cursor-pointer ${
                isActive ? 'text-cyan-400 font-bold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <item.icon size={18} />
              <span className="text-[10px] tracking-tight">{item.name}</span>
            </button>
          );
        })}
      </nav>
    </div>
  );
}
