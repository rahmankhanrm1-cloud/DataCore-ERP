import { auth } from './firebase';

// The original owner's records remain in their legacy root collections.
// Trial customers are restricted to tenants/{uid}/{collection}.
const OWNER_EMAIL = 'datacore.solutionswork@gmail.com';
export const isOwner = () => auth.currentUser?.email?.toLowerCase() === OWNER_EMAIL;
export function erpPath(collectionName: string): string[] {
  const user = auth.currentUser;
  if (!user) throw new Error('Sign in required');
  return isOwner() ? [collectionName] : ['tenants', user.uid, collectionName];
}
